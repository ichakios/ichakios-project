/**
 * @class @BeneficiaryDto class describing properties of Account Information
 */
export interface AccountListDTO {
    id: number
    totalBalance: number;
    availableBalance: number;
    drawableBalance: number;
    accountId: string;
    productID: string;
    name: string;
    currencyID: string;
    status: string;
    clientID: string;
    iban: string;
    openDate: string;
    productType: string;
    productDesc: string;
    groupCode: string;
    econoActCode: string;
    countryCode: string;
    accountType: string;
    debitFrozen: string;
    creditFrozen: string;
}
