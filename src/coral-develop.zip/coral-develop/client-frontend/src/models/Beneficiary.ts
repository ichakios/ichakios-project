/**
 * @class @BeneficiaryDto class describing properties of Beneficiary information
 */
export class BeneficiaryDto {
    id: string | undefined
    customerId: string | undefined
    name!:string
    fromAccount: string | undefined
    nickname!: string
    paymentType!: PaymentType
    bankCountry: string | undefined
    beneficiaryIban!: string
    beneficiaryAccountNumber!: string;
    beneficiaryStatus!: BeneficiaryStatus
    swiftCode!: string
    beneficiaryAddress: string | undefined
    bankName!: string
    bankAddress: string | undefined
    bankCode: string | undefined
    email: string | undefined
    otherReferenceCode: string | undefined
    phone: string | undefined
    createdBy: string | undefined
    createdOn: Date | undefined
    bic: String | undefined
}

/**
 * @enum @PaymentType describes Payment Types available
 */
export enum PaymentType {
  INTRA = 'INTRA',
  LOCAL = 'LOCAL',
  INTERNATIONAL = 'INTERNATIONAL',
}
/**
 * @enum @Status describes the status of the Beneficiary
 */
export enum BeneficiaryStatus {
  ACTIVE = 'ACTIVE',
  DELETED = 'DELETED'
}
