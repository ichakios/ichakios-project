export const approvalHistoryStepList = {
  Initialize: {
    key: 'Initialize',
    labelsBy: {
      NotRelevant: 'approvalHistory.stepList.by.initialize',
    },
  },
  Check: {
    key: 'Check',
    labelsBy: {
      Accepted: 'approvalHistory.stepList.by.check.accepted',
      Rejected: 'approvalHistory.stepList.by.check.rejected',
      Pending: 'approvalHistory.stepList.by.check.pending',
    },
  },
  Authorize: {
    key: 'Authorize',
    labelsBy: {
      Accepted: 'approvalHistory.stepList.by.authorize.accepted',
      Rejected: 'approvalHistory.stepList.by.authorize.rejected',
      Pending: 'approvalHistory.stepList.by.authorize.pending',
    },
  },
  Release: {
    key: 'Release',
    labelsBy: {
      Accepted: 'approvalHistory.stepList.by.release.accepted',
      Rejected: 'approvalHistory.stepList.by.release.rejected',
      Pending: 'approvalHistory.stepList.by.release.pending',
    },
  },
}

export const approvalHistoryStatepList = {
  NotRelevant: {
    key: 'NotRelevant',
  },
  Accepted: {
    key: 'Accepted',
  },
  Rejected: {
    key: 'Rejected',
  },
  Pending: {
    key: 'Pending',
  },
}
