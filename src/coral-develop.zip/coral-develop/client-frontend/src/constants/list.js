export const sortOrder = {
  ASCENDING: 'ascending',
  DESCENDING: 'descending',
}
