export const beneficiaryStatusList = {
  active: {
    value: 'Active',
    label: 'beneficiary.statusList.active',
    color: 'success',
  },
  inactive: {
    value: 'InActive',
    label: 'beneficiary.statusList.inactive',
    color: 'info',
  },
  deceased: {
    value: 'Deceased',
    label: 'beneficiary.statusList.deceased',
    color: 'info',
  },
  deleted: {
    value: 'DELETED',
    label: 'beneficiary.statusList.deleted',
    color: 'info',
  },
}
