export const languages = {
  en: {
    key: 'en',
    name: 'English',
  },
  'ar-ae': {
    key: 'ar-ae',
    name: 'عربى',
  },
}

export const languagesList = Object.values(languages)
