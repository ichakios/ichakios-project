export const sweepsTypes = {
  REAL_TIME_SWEEP: 'REAL_TIME_SWEEP',
  MIN_BALANCE: 'MAINTAIN_MIN_BALANCE',
  MAX_BALANCE: 'MAINTAIN_MAX_BALANCE',
}

export const sweepsErrorCode = {
  CIRCULAR_REFERENCE: 'sweep.circular.reference',
}

export const sweepRequestStatus = {
  PENDING_APPROVAL: {
    key: 'PENDING_APPROVAL',
    color: 'success',
    weight: 0,
  },
  APPROVED: {
    key: 'APPROVED',
    color: 'success',
    weight: 1,
  },
  REJECTED: {
    key: 'REJECTED',
    color: 'danger',
    weight: 2,
  },
  PROCESSED: {
    key: 'PROCESSED',
    color: 'regular',
    weight: 3,
  },
  CANCELED: {
    key: 'CANCELED',
    color: 'secondary',
    weight: 4,
  },
  PROCESSED_BY_BANK: {
    key: 'PROCESSED_BY_BANK',
    color: 'regular',
    weight: 5,
  },
  REJECTED_BY_BANK: {
    key: 'REJECTED_BY_BANK',
    color: 'danger',
    weight: 6,
  },
}
