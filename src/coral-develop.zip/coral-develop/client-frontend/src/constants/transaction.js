export const transactionTypes = {
  credit: {
    value: 'C',
    label: 'account.credit',
  },
  debit: {
    value: 'D',
    label: 'account.debit',
  },
}
