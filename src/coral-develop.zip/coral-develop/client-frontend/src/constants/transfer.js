export const transferTypeList = {
  OWN_ACCOUNT: {
    value: 'OWN_ACCOUNT',
    label: 'transfer.transferTypeList.OWN_ACCOUNT.label',
    sublabel: 'transfer.transferTypeList.OWN_ACCOUNT.sublabel',
  },
  INTRA: {
    value: 'INTRA',
    label: 'transfer.transferTypeList.INTRA.label',
    sublabel: 'transfer.transferTypeList.INTRA.sublabel',
  },
  LOCAL: {
    value: 'LOCAL',
    label: 'transfer.transferTypeList.LOCAL.label',
    sublabel: 'transfer.transferTypeList.LOCAL.sublabel',
  },
  INTERNATIONAL: {
    value: 'INTERNATIONAL',
    label: 'transfer.transferTypeList.INTERNATIONAL.label',
    sublabel: 'transfer.transferTypeList.INTERNATIONAL.sublabel',
  },
}
