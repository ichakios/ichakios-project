export const guaranteeTypesList = {
  'BID_BOND': {
    value: 'BID_BOND',
    url: 'bid-bond',
    label: 'guarantees.guaranteeTypesList.bidBond',
  },
  'PERFORMANCE_BOND': {
    value: 'PERFORMANCE_BOND',
    url: 'performance-bond',
    label: 'guarantees.guaranteeTypesList.performanceBond',
  },
  'ADVANCE_PAYMENT_WITH_OPERATIVE_CLAUSE': {
    value: 'ADVANCE_PAYMENT_WITH_OPERATIVE_CLAUSE',
    url: 'advance-payment-oc',
    label: 'guarantees.guaranteeTypesList.advancePaymentWithOperativeClause',
  },
  'ADVANCE_PAYMENT_WITHOUT_OPERATIVE_CLAUSE': {
    value: 'ADVANCE_PAYMENT_WITHOUT_OPERATIVE_CLAUSE',
    url: 'advance-payment',
    label: 'guarantees.guaranteeTypesList.advancePaymentWithoutOperativeClause',
  },
  'RETENTION_BOND': {
    value: 'RETENTION_BOND',
    url: 'retention-bond',
    label: 'guarantees.guaranteeTypesList.retentionBond',
  },
  'FINANCIAL_GUARANTEE': {
    value: 'FINANCIAL_GUARANTEE',
    url: 'financial-guarantee',
    label: 'guarantees.guaranteeTypesList.financialGuarantee',
  },
}

export const guaranteeStatusList = {
  'ACTIVE': {
    value: 'ACTIVE',
    label: 'guarantees.guaranteeStatusList.active',
    color: 'success',
  },
  'CLOSED': {
    value: 'CLOSED',
    label: 'guarantees.guaranteeStatusList.closed',
    color: 'info',
  },
  'INVOKED_CLOSED': {
    value: 'INVOKED_CLOSED',
    label: 'guarantees.guaranteeStatusList.invokedClosed',
    color: 'info',
  },
}
