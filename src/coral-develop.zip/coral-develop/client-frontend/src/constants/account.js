export const accountStatuses = {
  active: {
    value: 'Active',
    label: 'account.statusList.active',
    color: 'success',
    weight: 2,
  },
  inactive: {
    value: 'InActive',
    label: 'account.statusList.inactive',
    color: 'info',
    weight: 1,
  },
  deceased: {
    value: 'Deceased',
    label: 'account.statusList.deceased',
    color: 'info',
    weight: 0,
  },
  dormant: {
    value: 'Dormant',
    label: 'account.statusList.dormant',
    color: 'info',
    weight: 0,
  },
  blocked: {
    value: 'Blocked',
    label: 'account.statusList.blocked',
    color: 'info',
    weight: 0,
  },
}

export const getAccountStatuses = (status) => {
  return accountStatuses[status] || {}
}
