export const userStatusList = {
  active: {
    value: 'Active',
    key: 'active',
    color: 'success',
    weight: 2,
  },
  pending: {
    value: 'Pending',
    key: 'inactive',
    color: 'info',
    weight: 1,
  },
  deleted: {
    value: 'Deleted',
    key: 'deleted',
    color: 'info',
    weight: 0,
  },
}

export const userTypes = {
  CORPORATE: 'CORPORATE',
  ZAND_RELATIONSHIP_MANAGER: 'ZAND_RELATIONSHIP_MANAGER',
}
