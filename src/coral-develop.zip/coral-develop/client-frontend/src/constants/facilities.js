export const drawdownTypeList = {
  LOAN: 'LOAN',
  CREDIT_PROGRAM: 'CREDIT_PROGRAM',
}
