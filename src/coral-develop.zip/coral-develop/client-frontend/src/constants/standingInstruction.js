export const SIType = {
  own_account: 'OWN_ACCOUNT',
  intra: 'INTRA',
  local: 'LOCAL',
  international: 'INTERNATIONAL',
}

export const standingInstructionStatusList = {
  ACTIVE: {
    value: 'ACTIVE',
    label: 'standingInstructions.statusList.active',
    color: 'success',
  },
  HOLD: {
    value: 'HOLD',
    label: 'standingInstructions.statusList.hold',
    color: 'info',
  },
  CANCELLED: {
    value: 'CANCELLED',
    label: 'standingInstructions.statusList.cancelled',
    color: 'info',
  },
  EXPIRED: {
    value: 'EXPIRED',
    label: 'standingInstructions.statusList.expired',
    color: 'info',
  },
  COMPLETED: {
    value: 'COMPLETED',
    label: 'standingInstructions.statusList.completed',
    color: 'info',
  },
}

export const statusListSI = {
  DRAFT: 'DRAFT',
  NEW: 'NEW',
  PENDING_APPROVAL: 'PENDING_APPROVAL',
  PENDING_ADDITIONAL_APPROVAL: 'PENDING_ADDITIONAL_APPROVAL',
  PENDING_RELEASE: 'PENDING_RELEASE',
  APPROVED: 'APPROVED',
  REJECTED: 'REJECTED',
  FUTURE_DATED: 'FUTURE_DATED',
  CANCELED: 'CANCELED',
  IN_PROCESS_AT_BANK: 'IN_PROCESS_AT_BANK',
  PROCESSED_BY_BANK: 'PROCESSED_BY_BANK',
  REJECTED_BY_BANK: 'REJECTED_BY_BANK',
}

export const standingInstructionFrequencyList = {
  DAILY: {
    value: 'DAILY',
    label: 'standingInstructions.frequencyList.daily',
  },
  WEEKLY: {
    value: 'WEEKLY',
    label: 'standingInstructions.frequencyList.weekly',
  },
  MONTHLY: {
    value: 'MONTHLY',
    label: 'standingInstructions.frequencyList.monthly',
  },
  YEARLY: {
    value: 'YEARLY',
    label: 'standingInstructions.frequencyList.yearly',
  },
}

export const repeatUntilList = {
  COUNT: {
    value: 'COUNT',
    label: 'standingInstructions.repeatUntilList.count',
  },
  END_DATE: {
    value: 'END_DATE',
    label: 'standingInstructions.repeatUntilList.endDate',
  },
}

export const chargeBearerList = {
  OUR: {
    value: 'OUR',
    label: 'standingInstructions.form.chargeBearer.our',
  },
  SHARED: {
    value: 'SHARED',
    label: 'standingInstructions.form.chargeBearer.shared',
  },
  BENEFICIARY: {
    value: 'BENEFICIARY',
    label: 'standingInstructions.form.chargeBearer.beneficiary',
  },
}

export const SIActionType = {
  CREATE: {
    value: 'CREATE',
    label: 'standingInstructionsRequests.actionTypes.create',
  },
  MODIFY: {
    value: 'MODIFY',
    label: 'standingInstructionsRequests.actionTypes.modify',
  },
  CANCEL: {
    value: 'CANCEL',
    label: 'standingInstructionsRequests.actionTypes.cancel',
  },
}
