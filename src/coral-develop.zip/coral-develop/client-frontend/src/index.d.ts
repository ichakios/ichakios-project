declare module 'vue-nl2br'
