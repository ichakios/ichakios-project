import {
  getStandingInstructions,
  validateStandingInstruction,
  createStandingInstruction,
  holdStandingInstruction,
  resumeStandingInstruction,
  editStandingInstruction,
  cancelCoreStandingInstruction,
} from '@/services/standingInstruction/standingInstruction.service'
import { standingInstructionFrequencyList, standingInstructionStatusList } from '@/constants/standingInstruction'
import utils from '@/store/utils/collection'

export const statusListForStandingInstructions = {
  IDLE: 'IDLE',
  FETCHING: 'FETCHING',
  FETCH_SUCCESS: 'FETCH_SUCCESS',
  FETCH_ERROR: 'FETCH_ERROR',
}

export const statusListByStandingInstruction = {
  VALIDATING: 'VALIDATING',
  VALIDATION_SUCCESS: 'VALIDATION_SUCCESS',
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  SAVING: 'SAVING',
  SAVE_SUCCESS: 'SAVE_SUCCESS',
  SAVE_ERROR: 'SAVE_ERROR',
  HOLDING: 'HOLDING',
  HOLD_SUCCESS: 'HOLD_SUCCESS',
  HOLD_ERROR: 'HOLD_ERROR',
  RESUMING: 'RESUMING',
  RESUME_SUCCESS: 'RESUME_SUCCESS',
  RESUME_ERROR: 'RESUME_ERROR',
  CANCELING: 'CANCELING',
  CANCEL_SUCCESS: 'CANCEL_SUCCESS',
  CANCEL_ERROR: 'CANCEL_ERROR',
}

const initialState = {
  ...utils.initialState,
  sortProp: 'status',
  sortOrder: 'ascending',
}

export default {
  namespaced: true,
  state: { ...initialState },

  mutations: {
    ...utils.mutations,
  },

  actions: {
    ...utils.actions,

    loadCollection: async({ commit }) => {
      commit('setStatusForCollection', statusListForStandingInstructions.FETCHING)

      const [errors, data] = await getStandingInstructions()

      if (errors) {
        commit('setStatusForCollection', statusListForStandingInstructions.FETCH_ERROR)
        return
      }

      commit('setCollection', data.map((item) => ({
        id: item.siId,
        referenceId: item.siId,
        status: item.status,
        amount: item.amount,
        frequency: item.frequencyType,
        startDate: item.startDate,
        executedInstances: item.executedInstances,
        futureInstances: item.futureInstances,
      })))
      commit('setStatusForCollection', statusListForStandingInstructions.FETCH_SUCCESS)
    },

    validateItem: async({ commit }, payload) => {
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListByStandingInstruction.VALIDATING,
      })

      const [errors] = await validateStandingInstruction(payload)

      if (errors) {
        commit('setStatusByItem', {
          id: payload.id,
          status: statusListByStandingInstruction.VALIDATE_ERROR,
          errors,
        })
        return
      }

      commit('setStatusByItem', {
        id: payload.id,
        status: statusListByStandingInstruction.VALIDATION_SUCCESS,
      })
    },

    createItem: async({ commit, dispatch }, payload) => {
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListByStandingInstruction.SAVING,
      })

      const [errors] = await createStandingInstruction(payload)

      if (errors) {
        commit('setStatusByItem', {
          id: payload.id,
          status: statusListByStandingInstruction.SAVE_ERROR,
          errors,
        })
        return
      }

      dispatch('loadCollection')

      commit('setStatusByItem', {
        id: payload.id,
        status: statusListByStandingInstruction.SAVE_SUCCESS,
      })
    },

    updateItem: async({ commit }, payload) => {
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListByStandingInstruction.SAVING,
      })

      const [errors] = await editStandingInstruction(payload)

      if (errors) {
        commit('setStatusByItem', {
          id: payload.id,
          status: statusListByStandingInstruction.SAVE_ERROR,
          errors,
        })
        return
      }

      commit('setStatusByItem', {
        id: payload.id,
        status: statusListByStandingInstruction.SAVE_SUCCESS,
      })
    },

    holdItem: async({ commit, dispatch }, { id }) => {
      commit('setStatusByItem', {
        id,
        status: statusListByStandingInstruction.HOLDING,
      })

      const [errors] = await holdStandingInstruction(id)

      if (errors) {
        commit('setStatusByItem', {
          id,
          status: statusListByStandingInstruction.HOLD_ERROR,
          errors,
        })
        return
      }

      // Update the item in the collection
      dispatch('updateItemInCollection', {
        id,
        attrs: {
          status: standingInstructionStatusList.HOLD.value,
        },
      })

      commit('setStatusByItem', {
        id,
        status: statusListByStandingInstruction.HOLD_SUCCESS,
      })
    },

    resumeItem: async({ commit, dispatch }, { id }) => {
      commit('setStatusByItem', {
        id,
        status: statusListByStandingInstruction.RESUMING,
      })

      const [errors] = await resumeStandingInstruction(id)

      if (errors) {
        commit('setStatusByItem', {
          id,
          status: statusListByStandingInstruction.RESUME_ERROR,
          errors,
        })
        return
      }

      // Update the item in the collection
      dispatch('updateItemInCollection', {
        id,
        attrs: {
          status: standingInstructionStatusList.ACTIVE.value,
        },
      })

      commit('setStatusByItem', {
        id,
        status: statusListByStandingInstruction.RESUME_SUCCESS,
      })
    },

    cancelItem: async({ commit, dispatch }, { id, reason }) => {
      commit('setStatusByItem', {
        id,
        status: statusListByStandingInstruction.CANCELING,
      })

      const [errors] = await cancelCoreStandingInstruction(id, reason)

      if (errors) {
        commit('setStatusByItem', {
          id,
          status: statusListByStandingInstruction.CANCEL_ERROR,
          errors,
        })
        return
      }

      // Update the item in the collection

      commit('setStatusByItem', {
        id,
        status: statusListByStandingInstruction.CANCEL_SUCCESS,
      })

      dispatch('loadCollection')
    },
  },

  getters: {
    ...utils.getters,
    getSearchStringByItemForCollection: () => (item) => `
      ${item.nickname}
      ${item.referenceId}
      ${(item.to || {}).name || ''}
      ${(item.to || {}).accountId || ''}
      ${item.status}
      ${item.frequencyType}
      ${item.futureInstances}
      ${item.executedInstances}
      ${item.amount}
    `,
    collectionForDisplay: (state) => {
      return state.collection.map(item => ({
        ...item,
        toName: (item.to || {}).name,
        toId: (item.to || {}).accountId,
      }))
    },
    getSortFunctionForCollection: (state, getters) => () => {
      switch (state.sortProp) {
        case 'status':
          return getters
            .getEnumSortFunction(Object.keys(standingInstructionStatusList))
        case 'frequency':
          return getters
            .getEnumSortFunction(Object.keys(standingInstructionFrequencyList))
        default:
          return getters.getDefaultSortFunction()
      }
    },
  },
}
