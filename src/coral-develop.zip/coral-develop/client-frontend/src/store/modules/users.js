import { v4 as uuid } from 'uuid'

import uamService from '@/services/UserAccessManagementService'
import { sortOnProp } from '@/services/utils.service'

import { userStatusList } from '@/constants/user'
import { sortOrder } from '@/constants/list'

export const statusAllUsers = {
  IDLE: 'idle',
  FETCHING: 'fetching',
  FETCH_SUCCESS: 'fetch_success',
  FETCH_ERROR: 'fetch_error',
}

export const statusByUser = {
  SAVING: 'saving',
  SAVE_SUCCESS: 'save_success',
  SAVE_ERROR: 'save_error',
  DELETING: 'deleting',
  DELETE_SUCCESS: 'delete_success',
  DELETE_ERROR: 'delete_error',
}

const normalizedUser = ({ password, confirmPassword, ...userToNormalize }) => {
  return {
    status: userStatusList.active.key, // We keep the status here, so it can be override when the api will be ready
    roles: [], // Handle the create case, were no roles is added. Will be erased by the roles provided by the api
    ...userToNormalize,
  }
}

const initialState = {
  users: [],
  statusAllUsers: statusAllUsers.IDLE,
  statusByUser: {
    // 'internalId': {
    //   status: statusByUser.SAVE_SUCCESS
    //   updatedAt: new Date(),
    //   apiErrors: []
    // }
  },
  paging: {
    currentPage: 1,
    pageSize: 5,
  },
  sort: {
    prop: 'fullName',
    order: sortOrder.ASCENDING,
  },

  apiErrors: [],
}

export default {
  namespaced: true,
  state: { ...initialState },

  mutations: {
    setUsers(state, users) {
      state.users = users.map((user) => ({
        ...normalizedUser(user),
        internalId: uuid(),
      }))
    },
    setStatusAllUsers(state, status) {
      state.statusAllUsers = status
    },
    setStatusByUser(state, { id: internalId, status }) {
      state.statusByUser = {
        ...state.statusByUser,
        [internalId]: {
          status,
          updatedAt: new Date(),
        },
      }
    },
    setCurrentPage(state, page) {
      state.paging.currentPage = Math.max(1, page)
    },
    setSort(state, { prop, order }) {
      state.sort = {
        prop: prop || state.sort.prop,
        order: order || initialState.sort.order,
      }
      state.paging.currentPage = 1
    },
    setApiErrors(state, newApiErrors) {
      state.apiErrors = [...(newApiErrors || [])]
    },
    setRolesToUser(state, { userName, roles }) {
      const userToUpdate = state.users.find(({ login }) => login === userName)
      userToUpdate.roles = [...roles]
      state.users = [
        { ...userToUpdate },
        ...state.users.filter(({ login }) => login !== userName),
      ]
    },
  },

  actions: {
    async createUser({ commit, state, dispatch }, userInfos) {
      commit('setApiErrors', [])
      commit('setStatusByUser', {
        status: statusByUser.SAVING,
        id: userInfos.internalId,
      })

      const [errorsCreatingUser] = await uamService.createUser({ userInfos })
      if (errorsCreatingUser) {
        commit('setApiErrors', errorsCreatingUser)
        commit('setStatusByUser', {
          status: statusByUser.SAVE_ERROR,
          id: userInfos.internalId,
        })
        return
      }

      commit('setUsers', [
        {
          ...normalizedUser(userInfos),
          login: userInfos.email,
        },
        ...state.users,
      ])
      commit('setStatusByUser', {
        status: statusByUser.SAVE_SUCCESS,
        id: userInfos.internalId,
      })

      if (userInfos.roles) {
        dispatch('roles/setRolesToUser', {
          userName: userInfos.email,
          roles: userInfos.roles,
        }, { root: true })
      }
    },
    async loadUsers({ commit, dispatch }) {
      dispatch('roles/getRoles', null, { root: true })
      commit('setStatusAllUsers', statusAllUsers.FETCHING)

      const data = await Promise.all([
        uamService.getAllUsersInfos(),
        uamService.getAllUsersWithRoles(),
      ])

      let rolesByUser = {}
      const [errorLoadingUser, newUsers] = data[0]
      const [errorGettingRoles, roles = []] = data[1]

      // If we get role, build a map with the key = login, and values = roles
      if (!errorGettingRoles) {
        rolesByUser = roles.reduce((acc, roleObj) => {
          const userEmail = roleObj.user.name
          const userRoles = roleObj.roles || []
          acc[userEmail] = [...userRoles].map(role => role.name)
          return acc
        }, {})
      }

      if (errorLoadingUser) {
        commit('setStatusAllUsers', statusAllUsers.FETCH_ERROR)
        return
      }

      const usersWithRoles = newUsers.map(user => ({
        ...user,
        roles: rolesByUser[user.login] || [],
        mobileNumber: user.phoneNumber,
      }))

      commit('setUsers', usersWithRoles)
      commit('setStatusAllUsers', statusAllUsers.FETCH_SUCCESS)
    },
    goToPage({ commit }, { pageNumber }) {
      commit('setCurrentPage', pageNumber)
    },
    sortUsers({ commit, state }, { prop, order }) {
      if (prop !== state.sort.prop || order) {
        commit('setSort', { prop, order })
        return
      }

      switch (state.sort.order) {
        case sortOrder.ASCENDING:
          commit('setSort', { order: sortOrder.DESCENDING })
          return

        default:
          commit('setSort', { order: sortOrder.ASCENDING })
      }
    },
    async deleteUser({ commit, state, getters }, { id }) {
      commit('setStatusByUser', {
        status: statusByUser.DELETING,
        id,
      })

      const email = (state.users.find(user => user.internalId === id) || {}).email

      const [errorDeletingUser] = await uamService.deleteUser({ userName: email })
      if (errorDeletingUser) {
        commit('setStatusByUser', {
          status: statusByUser.DELETE_ERROR,
          id,
        })
        return
      }

      commit('setUsers', state.users.filter(user => user.internalId !== id))

      if (!getters.usersOnPage.length) {
        commit('setCurrentPage', state.paging.currentPage - 1)
      }

      commit('setStatusByUser', {
        status: statusByUser.DELETE_SUCCESS,
        id,
      })
    },
    async updateUser({ commit, state, dispatch }, userInfos) {
      commit('setApiErrors', [])
      commit('setStatusByUser', {
        status: statusByUser.SAVING,
        id: userInfos.internalId,
      })

      const [errorsUpdatingUser] = await uamService.updateUser({ userInfos })
      if (errorsUpdatingUser) {
        commit('setApiErrors', errorsUpdatingUser)
        commit('setStatusByUser', {
          status: statusByUser.SAVE_ERROR,
          id: userInfos.internalId,
        })
        return
      }

      const userIndexToUpdate = state.users
        .findIndex(user => user.internalId === userInfos.internalId)

      const users = [...state.users]
      users[userIndexToUpdate] = normalizedUser(userInfos)

      commit('setUsers', users)
      commit('setStatusByUser', {
        status: statusByUser.SAVE_SUCCESS,
        id: userInfos.internalId,
      })

      dispatch('roles/setRolesToUser', {
        userName: userInfos.email,
        roles: userInfos.roles,
      }, { root: true })
    },
    clearApiErrors({ commit }) {
      commit('setApiErrors', [])
    },
    addRolesToUser({ commit }, { userName, roles }) {
      commit('setRolesToUser', { userName, roles })
    },
  },

  getters: {
    usersOnPage(state) {
      const startIndexToShow = (state.paging.currentPage - 1) * state.paging.pageSize
      const endIndex = startIndexToShow + state.paging.pageSize
      return state.users
        .map(user => ({
          ...user,
          fullName: `${user.firstName} ${user.lastName}`,
          initials: `${user.firstName.slice(0, 1)}${user.lastName.slice(0, 1)}`.toUpperCase(),
        }))
        .sort(sortOnProp(state.sort.prop, state.sort.order))
        .slice(startIndexToShow, endIndex)
    },
    usersCount(state) {
      return state.users.length
    },
  },
}
