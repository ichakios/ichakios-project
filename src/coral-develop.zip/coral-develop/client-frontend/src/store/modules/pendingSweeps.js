import dayjs from 'dayjs'

import { getCurrentWeekDateRange, dateTableFormat } from '@/utils/formatDates'
import collectionUtils from '@/store/utils/collection'
import { getPendingSweeps, approveSweep, rejectSweep } from '@/services/sweeps/sweeps.service'
import i18n from '@/i18n'

export const statusListForPendingSweeps = {
  IDLE: 'idle',
  FETCHING: 'fetching',
  FETCH_SUCCESS: 'fetch_success',
  FETCH_ERROR: 'fetch_error',
}

export const statusListForBulkPendingSweeps = {
  IDLE: 'idle',
  REJECTING: 'rejecting',
  REJECT_SUCCESS: 'reject_success',
  REJECT_ERROR: 'reject_error',
  APPROVING: 'approving',
  APPROVE_SUCCESS: 'approve_success',
  APPROVE_ERROR: 'approve_error',
}

export const statusListByPendingSweep = {
  REJECTING: 'rejecting',
  REJECT_SUCCESS: 'reject_success',
  REJECT_ERROR: 'reject_error',
  APPROVING: 'approving',
  APPROVE_SUCCESS: 'approve_success',
  APPROVE_ERROR: 'approve_error',
}

const initialState = {
  ...collectionUtils.initialState,
  sortProp: 'createdOnForDisplay',
  sortOrder: 'descending',

  // custom state
  dateRange: getCurrentWeekDateRange(),
}

export default {
  namespaced: true,
  state: { ...initialState },
  mutations: {
    ...collectionUtils.mutations,
    setDateRange(state, dateRange) {
      state.dateRange = dateRange
    },
  },
  actions: {
    ...collectionUtils.actions,
    async loadCollection({ commit }) {
      commit('setStatusForCollection', statusListForPendingSweeps.FETCHING)

      const [errorGettingPendingDeposits, pendingSweeps] = await getPendingSweeps()

      if (errorGettingPendingDeposits) {
        commit('setStatusForCollection', statusListForPendingSweeps.FETCH_ERROR)
        return
      }

      commit('setCollection', [
        ...pendingSweeps,
      ])
      commit('setStatusForCollection', statusListForPendingSweeps.FETCH_SUCCESS)
    },
    filter({ commit }, { dateRange }) {
      commit('setDateRange', dateRange)
    },
    async reject({ commit, state }, { reference, comments }) {
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingSweep.REJECTING,
      })

      const [error] = await rejectSweep({
        reference,
        comments,
      })
      if (error) {
        commit('setStatusByItem', {
          id: reference,
          status: statusListByPendingSweep.REJECT_ERROR,
        })
        return
      }

      commit('setCollection', state.collection.filter(c => c.reference !== reference))
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingSweep.REJECT_SUCCESS,
      })
    },
    async bulkReject({ commit, state }, { options = [] }) {
      commit('setStatusForBulk', statusListForBulkPendingSweeps.REJECTING)

      const response = await Promise.all(options.map(({ reference, comments }) => rejectSweep({
        reference,
        comments,
      })))
      if (response.some(res => !!res[0])) {
        commit('setStatusForBulk', statusListForBulkPendingSweeps.REJECT_ERROR)
        return
      }

      const newCollection = state.collection.filter(c => !options.some(({ reference }) => reference === c.reference))

      commit('setCollection', newCollection)
      commit('setStatusForBulk', statusListForBulkPendingSweeps.REJECT_SUCCESS)
    },
    async approve({ commit, state }, { reference }) {
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingSweep.APPROVING,
      })

      const [error] = await approveSweep(reference)
      if (error) {
        commit('setStatusByItem', {
          id: reference,
          status: statusListByPendingSweep.APPROVE_ERROR,
        })
        return
      }

      commit('setCollection', state.collection.filter(c => c.reference !== reference))
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingSweep.APPROVE_SUCCESS,
      })
    },
    async bulkApprove({ commit, state }, { options = [] }) {
      commit('setStatusForBulk', statusListForBulkPendingSweeps.APPROVING)

      const response = await Promise.all(options.map((reference) => approveSweep(reference)))
      if (response.some(res => !!res[0])) {
        commit('setStatusForBulk', statusListForBulkPendingSweeps.APPROVE_ERROR)
        return
      }

      const newCollection = state.collection.filter(c => !options.some((reference) => reference === c.reference))

      commit('setCollection', newCollection)
      commit('setStatusForBulk', statusListForBulkPendingSweeps.APPROVE_SUCCESS)
    },
  },
  getters: {
    ...collectionUtils.getters,
    collectionForDisplay: (state) => {
      return state.collection.map((item) => {
        const itemForDisplay = {
          ...item,
          typeForDisplay: i18n.t(`pendingSweeps.sweepTypes.${item.type}`),
          createdOnForDisplay: dayjs(item.createdOn).format(dateTableFormat).toUpperCase(),
          targetAccountForDisplay: item.targetAccount.accountId,
          coverAccountsConcatenated: item.coverAccounts.reduce((acc, coverAccount) => `${acc}${coverAccount.accountId}`, ''),
          coverAccountsForDisplay: [
            item.coverAccounts[0].accountId,
            ...(item.coverAccounts[1] ? [item.coverAccounts[1].accountId] : []),
          ],
        }

        return itemForDisplay
      })
    },
    // Override for custom search
    getSearchStringByItemForCollection: () => (item) => {
      return `
        ${item.typeForDisplay}
        ${item.createdOnForDisplay}
        ${item.nickname || ''}
        ${item.amount || ''}
        ${item.targetAccountForDisplay}
        ${item.coverAccountsConcatenated}
      `
    },
    getFilterByItemForCollection: (state) => (item) => {
      if (!(state.dateRange || []).length) {
        return true
      }

      return dayjs(item.createdOn).isBetween(
        dayjs(state.dateRange[0]),
        dayjs(state.dateRange[1]),
        'day',
        '[]',
      )
    },
    getItemIdentifier: () => (item) => {
      return item.reference
    },
  },
}
