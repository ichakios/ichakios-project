import dayjs from 'dayjs'

import { dateTableFormat, getCurrentWeekDateRange } from '@/utils/formatDates'
import { featureCodeList } from '@/constants/deposits'
import {
  getAllPendingDeposits, rejectDeposit, approveDeposit,
} from '@/services/deposits/deposit.service'
import collectionUtils from '@/store/utils/collection'
import i18n from '@/i18n'

export const statusListForPendingDeposits = {
  IDLE: 'idle',
  FETCHING: 'fetching',
  FETCH_SUCCESS: 'fetch_success',
  FETCH_ERROR: 'fetch_error',
}

export const statusListForBulkPendingDeposits = {
  IDLE: 'idle',
  REJECTING: 'rejecting',
  REJECT_SUCCESS: 'reject_success',
  REJECT_ERROR: 'reject_error',
  APPROVING: 'approving',
  APPROVE_SUCCESS: 'approve_success',
  APPROVE_ERROR: 'approve_error',
}

export const statusListByPendingDeposit = {
  REJECTING: 'rejecting',
  REJECT_SUCCESS: 'reject_success',
  REJECT_ERROR: 'reject_error',
  APPROVING: 'approving',
  APPROVE_SUCCESS: 'approve_success',
  APPROVE_ERROR: 'approve_error',
}

const initialState = {
  ...collectionUtils.initialState,
  sortProp: 'createdOnForDisplay',
  sortOrder: 'descending',
  // custom state
  dateRange: getCurrentWeekDateRange(),
}

export default {
  namespaced: true,
  state: { ...initialState },
  mutations: {
    ...collectionUtils.mutations,
    setDateRange(state, dateRange) {
      state.dateRange = dateRange
    },
  },
  actions: {
    ...collectionUtils.actions,
    async loadCollection({ commit }) {
      commit('setStatusForCollection', statusListForPendingDeposits.FETCHING)

      const [errorGettingPendingDeposits, result] = await getAllPendingDeposits()

      if (errorGettingPendingDeposits) {
        commit('setStatusForCollection', statusListForPendingDeposits.FETCH_ERROR)
        return
      }

      const pendingDeposits = result[0]
      const pendingDepositsWithdrawals = result[1]

      commit('setCollection', [
        ...pendingDeposits,
        ...pendingDepositsWithdrawals,
      ])
      commit('setStatusForCollection', statusListForPendingDeposits.FETCH_SUCCESS)
    },
    filter({ commit }, { dateRange }) {
      commit('setDateRange', dateRange)
    },
    async reject({ commit, state, getters }, { id, comments }) {
      commit('setStatusByItem', {
        id,
        status: statusListByPendingDeposit.REJECTING,
      })

      const selectedDepositForRejection = getters.getItemForDisplay(id)
      const [error] = await rejectDeposit({
        reference: id,
        type: selectedDepositForRejection.featureCode,
        comments,
      })
      if (error) {
        commit('setStatusByItem', {
          id,
          status: statusListByPendingDeposit.REJECT_ERROR,
        })
        return
      }

      commit('setCollection', state.collection.filter(c => c.reference !== id))
      commit('setStatusByItem', {
        id,
        status: statusListByPendingDeposit.REJECT_SUCCESS,
      })
    },
    async bulkReject({ commit, state }, { options = [] }) {
      commit('setStatusForBulk', statusListForBulkPendingDeposits.REJECTING)

      const response = await Promise.all(options.map(({ reference, type, comments }) => rejectDeposit({
        reference,
        type,
        comments,
      })))
      if (response.some(res => !!res[0])) {
        commit('setStatusForBulk', statusListForBulkPendingDeposits.REJECT_ERROR)
        return
      }

      const newCollection = state.collection.filter(c => !options.some(({ reference }) => reference === c.reference))

      commit('setCollection', newCollection)
      commit('setStatusForBulk', statusListForBulkPendingDeposits.REJECT_SUCCESS)
    },
    async approve({ commit, state, getters }, { id }) {
      commit('setStatusByItem', {
        id,
        status: statusListByPendingDeposit.APPROVING,
      })

      const selectedDepositForRejection = getters.getItemForDisplay(id)
      const [error] = await approveDeposit({
        reference: id,
        type: selectedDepositForRejection.featureCode,
      })
      if (error) {
        commit('setStatusByItem', {
          id,
          status: statusListByPendingDeposit.APPROVE_ERROR,
        })
        return
      }

      commit('setCollection', state.collection.filter(c => c.reference !== id))
      commit('setStatusByItem', {
        id,
        status: statusListByPendingDeposit.APPROVE_SUCCESS,
      })
    },
    async bulkApprove({ commit, state }, { options = [] }) {
      commit('setStatusForBulk', statusListForBulkPendingDeposits.APPROVING)

      const response = await Promise.all(options.map(({ reference, type }) => approveDeposit({
        reference,
        type,
      })))
      if (response.some(res => !!res[0])) {
        commit('setStatusForBulk', statusListForBulkPendingDeposits.APPROVE_ERROR)
        return
      }

      const newCollection = state.collection.filter(c => !options.some(({ reference }) => reference === c.reference))

      commit('setCollection', newCollection)
      commit('setStatusForBulk', statusListForBulkPendingDeposits.APPROVE_SUCCESS)
    },
  },
  getters: {
    ...collectionUtils.getters,
    collectionForDisplay: (state) => {
      return state.collection.map((item) => {
        const itemForDisplay = {
          id: item.reference,
          ...item,
          featureCodeForDisplay: i18n.t(`pendingDeposits.featureCodeList.${item.featureCode}`),
          createdOnForDisplay: dayjs(item.createdOn).format(dateTableFormat).toUpperCase(),
        }

        if (item.featureCode === featureCodeList.INVESTMENT_DEPOSIT_REQUEST) {
          itemForDisplay.amountForDisplay = item.amount
        } else if (item.featureCode === featureCodeList.INVESTMENT_DEPOSIT_WITHDRAWAL) {
          itemForDisplay.amountForDisplay = item.withdrawalAmount
        }

        return itemForDisplay
      })
    },
    // Override for custom search
    getSearchStringByItemForCollection: () => (item) => {
      return `
        ${item.featureCodeForDisplay}
        ${item.createdOnForDisplay}
        ${item.reference}
        ${item.createdBy}
        ${item.depositAccount}
        ${item.nominatedAccount}
        ${item.currency}
        ${item.amountForDisplay}
      `
    },
    getFilterByItemForCollection: (state) => (item) => {
      if (!(state.dateRange || []).length) {
        return true
      }

      return dayjs(item.createdOn).isBetween(
        dayjs(state.dateRange[0]),
        dayjs(state.dateRange[1]),
        'day',
        '[]',
      )
    },
  },
}
