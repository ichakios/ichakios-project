import dayjs from 'dayjs'
import { getAllDrawdowns } from '@/services/facilities/facilities.service.ts'
import utils from '@/store/utils/collection'
import i18n from '@/i18n'
import { drawdownTypeList } from '@/constants/facilities'
import { dateTableFormat } from '@/utils/formatDates'

export const statusListForDrawdowns = {
  IDLE: 'idle',
  FETCHING: 'fetching',
  FETCH_SUCCESS: 'fetch_success',
  FETCH_ERROR: 'fetch_error',
}

export const statusListByDrawdown = {
  IDLE: 'idle',
  VALIDATING: 'validating',
  VALIDATION_SUCCESS: 'validation_success',
  VALIDATION_ERROR: 'validation_error',
  SAVING: 'saving',
  SAVE_SUCCESS: 'save_success',
  SAVE_ERROR: 'save_error',
  CANCELING: 'canceling',
  CANCEL_SUCCESS: 'cancel_success',
  CANCEL_ERROR: 'cancel_error',
}

const initialState = {
  ...utils.initialState,
  dateRangeFilter: {
    startDate: null,
    endDate: null,
  },
  pageSize: 5,
  sortProp: 'createdOn',
  sortOrder: 'descending',
}

export default {
  namespaced: true,
  state: {
    ...initialState,
  },

  mutations: {
    ...utils.mutations,
    setFilterDateRange(state, { startDate, endDate }) {
      if (!startDate || !endDate) {
        state.dateRangeFilter = {
          startDate: null,
          endDate: null,
        }
        return
      }
      state.dateRangeFilter = { startDate, endDate }
    },
  },

  actions: {
    ...utils.actions,
    /**
 * This Action will excute the getAllDrawdowns API
 * will set the collecton retrieved to the store main collection
 * @param {*} param0
 * @param {*} dateRange needed startDate and endDate params to retrieve list
 */
    async loadCollection({ commit }, dateRange) {
      if (!dateRange) {
        return
      }
      commit('setStatusForCollection', statusListForDrawdowns.FETCHING)
      commit('setFilterDateRange', dateRange)
      const startDate = dayjs(dateRange.startDate).format('YYYY-MM-DD')
      const endDate = dayjs(dateRange.endDate).format('YYYY-MM-DD')
      const [errors, data] = await getAllDrawdowns(startDate, endDate)
      if (errors) {
        commit('setStatusForCollection', statusListForDrawdowns.FETCH_ERROR)
        return
      }
      commit('setCollection', data.content)
      commit('setStatusForCollection', statusListForDrawdowns.FETCH_SUCCESS)
    },
    dateRangeFilter({ commit }, range) {
      commit('setFilterDateRange', range)
    },

  },

  getters: {
    ...utils.getters,
    collectionForDisplay: (state) => {
      return state.collection.map((item) => ({
        ...item,
        drawdownTypeForDisplay: i18n.t(`facilitiesRequests.drawdownTypeList.${drawdownTypeList[item.facilityType]}`),
        createdOnForDisplay: dayjs(item.createdOn).format(dateTableFormat).toUpperCase(),
        amountForDisplay: item.amount,
        statusForDisplay: i18n.t(`facilitiesRequests.statuses.${item.status}`),

      }))
    },
    getItemByReference: (state) => (reference) => {
      const item = state.collection.find((x) => x.reference === reference)
      return item || null
    },

    getSearchStringByItemForCollection: () => (item) => `
    ${item.drawdownTypeForDisplay}
    ${item.createdOnForDisplay}
    ${item.facilityId}
    ${item.createdBy}
    ${item.purpose}
    ${item.amountForDisplay}
    ${item.statusForDisplay}
    `,
  },
}
