import dayjs from 'dayjs'
import { Message } from 'element-ui'
import { getAccounts } from '@/services/account/account.service'
import { getDepositAccounts, getDepositRequests, createDeposit } from '@/services/deposits/deposit.service'
import utils from '@/store/utils/collection'
import i18n from '@/i18n'

export const statusListForDeposits = {
  IDLE: 'idle',
  FETCHING: 'fetching',
  FETCH_SUCCESS: 'fetch_success',
  FETCH_ERROR: 'fetch_error',
}

export const statusListByDeposit = {
  IDLE: 'idle',
  VALIDATING: 'validating',
  VALIDATION_SUCCESS: 'validation_success',
  VALIDATION_ERROR: 'validation_error',
  SAVING: 'saving',
  SAVE_SUCCESS: 'save_success',
  SAVE_ERROR: 'save_error',
  CANCELING: 'canceling',
  CANCEL_SUCCESS: 'cancel_success',
  CANCEL_ERROR: 'cancel_error',
}

const initialState = {
  ...utils.initialState,
  dateRangeFilter: {
    startDate: null,
    endDate: null,
  },
  pageSize: 50,
  sortProp: 'createdOn',
  sortOrder: 'descending',
}

export default {
  namespaced: true,

  state: {
    ...initialState,
    depositAccounts: [],
    depositRequests: [],
    depositAccountsLoading: false,
    depositRequestsLoading: false,
    accounts: [],
  },

  mutations: {
    ...utils.mutations,
    SET_DATA: (state, depositAccounts) => {
      state.depositAccounts = depositAccounts
    },
    SET_LOADING: (state, isLoading) => {
      state.depositAccountsLoading = isLoading
    },
    SET_ACCOUNTS: (state, accounts) => {
      state.accounts = accounts
    },
    setFilterDateRange(state, { startDate, endDate }) {
      if (!startDate || !endDate) {
        state.dateRangeFilter = {
          startDate: null,
          endDate: null,
        }
        return
      }
      state.dateRangeFilter = { startDate, endDate }
    },
  },

  actions: {
    ...utils.actions,

    /**
      * Triggers get All deposits to display in table
      * @param context current context of the state to commit changes to
      * @returns {void}
    */
    async getAllDeposits(context) {
      context.commit('SET_LOADING', true)
      const [error, data] = await getDepositAccounts()
      if (error) {
        context.commit('SET_LOADING', false)
        Message({
          message: i18n.t('deposits.loadDepositFailMsg'),
          type: 'error',
        })
        console.log(error)
      } else {
        context.commit('SET_LOADING', false)
        context.commit('SET_DATA', data)
      }
    },

    /**
      * Triggers create API for deposit after submit
      * @param context current context of the state to commit changes to
      * @param depositDTO is the deposit object needed to be created
      * @returns {void}
    */
    async createDeposit(context, depositDTO) {
      context.commit('SET_LOADING', true)
      const [error] = await createDeposit(depositDTO)
      if (error) {
        context.commit('SET_LOADING', false)
        console.log(error)
      } else {
        context.commit('SET_LOADING', false)
      }
    },
    /**
     * Gets List of Accounts to be used in the Form Account Select Component
     * @param {*} context current context of the state to commit changes to
     */
    async setAccountsforSelect(context) {
      const [error, data] = await getAccounts()
      if (error) {
        Message.error({
          title: 'Deposits',
          message: i18n.t('deposits.loadAccountSelectMsg'),
        })
      } else {
        context.commit('SET_ACCOUNTS', data)
      }
    },

    async loadCollection({ commit }) {
      commit('setStatusForCollection', statusListForDeposits.FETCHING)
      const [errors, data] = await getDepositRequests()
      if (errors) {
        commit('setStatusForCollection', statusListForDeposits.FETCH_ERROR)
        return
      }
      commit('setCollection', data.content)
      commit('setStatusForCollection', statusListForDeposits.FETCH_SUCCESS)
    },

    dateRangeFilter({ commit }, range) {
      commit('setFilterDateRange', range)
    },
  },

  getters: {
    ...utils.getters,

    getSearchStringByItemForCollection: () => (item) => `
      ${item.productType}, // TODO: Complete with all columns
    `,

    getFilterByItemForCollection: (state) => (item) => {
      if (!state.dateRangeFilter.startDate || !state.dateRangeFilter.endDate) {
        return true
      }
      return dayjs(item.createdOn).isBetween(state.dateRangeFilter.startDate, state.dateRangeFilter.endDate, 'day')
    },
  },
}
