import uamService from '@/services/UserAccessManagementService'

export const rolesStatus = {
  IDLE: 'idle',
  FETCHING: 'fetching',
  FETCH_SUCCESS: 'fetch_success',
  FETCH_ERROR: 'fetch_error',
}

export const rolesStatusByUser = {
  EDITING: 'editing',
  EDIT_SUCCESS: 'edit_success',
  EDIT_ERROR: 'edit_error',
}

const initialState = {
  roles: [],
  rolesStatus: rolesStatus.IDLE,
  rolesStatusByUser: {
    // 'john@mail.com': {
    //   status: rolesStatusByUser.EDITING,
    //   updatedAt: new Date(),
    // }
  },
}

export default {
  namespaced: true,
  state: { ...initialState },

  mutations: {
    setRoles(state, newRoles) {
      state.roles = [...newRoles]
    },
    setRolesStatus(state, newStatus) {
      state.rolesStatus = newStatus
    },
    setRolesStatusByUser(state, { status, userName }) {
      state.rolesStatusByUser = {
        ...state.rolesStatusByUser,
        [userName]: {
          status,
          updatedAt: new Date(),
        },
      }
    },
  },

  actions: {
    async getRoles({ commit }) {
      commit('setRolesStatus', rolesStatus.FETCHING)
      const [errorGettingRoles, newRoles] = await uamService.getRoles()
      if (errorGettingRoles) {
        commit('setRolesStatus', rolesStatus.FETCH_ERROR)
        return
      }

      commit('setRoles', newRoles)
      commit('setRolesStatus', rolesStatus.FETCH_SUCCESS)
    },

    async setRolesToUser({ commit, dispatch }, { roles, userName }) {
      commit('setRolesStatusByUser', {
        userName,
        status: rolesStatusByUser.EDITING,
      })

      const [errorAddingRoles] = await uamService.addRoleToUser({ roles, userName })
      if (errorAddingRoles) {
        commit('setRolesStatusByUser', {
          userName,
          status: rolesStatusByUser.EDIT_ERROR,
        })
        return
      }

      dispatch('users/addRolesToUser', { roles, userName }, { root: true })

      commit('setRolesStatusByUser', {
        userName,
        status: rolesStatusByUser.EDIT_SUCCESS,
      })
    },
  },
}
