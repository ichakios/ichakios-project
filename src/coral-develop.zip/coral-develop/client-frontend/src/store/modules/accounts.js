import { getAccounts, editAccount, deleteAccountNickname } from '@/services/account/account.service'
import { accountDetailsStore } from './accountDetails'
import { getAccountStatuses } from '@/constants/account'
import { Message } from 'element-ui'
import utils from '@/store/utils/collection'
import i18n from '@/i18n'

export const statusListByAccount = {
  IDLE: 'idle',
  UPDATING: 'updating',
  UPDATE_SUCCESS: 'update_success',
  UPDATE_ERROR: 'update_error',
  NICKNAME_DELETING: 'nickname_deleting',
  NICKNAME_DELETE_SUCCESS: 'nickname_delete_success',
  NICKNAME_DELETE_ERROR: 'nickname_delete_error',
  NICKNAME_DUPLICATE_ERROR: 'nickname_duplicate_error',
}

// MODULE MAPPINGS
export const accountsStore = {
  moduleName: 'accounts',
  state: {
    accounts: 'accounts',
  },
  actions: {
    getAccounts: 'accounts/getAccounts',
    selectAccount: 'accounts/selectAccount',
  },
  mutations: {
    setAccounts: 'accounts/setAccounts',
  },
}

const initialState = {
  ...utils.initialState,
}

export default {
  namespaced: true,
  state: {
    ...initialState,
  },
  mutations: {
    ...utils.mutations,
    setAccounts(state, accounts) {
      state.collection = accounts
        .map((account) => {
          const lowerCasedStatus = account.status.toLowerCase()
          return {
            ...account,
            totalBalance: Number.parseFloat(account.totalBalance),
            availableBalance: Number.parseFloat(account.availableBalance),
            drawableBalance: Number.parseFloat(account.drawableBalance),
            creditFrozen: Number.parseFloat(account.creditFrozen),
            debitFrozen: Number.parseFloat(account.debitFrozen),
            status: lowerCasedStatus,
            weight: getAccountStatuses(lowerCasedStatus).weight,
          }
        })
        .sort((a, b) => {
          const aStatusWeight = a.weight
          const bStatusWeight = b.weight
          if (aStatusWeight > bStatusWeight) {
            return -1
          }

          if (aStatusWeight < bStatusWeight) {
            return 1
          }

          return 0
        })
    },
  },
  actions: {
    ...utils.actions,
    async getAccounts({ commit }) {
      // TODO: get accountId from the user store
      const [error, accounts] = await getAccounts()
      if (error) {
        return [error, null]
      }

      commit('setAccounts', accounts)
      return [null, accounts]
    },
    async selectAccount({ state, dispatch }, accountId) {
      if (!state.collection.length) {
        const [errorGettingAccounts] = await dispatch('getAccounts')
        if (errorGettingAccounts) {
          return [errorGettingAccounts, null]
        }
      }

      const selectedAccountIndex = state.collection.findIndex((account) => account.accountId === accountId)
      if (selectedAccountIndex !== -1) {
        await dispatch(accountDetailsStore.actions.setAccount, state.collection[selectedAccountIndex], { root: true })
        return [null, state.collection[selectedAccountIndex]]
      }

      console.error('Account details not found')
      return [new Error('Account details not found')]
    },
    async editAccount({ commit, state }, { payload }) {
      commit('setStatusByItem', {
        id: payload.accountId,
        status: statusListByAccount.UPDATING,
      })
      const [errors] = await editAccount(payload)
      if (errors) {
        const fieldErrors = errors.response.data.fieldErrors
        if (fieldErrors) {
          if (fieldErrors[0].message === 'nickname.duplicated') {
            commit('setStatusByItem', {
              id: payload.accountId,
              status: statusListByAccount.NICKNAME_DUPLICATE_ERROR,
            })
            return [errors, null]
          }
        }
        commit('setStatusByItem', {
          id: payload.accountId,
          status: statusListByAccount.UPDATE_ERROR,
        })
        Message({
          message: i18n.t('account.errors.cannotEditNickname'),
          type: 'error',
        })
        return [errors, null]
      }

      const accountToUpdateIndex = state.collection.findIndex(account => account.accountId === payload.accountId)
      const newAccounts = [...state.collection]

      newAccounts[accountToUpdateIndex] = {
        ...newAccounts[accountToUpdateIndex],
        ...payload,
      }

      commit('setAccounts', newAccounts)

      commit('setStatusByItem', {
        id: payload.accountId,
        status: statusListByAccount.UPDATE_SUCCESS,
      })

      Message({
        message: i18n.t('account.errors.nicknameEdited'),
        type: 'success',
      })
    },
    async deleteAccountNickname({ commit, state }, id) {
      commit('setStatusByItem', {
        id,
        status: statusListByAccount.NICKNAME_DELETING,
      })
      const [errors] = await deleteAccountNickname(id)
      if (errors) {
        commit('setStatusByItem', {
          id,
          status: statusListByAccount.NICKNAME_DELETE_ERROR,
        })
        Message({
          message: i18n.t('account.errors.cannotDeleteNickname'),
          type: 'error',
        })
        return [errors, null]
      }

      const accountToUpdateIndex = state.collection.findIndex(account => account.accountId === id)
      const newAccounts = [...state.collection]

      newAccounts[accountToUpdateIndex] = {
        ...newAccounts[accountToUpdateIndex],
        nickname: null,
      }

      commit('setAccounts', newAccounts)

      commit('setStatusByItem', {
        id,
        status: statusListByAccount.NICKNAME_DELETE_SUCCESS,
      })

      Message({
        message: i18n.t('account.errors.nicknameDeleted'),
        type: 'success',
      })
    },
  },
  getters: {
    ...utils.getters,
    accounts: (state) => {
      return state.collection
    },
  },
}
