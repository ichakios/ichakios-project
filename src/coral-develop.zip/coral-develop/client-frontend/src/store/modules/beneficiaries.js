import {
  getBeneficiaries,
  createBeneficiary,
  deleteBeneficiary,
  updateBeneficiary,
  validateBeneficiary,
} from '@/services/beneficiary/beneficiary.service'
import utils from '@/store/utils/collection'
import { beneficiaryStatusList } from '@/constants/beneficiary'

export const statusListForBeneficiaries = {
  IDLE: 'IDLE',
  FETCHING: 'FETCHING',
  FETCH_SUCCESS: 'FETCH_SUCCESS',
  FETCH_ERROR: 'FETCH_ERROR',
}

export const statusListByBeneficiary = {
  VALIDATING: 'VALIDATING',
  VALIDATION_SUCCESS: 'VALIDATION_SUCCESS',
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  SAVING: 'SAVING',
  SAVE_SUCCESS: 'SAVE_SUCCESS',
  SAVE_ERROR: 'SAVE_ERROR',
  DELETING: 'DELETING',
  DELETE_SUCCESS: 'DELETE_SUCCESS',
  DELETE_ERROR: 'DELETE_ERROR',
}

const initialState = {
  ...utils.initialState,
  pageSize: 5,
  sortProp: 'beneficiaryStatus',
}

export default {
  namespaced: true,
  state: { ...initialState },

  mutations: {
    ...utils.mutations,
    setCollection: (state, newCollection) => {
      state.collection = newCollection.map((item) => ({
        beneficiaryStatus: 'Active',
        ...item,
      }))
    },
  },

  actions: {
    ...utils.actions,

    loadCollection: async({ commit }) => {
      commit('setStatusForCollection', statusListForBeneficiaries.FETCHING)

      const [errors, data] = await getBeneficiaries()

      if (errors) {
        commit('setStatusForCollection', statusListForBeneficiaries.FETCH_ERROR)
        return
      }

      commit('setCollection', data.content)
      commit('setStatusForCollection', statusListForBeneficiaries.FETCH_SUCCESS)
    },

    validateItem: async({ commit }, { id, ...payload }) => {
      commit('setStatusByItem', {
        id,
        status: statusListByBeneficiary.VALIDATING,
      })

      const [errors] = await validateBeneficiary(payload)

      if (errors) {
        commit('setStatusByItem', {
          id,
          status: statusListByBeneficiary.VALIDATION_ERROR,
          errors,
        })
        return
      }

      commit('setStatusByItem', {
        id,
        status: statusListByBeneficiary.VALIDATION_SUCCESS,
      })
    },

    createItem: async({ commit, state }, payload) => {
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListByBeneficiary.SAVING,
      })

      const [errors, data] = await createBeneficiary(payload)

      if (errors) {
        commit('setStatusByItem', {
          id: payload.id,
          status: statusListByBeneficiary.SAVE_ERROR,
          errors,
        })
        return
      }

      commit('setCollection', [
        data,
        ...state.collection,
      ])
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListByBeneficiary.SAVE_SUCCESS,
      })
    },

    updateItem: async({ commit, state }, payload) => {
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListByBeneficiary.SAVING,
      })

      const [errors] = await updateBeneficiary(payload)
      if (errors) {
        commit('setStatusByItem', {
          id: payload.id,
          status: statusListByBeneficiary.SAVE_ERROR,
          errors,
        })
        return
      }

      const indexToUpdate = state.collection
        .findIndex(user => user.id === payload.id)

      const collection = [...state.collection]
      collection[indexToUpdate] = {
        ...(collection[indexToUpdate] || {}),
        ...payload,
      }

      commit('setCollection', collection)
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListByBeneficiary.SAVE_SUCCESS,
      })
    },

    deleteItem: async({ commit, state, getters, dispatch }, { id }) => {
      commit('setStatusByItem', { id, status: statusListByBeneficiary.DELETING })

      const [errors] = await deleteBeneficiary(id)
      if (errors) {
        commit('setStatusByItem', { id, status: statusListByBeneficiary.DELETE_ERROR, errors })
        return
      }

      const indexToUpdate = state.collection
        .findIndex(user => user.id === id)

      const collection = [...state.collection]
      collection[indexToUpdate] = {
        ...(collection[indexToUpdate] || {}),
        beneficiaryStatus: beneficiaryStatusList.deleted.value,
      }

      commit('setCollection', collection)

      commit('setStatusByItem', { id, status: statusListByBeneficiary.DELETE_SUCCESS })

      if (!getters.collectionOnPage.length) {
        dispatch('goToPage', state.currentPage - 1)
      }
    },
  },

  getters: {
    ...utils.getters,
    getSearchStringByItemForCollection: () => (item) => `
      ${item.nickname}
      ${item.name}
      ${item.bankName}
      ${item.beneficiaryStatus}
      ${item.paymentType}
      ${item.beneficiaryAccountNumber}
      ${item.beneficiaryIban}
      ${item.swiftCode}
    `,
  },
}
