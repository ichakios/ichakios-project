import dayjs from 'dayjs'
import utils from '@/store/utils/collection'
import { getSweepRequestsForCustomer, cancelSweepRequest } from '@/services/sweeps/sweeps.service'
import { dateTableFormat } from '@/utils/formatDates'
import i18n from '@/i18n'
import { getAccounts } from '@/services/account/account.service'
import { sweepRequestStatus } from '@/constants/sweeps'

export const statusListForSweepRequests = {
  IDLE: 'IDLE',
  FETCHING: 'FETCHING',
  FETCH_SUCCESS: 'FETCH_SUCCESS',
  FETCH_ERROR: 'FETCH_ERROR',
}

export const statusListBySweepRequest = {
  CANCELING: 'CANCELING',
  CANCEL_SUCCESS: 'CANCEL_SUCCESS',
  CANCEL_ERROR: 'CANCEL_ERROR',
}

const initialState = {
  ...utils.initialState,
  sortProp: 'createdOnForDisplay',
  sortOrder: 'descending',
  dateRangeFilter: {
    startDate: null,
    endDate: null,
  },
}

export default {
  namespaced: true,
  state: { ...initialState },
  mutations: {
    ...utils.mutations,
    setFilterDateRange(state, { startDate, endDate }) {
      if (!startDate || !endDate) {
        state.dateRangeFilter = {
          startDate: null,
          endDate: null,
        }
        return
      }
      state.dateRangeFilter = { startDate, endDate }
    },
  },
  actions: {
    ...utils.actions,
    loadCollection: async({ commit }) => {
      commit('setStatusForCollection', statusListForSweepRequests.FETCHING)

      const [
        sweepRequestsResults,
        accountsDetailsResults,
      ] = await Promise.all([
        getSweepRequestsForCustomer(),
        getAccounts(),
      ])

      if (sweepRequestsResults[0] || accountsDetailsResults[0]) {
        commit('setStatusForCollection', statusListForSweepRequests.FETCH_ERROR)
        return
      }

      const sweepRequests = sweepRequestsResults[1]
      const accountsDetails = accountsDetailsResults[1]

      const findAccountByAccountId = (accountIdToFind) => accountsDetails.find(account => account.accountId === accountIdToFind)

      const sweepRequestsWithAccountDetails = sweepRequests.map((sweepRequest) => {
        const targetAccountId = sweepRequest.targetAccountId || sweepRequest.targetAccount.accountId
        const coverAccountIds = sweepRequest.coverAccountIds || sweepRequest.coverAccounts.map(coverAccount => coverAccount.accountId)
        return {
          ...sweepRequest,
          targetAccount: findAccountByAccountId(targetAccountId),
          coverAccounts: coverAccountIds.map(coverAccountId => findAccountByAccountId(coverAccountId)),
        }
      })

      commit('setCollection', sweepRequestsWithAccountDetails)
      commit('setStatusForCollection', statusListForSweepRequests.FETCH_SUCCESS)
    },
    cancel: async({ commit, state }, { reference, comments }) => {
      commit('setStatusByItem', {
        id: reference,
        status: statusListBySweepRequest.CANCELING,
      })

      const [error] = await cancelSweepRequest({ comments, reference })
      if (error) {
        commit('setStatusByItem', {
          id: reference,
          status: statusListBySweepRequest.CANCEL_ERROR,
        })
        return
      }

      const sweepRequestToCancel = state.collection.find(sweepRequest => sweepRequest.reference === reference)
      const othersSweepRequests = state.collection.filter(sweepRequest => sweepRequest.reference !== reference)

      commit('setCollection', [
        ...othersSweepRequests,
        {
          ...sweepRequestToCancel,
          status: sweepRequestStatus.CANCELED.key,
        },
      ])
      commit('setStatusByItem', {
        id: reference,
        status: statusListBySweepRequest.CANCEL_SUCCESS,
      })
    },
    dateRangeFilter({ commit }, range) {
      commit('setFilterDateRange', range)
    },
  },
  getters: {
    ...utils.getters,
    collectionForDisplay: state =>
      state.collection.map(sweepRequest => {
        return {
          ...sweepRequest,
          typeForDisplay: i18n.t(`sweepRequests.sweepTypes.${sweepRequest.type}`),
          createdOnForDisplay: dayjs(sweepRequest.createdOn).format(dateTableFormat).toUpperCase(),
          statusForDisplay: i18n.t(`sweepRequests.requestStatus.${sweepRequest.status}`),
        }
      }),
    getSearchStringByItemForCollection: () => item => {
      return `
        ${item.typeForDisplay}
        ${item.createdOnForDisplay}
        ${item.createdBy}
        ${item.statusForDisplay}
        ${item.targetAccount.name}
        ${item.targetAccount.accountId}
      `
    },
    getFilterByItemForCollection: (state) => (item) => {
      if (!(state.dateRangeFilter.startDate || state.dateRangeFilter.endDate)) {
        return true
      }

      return dayjs(item.createdOn).isBetween(
        dayjs(state.dateRangeFilter.startDate),
        dayjs(state.dateRangeFilter.endDate),
        'day',
        '[]',
      )
    },
    getItemIdentifier: () => (item) => item.reference,
  },
}
