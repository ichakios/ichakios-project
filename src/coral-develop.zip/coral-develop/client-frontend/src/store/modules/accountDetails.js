import { getTransactions } from '@/services/account/account.service'

// MODULE MAPPINGS
export const accountDetailsStore = {
  moduleName: 'accountDetails',
  state: {
    account: 'account',
    transactions: 'transactions',
  },
  actions: {
    setAccount: 'accountDetails/setAccount',
    getTransactions: 'accountDetails/getTransactions',
  },
  mutations: {
    setAccount: 'accountDetails/setAccount',
    setTransactions: 'accountDetails/setTransactions',
  },
}

const initialState = {
  account: {},
  transactions: [],
}

export default {
  namespaced: true,
  state: initialState,
  mutations: {
    setAccount(state, account) {
      state.account = { ...account }
    },
    setTransactions(state, transactions) {
      state.transactions = transactions.map((transaction, i) => {
        const amount = Number.parseFloat(transaction.amount)
        return {
          ...transaction,
          amount,
          credit: transaction.trxType === 'C' ? amount : null,
          debit: transaction.trxType === 'D' ? amount : null,
          balance: Number.parseFloat(transaction.balance),
          workingDate: transaction.wDate,
          internalId: i,
        }
      })
    },
  },
  actions: {
    async setAccount({ commit }, account) {
      commit('setAccount', account)
      return [null, account]
    },
    async getTransactions(
      { commit, state },
      { startDate, endDate },
    ) {
      if (!state.account.accountId) {
        return [null, []]
      }

      const [error, statementRecords] = await getTransactions(
        state.account.accountId,
        startDate,
        endDate,
      )

      if (error) {
        commit('setTransactions', [])
        return [error, null]
      }

      commit('setTransactions', statementRecords)
      return [null, statementRecords]
    },
  },
}
