import router from '@/router'
import { login, logout } from '@/api/user'
import uamService from '@/services/UserAccessManagementService'
import { resetRouter } from '@/router'
import { getInitStateFromStorage } from '@/store/plugins/localStoragePlugin'
import { languagesList, languages } from '@/constants/languages'
import dayjs from 'dayjs'
import i18n from '@/i18n'
import { getUserType } from '@/utils/auth'
interface LoginPayload {
  username: string,
  password: string,
  rememberMe: boolean
}
export interface Customer {
  name: string,
  description: string,
  type: null | string,
  key: string,
}
export interface StoreUserState {
  avatar: string,
  introduction: string,
  roles: string[],
  lastLogin: any,
  tasks: number,
  notifications: number,
  onboarded: boolean,
  rememberMe?: boolean,
  customers?: Customer[],
  name?: string,
  currentCustomer?: Customer,
  type?: string,
  currentLang: string,
}
const initialState: StoreUserState = {
  avatar: '',
  introduction: '',
  roles: [],
  lastLogin: dayjs(),
  tasks: 33,
  notifications: 9,
  name: undefined,
  onboarded: false,
  currentLang: languagesList[0].key,
  ...getInitStateFromStorage(),
}
export default {
  namespaced: true,
  state: { ...initialState },
  mutations: {
    SET_REMEMBER_ME: (state: StoreUserState, rememberMe: boolean) => {
      state.rememberMe = rememberMe
    },
    SET_INTRODUCTION: (state: StoreUserState, introduction: string) => {
      state.introduction = introduction
    },
    SET_NAME: (state: StoreUserState, name: string) => {
      state.name = name
    },
    SET_AVATAR: (state: StoreUserState, avatar: string) => {
      state.avatar = avatar
    },
    SET_ROLES: (state: StoreUserState, roles: string[]) => {
      state.roles = roles
    },
    SET_CUSTOMERS: (state: StoreUserState, customers: Customer[]) => {
      state.customers = customers
    },
    SET_CURRENT_CUSTOMER: (state: StoreUserState, currentCustomer: Customer) => {
      state.currentCustomer = currentCustomer
    },
    SET_TYPE: (state: StoreUserState, type: string) => {
      state.type = type
    },
    SET_CURRENT_LANG: (state: StoreUserState, currentLang: string) => {
      state.currentLang = currentLang
    },
  },
  actions: {
    // user login
    async login({ commit }: any, userInfo: LoginPayload) {
      const { username, password, rememberMe } = userInfo
      try {
        await login({ username: username.trim(), password, rememberMe })
        commit('SET_REMEMBER_ME', rememberMe)
        commit('SET_NAME', username)
        const data = await Promise.all([
          uamService.getCustomers(),
          uamService.getUserInfos(),
        ])
        const customers = data[0]
        const [, userInfos] = data[1]
        commit('SET_CUSTOMERS', customers)
        commit('SET_TYPE', getUserType(userInfos))
      } catch (error) {
        console.log('Could not log in', error)
        throw error
      }
    },
    clear({ commit }: any) {
      commit('SET_ROLES', [])
      commit('SET_CUSTOMERS', [])
      commit('SET_CURRENT_CUSTOMER', undefined)
      commit('SET_NAME', undefined)
      commit('SET_AVATAR', '')
      commit('SET_INTRODUCTION', '')
      resetRouter()
      return
    },
    resetAuth({ dispatch }: any) {
      dispatch('clear')
      router.push('/login')
    },
    // logout of the ui triggered by the user.
    async logout({ dispatch }: any) {
      try {
        await logout()
      } catch (e) {
        // Logout failed on server side. Still erase our credentials here.
      }
      dispatch('clear')
      return
    },
    updateCurrentLang: ({ commit }: any, langKey: string) => {
      i18n.locale = langKey
      if (langKey === 'ar-ae') {
        dayjs.locale('ar')
      } else {
        dayjs.locale(langKey)
      }
      commit('SET_CURRENT_LANG', langKey)
    },
  },
  getters: {
    currentLangName: (state: StoreUserState) => {
      return (languages as any)[state.currentLang].name
    },
  },
}
