import utils from '@/store/utils/collection'

export const tabList = {
  PAYMENTS: 'payments',
  DEPOSITS: 'deposits',
  FACILITIES: 'facilities',
  SWEEPS: 'sweeps',
  STANDING_INSTRUCTIONS: 'standingInstructionsRequests',
}

const initialState = {
  ...utils.initialState,
  activeTab: tabList.PAYMENTS,
}

export default {
  namespaced: true,

  state: { ...initialState },

  mutations: {
    ...utils.mutations,
    setActiveTab(state, tab) {
      state.activeTab = tab
    },
  },

  actions: {
    ...utils.actions,
    changeActiveTab({ commit }, tab) {
      commit('setActiveTab', tab)
    },
  },

  getters: {
    ...utils.getters,
  },
}
