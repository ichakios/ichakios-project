import dayjs from 'dayjs'
import utils from '@/store/utils/collection'
import { getStandingInstructionsRequests, cancelStandingInstruction, validateStandingInstruction, editStandingInstruction, createWithReferenceStandingInstruction } from '@/services/standingInstruction/standingInstruction.service'
import { dateTableFormat } from '@/utils/formatDates'
import i18n from '@/i18n'
import { statusListSI } from '@/constants/standingInstruction'
import { standingInstructionFrequencyList } from '@/constants/standingInstruction'

export const statusListForSIRequests = {
  IDLE: 'IDLE',
  FETCHING: 'FETCHING',
  FETCH_SUCCESS: 'FETCH_SUCCESS',
  FETCH_ERROR: 'FETCH_ERROR',
}
export const statusListBySIRequest = {
  CANCELING: 'CANCELING',
  CANCEL_SUCCESS: 'CANCEL_SUCCESS',
  CANCEL_ERROR: 'CANCEL_ERROR',
  VALIDATING: 'VALIDATING',
  VALIDATE_ERROR: 'VALIDATE_ERROR',
  VALIDATION_SUCCESS: 'VALIDATION_SUCCESS',
  SAVING: 'SAVING',
  SAVE_SUCCESS: 'SAVE_SUCCESS',
  SAVE_ERROR: 'SAVE_ERROR',
}

const initialState = {
  ...utils.initialState,
  sortProp: 'createdOnForDisplay',
  dateRangeFilter: {
    startDate: null,
    endDate: null,
  },
  sortOrder: 'descending',
  pageSize: 10,
}

export default {
  namespaced: true,
  state: { ...initialState },
  mutations: {
    ...utils.mutations,
    setFilterDateRange(state, { startDate, endDate }) {
      if (!startDate || !endDate) {
        state.dateRangeFilter = {
          startDate: null,
          endDate: null,
        }
        return
      }
      state.dateRangeFilter = { startDate, endDate }
    },
  },
  actions: {
    ...utils.actions,
    loadCollection: async({ commit }) => {
      commit('setStatusForCollection', statusListForSIRequests.FETCHING)
      const [errors, data] = await getStandingInstructionsRequests()
      if (errors) {
        commit('setStatusForCollection', statusListForSIRequests.FETCH_ERROR)
        return
      }
      commit('setCollection', data.content)
      commit('setStatusForCollection', statusListForSIRequests.FETCH_SUCCESS)
    },

    validateItem: async({ commit }, payload) => {
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListBySIRequest.VALIDATING,
      })

      const [errors] = await validateStandingInstruction(payload)

      if (errors) {
        commit('setStatusByItem', {
          id: payload.id,
          status: statusListBySIRequest.VALIDATE_ERROR,
          errors,
        })
        return
      }

      commit('setStatusByItem', {
        id: payload.id,
        status: statusListBySIRequest.VALIDATION_SUCCESS,
      })
    },
    createItem: async({ commit, dispatch }, payload) => {
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListBySIRequest.SAVING,
      })

      const [errors] = await createWithReferenceStandingInstruction(payload)

      if (errors) {
        commit('setStatusByItem', {
          id: payload.id,
          status: statusListBySIRequest.SAVE_ERROR,
          errors,
        })
        return
      }

      dispatch('loadCollection')

      commit('setStatusByItem', {
        id: payload.id,
        status: statusListBySIRequest.SAVE_SUCCESS,
      })
    },
    updateItem: async({ commit, dispatch }, payload) => {
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListBySIRequest.SAVING,
      })

      const [errors] = await editStandingInstruction(payload)

      if (errors) {
        commit('setStatusByItem', {
          id: payload.id,
          status: statusListBySIRequest.SAVE_ERROR,
          errors,
        })
        return
      }

      commit('setStatusByItem', {
        id: payload.id,
        status: statusListBySIRequest.SAVE_SUCCESS,
      })

      dispatch('loadCollection')
    },
    cancel: async({ commit, state }, { reference, comments }) => {
      commit('setStatusByItem', {
        id: reference,
        status: statusListBySIRequest.CANCELING,
      })

      const [error] = await cancelStandingInstruction({ comments, reference })
      if (error) {
        commit('setStatusByItem', {
          id: reference,
          status: statusListBySIRequest.CANCEL_ERROR,
        })
        return
      }

      const SIRequestToCancel = state.collection.find(SIRequest => SIRequest.reference === reference)
      const othersSIRequests = state.collection.filter(SIRequest => SIRequest.reference !== reference)

      commit('setCollection', [
        ...othersSIRequests,
        {
          ...SIRequestToCancel,
          status: statusListSI.CANCELED,
        },
      ])
      commit('setStatusByItem', {
        id: reference,
        status: statusListBySIRequest.CANCEL_SUCCESS,
      })
    },
    dateRangeFilter({ commit }, range) {
      commit('setFilterDateRange', range)
    },
  },
  getters: {
    ...utils.getters,
    collectionForDisplay: state =>
      state.collection.map(siRequest => {
        return {
          ...siRequest,
          paymentTypeForDisplay: i18n.t(`myTransfers.payments.types.${siRequest.paymentType}`),
          createdOnForDisplay: dayjs(siRequest.createdOn).format(dateTableFormat).toUpperCase(),
          startDateForDisplay: siRequest.startDate ? dayjs(siRequest.startDate).format(dateTableFormat).toUpperCase() : '',
          statusForDisplay: i18n.t(`standingInstructionsRequests.requestStatus.${siRequest.status}`),
          amount: siRequest.paymentAmount,
          endDateForDisplay: dayjs(siRequest.endDate).format(dateTableFormat).toUpperCase(),
          frequencyTypeForDisplay: siRequest.frequencyType ? i18n.t(standingInstructionFrequencyList[siRequest.frequencyType].label) : '',
        }
      }),
    getSearchStringByItemForCollection: () => item => {
      return `
        ${item.paymentTypeForDisplay}
        ${item.createdOnForDisplay}
        ${item.createdBy}
        ${item.statusForDisplay}
        ${item.startDateForDisplay}
        ${item.amount}
        ${item.paymentCurrency}
        ${item.beneficiaryAccount}
        ${item.beneficiaryIban}
        ${item.beneficiaryName}
        ${item.frequencyType}

      `
    },

    getItemIdentifier: () => (item) => item.reference,

    getFilterByItemForCollection: (state) => (item) => {
      if (!(state.dateRangeFilter.startDate || state.dateRangeFilter.endDate)) {
        return true
      }

      return dayjs(item.createdOn).isBetween(
        dayjs(state.dateRangeFilter.startDate),
        dayjs(state.dateRangeFilter.endDate),
        'day',
        '[]',
      )
    },
  },
}
