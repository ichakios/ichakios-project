import dayjs from 'dayjs'

import { dateTableFormat, getCurrentWeekDateRange } from '@/utils/formatDates'

import { paymentType } from '@/constants/payment'

import {
  getPendingPayments,
  acceptPendingPayment,
  rejectPendingPayment,
} from '@/services/payment/payment.service'

import collectionUtils from '@/store/utils/collection'

import i18n from '@/i18n'

export const statusListForPendingPayments = {
  IDLE: 'idle',
  FETCHING: 'fetching',
  FETCH_SUCCESS: 'fetch_success',
  FETCH_ERROR: 'fetch_error',
}

export const statusListForBulkPendingPayments = {
  IDLE: 'idle',
  REJECTING: 'rejecting',
  REJECT_SUCCESS: 'reject_success',
  REJECT_ERROR: 'reject_error',
  APPROVING: 'approving',
  APPROVE_SUCCESS: 'approve_success',
  APPROVE_ERROR: 'approve_error',
}

export const statusListByPendingPayment = {
  REJECTING: 'rejecting',
  REJECT_SUCCESS: 'reject_success',
  REJECT_ERROR: 'reject_error',
  APPROVING: 'approving',
  APPROVE_SUCCESS: 'approve_success',
  APPROVE_ERROR: 'approve_error',
}

const initialState = {
  ...collectionUtils.initialState,
  pageSize: 10,
  sortProp: 'createdOnForDisplay',
  sortOrder: 'descending',
  // custom state
  dateRange: getCurrentWeekDateRange(),
}

export default {
  namespaced: true,
  state: { ...initialState },
  mutations: {
    ...collectionUtils.mutations,
    setDateRange(state, dateRange) {
      state.dateRange = dateRange
    },
  },
  actions: {
    ...collectionUtils.actions,
    async loadCollection({ commit }) {
      commit('setStatusForCollection', statusListForPendingPayments.FETCHING)

      const [errorGettingPendingPayments, pendingPayments] = await getPendingPayments()
      if (errorGettingPendingPayments) {
        commit('setStatusForCollection', statusListForPendingPayments.FETCH_ERROR)
        return
      }

      commit('setCollection', pendingPayments)
      commit('setStatusForCollection', statusListForPendingPayments.FETCH_SUCCESS)
    },
    async bulkApprove({ commit, state }, { references = [] }) {
      commit('setStatusForBulk', statusListForBulkPendingPayments.APPROVING)

      const response = await Promise.all(references.map(ref => acceptPendingPayment(ref)))
      if (response.some(res => !!res[0])) {
        commit('setStatusForBulk', statusListForBulkPendingPayments.APPROVE_ERROR)
        return
      }

      const newCollection = state.collection.filter(c => !references.includes(c.reference))

      commit('setCollection', newCollection)
      commit('setStatusForBulk', statusListForBulkPendingPayments.APPROVE_SUCCESS)
    },
    async approve({ commit, state }, { id }) {
      commit('setStatusByItem', {
        id,
        status: statusListByPendingPayment.APPROVING,
      })

      const reference = (state.collection.find(c => c.id === id) || {}).reference
      const [errorAcceptingPendingPayment] = await acceptPendingPayment(reference)
      if (errorAcceptingPendingPayment) {
        commit('setStatusByItem', {
          id,
          status: statusListByPendingPayment.APPROVE_ERROR,
        })
        return
      }

      const newCollection = state.collection.filter(c => c.id !== id)

      commit('setCollection', newCollection)
      commit('setStatusByItem', {
        id,
        status: statusListByPendingPayment.APPROVE_SUCCESS,
      })
    },
    async bulkReject({ commit, state }, { options = [] }) {
      commit('setStatusForBulk', statusListForBulkPendingPayments.REJECTING)

      const response = await Promise.all(options.map(({ reference, comments }) => rejectPendingPayment({
        paymentId: reference,
        comments,
      })))
      if (response.some(res => !!res[0])) {
        commit('setStatusForBulk', statusListForBulkPendingPayments.REJECT_ERROR)
        return
      }

      const newCollection = state.collection.filter(c => !options.some(({ reference }) => reference === c.reference))

      commit('setCollection', newCollection)
      commit('setStatusForBulk', statusListForBulkPendingPayments.REJECT_SUCCESS)
    },
    async reject({ commit, state }, { id, comments }) {
      commit('setStatusByItem', {
        id,
        status: statusListByPendingPayment.REJECTING,
      })

      const reference = (state.collection.find(c => c.id === id) || {}).reference
      const [errorRejectingPendingPayment] = await rejectPendingPayment({
        paymentId: reference,
        comments,
      })
      if (errorRejectingPendingPayment) {
        commit('setStatusByItem', {
          id,
          status: statusListByPendingPayment.REJECT_ERROR,
        })
        return
      }

      const newCollection = state.collection.filter(c => c.id !== id)

      commit('setCollection', newCollection)
      commit('setStatusByItem', {
        id,
        status: statusListByPendingPayment.REJECT_SUCCESS,
      })
    },
    filter({ commit }, { dateRange }) {
      commit('setDateRange', dateRange)
    },
  },
  getters: {
    ...collectionUtils.getters,
    collectionForDisplay: (state) => {
      return state.collection.map((item) => {
        const itemForDisplay = {
          ...item,
          transactionModeForDisplay: i18n.t(`pendingPayments.transferModeList.${item.paymentType}`),
          createdOnForDisplay: dayjs(item.createdOn).format(dateTableFormat).toUpperCase(),
          paymentAmountForDisplay: item.paymentAmount,
          purposeCodeForDisplay: item.purposeCode ? i18n.t((`transfer.form.purpose.options.${item.purposeCode}`)) : '',
        }

        if (item.paymentType === paymentType.local) {
          itemForDisplay.accountNumberForDisplay = item.beneficiaryIban
        } else {
          itemForDisplay.accountNumberForDisplay = item.beneficiaryAccount
        }

        return itemForDisplay
      })
    },
    // Override for custom search
    getSearchStringByItemForCollection: () => (item) => {
      return `
        ${item.transactionModeForDisplay}
        ${item.createdOnForDisplay}
        ${item.reference}
        ${item.debitAccount}
        ${item.beneficiaryAccount}
        ${item.beneficiaryName}
        ${item.createdBy}
        ${item.purposeCodeForDisplay}
        ${item.paymentCurrency}
        ${item.paymentAmountForDisplay}
      `
    },
    getFilterByItemForCollection: (state) => (item) => {
      if (!(state.dateRange || []).length) {
        return true
      }

      return dayjs(item.createdOn).isBetween(
        dayjs(state.dateRange[0]).startOf('day'),
        dayjs(state.dateRange[1]).endOf('day'),
        'day',
        '[]',
      )
    },
  },
}
