import dayjs from 'dayjs'

import collectionUtils from '@/store/utils/collection'
import { getPendingDrawdowns, approveDrawdownRequest, rejectDrawdownRequest } from '@/services/facilities/facilities.service'
import { drawdownTypeList } from '@/constants/facilities'
import i18n from '@/i18n'
import { dateTableFormat, getCurrentWeekDateRange } from '@/utils/formatDates'

export const statusListForPendingDrawdowns = {
  IDLE: 'idle',
  FETCHING: 'fetching',
  FETCH_SUCCESS: 'fetch_success',
  FETCH_ERROR: 'fetch_error',
}

export const statusListByPendingDrawdown = {
  REJECTING: 'rejecting',
  REJECT_SUCCESS: 'reject_success',
  REJECT_ERROR: 'reject_error',
  APPROVING: 'approving',
  APPROVE_SUCCESS: 'approve_success',
  APPROVE_ERROR: 'approve_error',
}
const initialState = {
  ...collectionUtils.initialState,
  sortProp: 'drawdownTypeForDisplay',

  // custom state
  dateRange: getCurrentWeekDateRange(),
}

export default {
  namespaced: true,
  state: { ...initialState },
  mutations: {
    ...collectionUtils.mutations,
  },
  actions: {
    ...collectionUtils.actions,
    /**
     * Action to Load all pending drawdown request
     */
    async loadCollection({ commit }, dateRange) {
      if (!dateRange) {
        return
      }
      commit('setStatusForCollection', statusListForPendingDrawdowns.FETCHING)
      const startDate = dayjs(dateRange[0]).format('YYYY-MM-DD')
      const endDate = dayjs(dateRange[1]).format('YYYY-MM-DD')
      const [errorGettingPendingDrawdowns, pendingDrawdowns] = await getPendingDrawdowns(startDate, endDate)
      if (errorGettingPendingDrawdowns) {
        commit('setStatusForCollection', statusListForPendingDrawdowns.FETCH_ERROR)
        return
      }
      commit('setCollection', pendingDrawdowns)
      commit('setStatusForCollection', statusListForPendingDrawdowns.FETCH_SUCCESS)
    },
    /**
     * Action to Approve drawdown request
     */
    async approve({ commit, state }, { reference }) {
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingDrawdown.APPROVING,
      })
      const [errorAcceptingPendingPayment] = await approveDrawdownRequest({ reference })
      if (errorAcceptingPendingPayment) {
        commit('setStatusByItem', {
          id: reference,
          status: statusListByPendingDrawdown.APPROVE_ERROR,
        })
        return
      }
      const newCollection = state.collection.filter(c => c.reference !== reference)
      commit('setCollection', newCollection)
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingDrawdown.APPROVE_SUCCESS,
      })
    },
    /**
     * Action to Approve drawdown request
     */
    async reject({ commit, state }, { reference, comments }) {
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingDrawdown.REJECTING,
      })
      const [errorAcceptingPendingPayment] = await rejectDrawdownRequest({ reference, comments })
      if (errorAcceptingPendingPayment) {
        commit('setStatusByItem', {
          id: reference,
          status: statusListByPendingDrawdown.REJECT_ERROR,
        })
        return
      }
      const newCollection = state.collection.filter(c => c.reference !== reference)
      commit('setCollection', newCollection)
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingDrawdown.REJECT_SUCCESS,
      })
    },
  },

  getters: {
    ...collectionUtils.getters,
    collectionForDisplay: (state) => {
      return state.collection.map((item) => {
        const itemForDisplay = {
          ...item,
          drawdownTypeForDisplay: i18n.t(`pendingFacilities.drawdownTypeList.${drawdownTypeList[item.facilityType]}`),
          createdOnForDisplay: dayjs(item.createdOn).format(dateTableFormat).toUpperCase(),
          amountForDisplay: item.amount,
          id: item.reference,
        }
        return itemForDisplay
      })
    },
    // Override for custom search
    getSearchStringByItemForCollection: () => (item) => {
      return `
        ${item.drawdownTypeForDisplay}
        ${item.createdOnForDisplay}
        ${item.facilityId}
        ${item.createdBy}
        ${item.purpose}
        ${item.amountForDisplay}
      `
    },
    getFilterByItemForCollection: (state) => (item) => {
      if (!(state.dateRange || []).length) {
        return true
      }

      return dayjs(item.createdOn).isBetween(
        dayjs(state.dateRange[0]),
        dayjs(state.dateRange[1]),
        'day',
        '[]',
      )
    },
  },
}
