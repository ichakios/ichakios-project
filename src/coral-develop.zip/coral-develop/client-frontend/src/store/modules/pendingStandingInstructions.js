import dayjs from 'dayjs'

import { dateTableFormat, getCurrentWeekDateRange } from '@/utils/formatDates'
import collectionUtils from '@/store/utils/collection'
import {
  getPendingStandingInstructions,
  rejectPendingStandingInstruction,
  approvePendingStandingInstruction,
} from '@/services/standingInstruction/standingInstruction.service'
import {
  standingInstructionFrequencyList,
  chargeBearerList,
} from '@/constants/standingInstruction'
import i18n from '@/i18n'
import { paymentType } from '@/constants/payment'

export const statusListForPendingStandingInstructions = {
  IDLE: 'idle',
  FETCHING: 'fetching',
  FETCH_SUCCESS: 'fetch_success',
  FETCH_ERROR: 'fetch_error',
}

export const statusListForBulkPendingStandingInstructions = {
  IDLE: 'idle',
  REJECTING: 'rejecting',
  REJECT_SUCCESS: 'reject_success',
  REJECT_ERROR: 'reject_error',
  APPROVING: 'approving',
  APPROVE_SUCCESS: 'approve_success',
  APPROVE_ERROR: 'approve_error',
}

export const statusListByPendingStandingInstruction = {
  REJECTING: 'rejecting',
  REJECT_SUCCESS: 'reject_success',
  REJECT_ERROR: 'reject_error',
  APPROVING: 'approving',
  APPROVE_SUCCESS: 'approve_success',
  APPROVE_ERROR: 'approve_error',
}

const initialState = {
  ...collectionUtils.initialState,
  sortProp: 'createdOnForDisplay',
  sortOrder: 'descending',
  pageSize: 10,

  // custom state
  dateRange: getCurrentWeekDateRange(),
}

export default {
  namespaced: true,
  state: { ...initialState },
  mutations: {
    ...collectionUtils.mutations,
    setDateRange(state, dateRange) {
      state.dateRange = dateRange
    },
  },
  actions: {
    ...collectionUtils.actions,
    async loadCollection({ commit }) {
      commit('setStatusForCollection', statusListForPendingStandingInstructions.FETCHING)

      const [error, pendingStandingInstructions] = await getPendingStandingInstructions()
      if (error) {
        commit('setStatusForCollection', statusListForPendingStandingInstructions.FETCH_ERROR)
        return
      }

      commit('setCollection', pendingStandingInstructions)
      commit('setStatusForCollection', statusListForPendingStandingInstructions.FETCH_SUCCESS)
    },
    filter({ commit }, { dateRange }) {
      commit('setDateRange', dateRange)
    },
    async reject({ commit, state }, { reference, comments }) {
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingStandingInstruction.REJECTING,
      })

      const [error] = await rejectPendingStandingInstruction({
        reference,
        comments,
      })
      if (error) {
        commit('setStatusByItem', {
          id: reference,
          status: statusListByPendingStandingInstruction.REJECT_ERROR,
        })
        return
      }

      commit('setCollection', state.collection.filter(c => c.reference !== reference))
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingStandingInstruction.REJECT_SUCCESS,
      })
    },
    async bulkReject({ commit, state }, { options = [] }) {
      commit('setStatusForBulk', statusListForBulkPendingStandingInstructions.REJECTING)

      const response = await Promise.all(options.map(({ reference, comments }) => rejectPendingStandingInstruction({
        reference,
        comments,
      })))
      if (response.some(res => !!res[0])) {
        commit('setStatusForBulk', statusListForBulkPendingStandingInstructions.REJECT_ERROR)
        return
      }

      const newCollection = state.collection.filter(c => !options.some(({ reference }) => reference === c.reference))

      commit('setCollection', newCollection)
      commit('setStatusForBulk', statusListForBulkPendingStandingInstructions.REJECT_SUCCESS)
    },
    async approve({ commit, state }, { reference }) {
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingStandingInstruction.APPROVING,
      })

      const [error] = await approvePendingStandingInstruction({
        reference,
      })
      if (error) {
        commit('setStatusByItem', {
          id: reference,
          status: statusListByPendingStandingInstruction.APPROVE_ERROR,
        })
        return
      }

      commit('setCollection', state.collection.filter(c => c.reference !== reference))
      commit('setStatusByItem', {
        id: reference,
        status: statusListByPendingStandingInstruction.APPROVE_SUCCESS,
      })
    },
    async bulkApprove({ commit, state }, { references = [] }) {
      commit('setStatusForBulk', statusListForBulkPendingStandingInstructions.APPROVING)

      const response = await Promise.all(references.map(reference => approvePendingStandingInstruction({ reference })))
      if (response.some(res => !!res[0])) {
        commit('setStatusForBulk', statusListForBulkPendingStandingInstructions.APPROVE_ERROR)
        return
      }

      const newCollection = state.collection.filter(c => !references.includes(c.reference))

      commit('setCollection', newCollection)
      commit('setStatusForBulk', statusListForBulkPendingStandingInstructions.APPROVE_SUCCESS)
    },
  },
  getters: {
    ...collectionUtils.getters,
    collectionForDisplay: (state) => {
      return state.collection.map((item) => {
        const itemForDisplay = {
          ...item,
          paymentTypeForDisplay: i18n.t(`myTransfers.payments.types.${item.paymentType}`),
          createdOnForDisplay: dayjs(item.createdOn).format(dateTableFormat).toUpperCase(),
          statusForDisplay: i18n.t(`standingInstructionsRequests.requestStatus.${item.status}`),
          startDateForDisplay: item.startDate ? dayjs(item.startDate).format(dateTableFormat).toUpperCase() : '',
          frequencyTypeForDisplay: item.frequencyType ? i18n.t(standingInstructionFrequencyList[item.frequencyType].label) : '',
          endDateForDisplay: item.endDate ? dayjs(item.endDate).format(dateTableFormat).toUpperCase() : '',

        }

        if (itemForDisplay.paymentType === paymentType.local && itemForDisplay.chargeBearer) {
          itemForDisplay.chargeBearerForDisplay = i18n.t(chargeBearerList[itemForDisplay.chargeBearer].label)
        }

        return itemForDisplay
      })
    },
    // Override for custom search
    getSearchStringByItemForCollection: () => (item) => {
      return `
        ${item.paymentTypeForDisplay}
        ${item.createdOnForDisplay}
        ${item.statusForDisplay}
        ${item.startDateForDisplay}
        ${item.frequencyTypeForDisplay}
        ${item.debitAmount}
        ${item.title || ''}
        ${item.createdBy}
        ${item.reference}
        ${item.beneficiaryAccount}
        ${item.beneficiaryEmail}
        ${item.beneficiaryIban}
        ${item.beneficiaryName}
        ${item.beneficiaryPhone}
      `
    },
    getItemIdentifier: () => (item) => item.reference,
    getFilterByItemForCollection: (state) => (item) => {
      if (!(state.dateRange || []).length) {
        return true
      }

      return dayjs(item.createdOn).isBetween(
        dayjs(state.dateRange[0]),
        dayjs(state.dateRange[1]),
        'day',
        '[]',
      )
    },
  },
}
