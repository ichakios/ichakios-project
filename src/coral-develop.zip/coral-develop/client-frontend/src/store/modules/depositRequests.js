import dayjs from 'dayjs'
import { depositStatus } from '@/constants/deposits'
import { getAllDeposits, cancelDeposit } from '@/services/deposits/depositRequest.service'
import { dateTableFormat } from '@/utils/formatDates'
import { featureCodeList } from '@/constants/deposits'
import i18n from '@/i18n'
import utils from '@/store/utils/collection'

export const statusListForDeposits = {
  IDLE: 'idle',
  FETCHING: 'fetching',
  FETCH_SUCCESS: 'fetch_success',
  FETCH_ERROR: 'fetch_error',
}

export const statusListByDeposit = {
  IDLE: 'idle',
  VALIDATING: 'validating',
  VALIDATION_SUCCESS: 'validation_success',
  VALIDATION_ERROR: 'validation_error',
  SAVING: 'saving',
  SAVE_SUCCESS: 'save_success',
  SAVE_ERROR: 'save_error',
  CANCELING: 'canceling',
  CANCEL_SUCCESS: 'cancel_success',
  CANCEL_ERROR: 'cancel_error',
}

const initialState = {
  ...utils.initialState,
  dateRangeFilter: {
    startDate: null,
    endDate: null,
  },
  pageSize: 50,
  sortProp: 'createdOnForDisplay',
  sortOrder: 'descending',
}

export default {
  namespaced: true,

  state: {
    ...initialState,
    depositAccounts: [],
    depositRequests: [],
    depositAccountsLoading: false,
    accounts: [],
  },

  mutations: {
    ...utils.mutations,
    setFilterDateRange(state, { startDate, endDate }) {
      if (!startDate || !endDate) {
        state.dateRangeFilter = {
          startDate: null,
          endDate: null,
        }
        return
      }
      state.dateRangeFilter = { startDate, endDate }
    },
  },

  actions: {
    ...utils.actions,

    async loadCollection({ commit }) {
      commit('setStatusForCollection', statusListForDeposits.FETCHING)
      const [errors, data] = await getAllDeposits()
      if (errors) {
        commit('setStatusForCollection', statusListForDeposits.FETCH_ERROR)
        return
      }
      commit('setCollection', data)
      commit('setStatusForCollection', statusListForDeposits.FETCH_SUCCESS)
    },

    dateRangeFilter({ commit }, range) {
      commit('setFilterDateRange', range)
    },

    async cancel({ commit, state, getters }, { reference, comments }) {
      commit('setStatusByItem', {
        id: reference,
        status: statusListByDeposit.CANCELING,
      })

      const selectedDepositForCancel = getters.getItem(reference)
      const [errors] = await cancelDeposit({
        reference,
        type: selectedDepositForCancel.featureCode,
        comments,
      })

      if (errors) {
        commit('setStatusByItem', {
          id: reference,
          status: statusListByDeposit.CANCEL_ERROR,
          errors,
        })
        return
      }

      const canceledItem = state.collection.find(item => item.reference === reference)
      const otherItems = state.collection.filter(item => item.reference !== reference)

      commit('setCollection', [
        ...otherItems,
        {
          ...canceledItem,
          status: depositStatus.CANCELED,
        },
      ])
      commit('setStatusByItem', {
        id: reference,
        status: statusListByDeposit.CANCEL_SUCCESS,
      })
    },
  },

  getters: {
    ...utils.getters,

    getItemByReference: (state) => (reference) => {
      const item = state.collection.find((x) => x.reference === reference)
      return item || null
    },

    collectionForDisplay: (state) => {
      return state.collection.map((item) => {
        const itemForDisplay = {
          ...item,
          featureCodeForDisplay: i18n.t(`pendingDeposits.featureCodeList.${item.featureCode}`),
          createdOnForDisplay: dayjs(item.createdOn).format(dateTableFormat).toUpperCase(),
          approvedOnForDisplay: dayjs(item.approvedOn).format(dateTableFormat).toUpperCase(),
          statusForDisplay: i18n.t(`myTransfers.deposits.statuses.${item.status}`),
        }

        if (item.featureCode === featureCodeList.INVESTMENT_DEPOSIT_REQUEST) {
          itemForDisplay.amountForDisplay = item.amount
        } else if (item.featureCode === featureCodeList.INVESTMENT_DEPOSIT_WITHDRAWAL) {
          itemForDisplay.amountForDisplay = item.withdrawalAmount
        }

        return itemForDisplay
      })
    },

    getSearchStringByItemForCollection: () => (item) => {
      return `
        ${item.featureCodeForDisplay}
        ${item.amountForDisplay},
        ${item.createdBy},
        ${item.createdOnForDisplay},
        ${item.currency},
        ${item.featureCodeForDisplay},
        ${item.nominatedAccount},
        ${item.depositAccount},
        ${item.status},
      `
    },

    getFilterByItemForCollection: (state) => (item) => {
      if (!(state.dateRangeFilter.startDate || state.dateRangeFilter.endDate)) {
        return true
      }

      return dayjs(item.createdOn).isBetween(
        dayjs(state.dateRangeFilter.startDate),
        dayjs(state.dateRangeFilter.endDate),
        'day',
        '[]',
      )
    },
    getItemIdentifier: () => (item) => item.reference,
  },
}
