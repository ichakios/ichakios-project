import utils from '@/store/utils/collection'
import { getSweeps, createSweep, editSweep, cancelSweep } from '@/services/sweeps/sweeps.service'
import i18n from '@/i18n'

export const statusListForSweeps = {
  IDLE: 'IDLE',
  FETCHING: 'FETCHING',
  FETCH_SUCCESS: 'FETCH_SUCCESS',
  FETCH_ERROR: 'FETCH_ERROR',
}

export const statusListBySweep = {
  SAVING: 'SAVING',
  SAVE_SUCCESS: 'SAVE_SUCCESS',
  SAVE_ERROR: 'SAVE_ERROR',
  CANCELING: 'CANCELING',
  CANCEL_SUCCESS: 'CANCEL_SUCCESS',
  CANCEL_ERROR: 'CANCEL_ERROR',
}

const initialState = {
  ...utils.initialState,
  sortProp: 'accountName',
}

const getCoverAccountInformations = item => {
  if (!item) {
    return null
  }

  return `${item.currencyID} ${item.accountId}`
}

const getCoverAccountName = item => {
  if (!item) {
    return null
  }
  return item.name
}

const getSecondCoverAccount = item => {
  if (!item) {
    return null
  }
  return {
    name: item.name,
    informations: `${item.currencyID} ${item.accountId}`,
  }
}

// Export state, mutations, actions & getters
export default {
  namespaced: true,
  state: { ...initialState },
  mutations: {
    ...utils.mutations,
  },
  actions: {
    ...utils.actions,
    loadCollection: async({ commit }) => {
      // Set the collection status to FETCHING
      commit('setStatusForCollection', statusListForSweeps.FETCHING)

      // Make the call to the API through the service

      const [sweepsErrors, sweepsResults] = await getSweeps()

      // If there is an API error
      if (sweepsErrors) {
        // Set the collection status to FETCH_ERROR
        commit('setStatusForCollection', statusListForSweeps.FETCH_ERROR)
        return
      }

      // Update the collection
      commit('setCollection', sweepsResults)
      commit('setStatusForCollection', statusListForSweeps.FETCH_SUCCESS)
    },
    createItem: async({ commit, state }, payload) => {
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListBySweep.SAVING,
      })
      const [errors] = await createSweep(payload)

      if (errors) {
        commit('setStatusByItem', {
          id: payload.id,
          status: statusListBySweep.SAVE_ERROR,
          errors,
        })
        return
      }

      commit('setCollection', [payload, ...state.collection])
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListBySweep.SAVE_SUCCESS,
      })
    },
    editItem: async({ commit, state }, payload) => {
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListBySweep.SAVING,
      })

      const [errors] = await editSweep(payload)
      if (errors) {
        commit('setStatusByItem', {
          id: payload.id,
          status: statusListBySweep.SAVE_ERROR,
          errors,
        })
        return
      }

      const itemsToKeep = state.collection.filter(item => item.id !== payload.id)
      commit('setCollection', [payload, ...itemsToKeep])
      commit('setStatusByItem', {
        id: payload.id,
        status: statusListBySweep.SAVE_SUCCESS,
      })
    },
    cancelItem: async({ commit, state, getters, dispatch }, sweepId) => {
      commit('setStatusByItem', {
        id: sweepId,
        status: statusListBySweep.CANCELING,
      })

      const selectedSweepForCancelation = getters.getItem(sweepId)
      const [errors] = await cancelSweep(selectedSweepForCancelation)
      if (errors) {
        commit('setStatusByItem', {
          id: sweepId,
          status: statusListBySweep.CANCEL_ERROR,
          errors,
        })
        return
      }

      commit('setCollection', state.collection.filter((item) => item.id !== sweepId))
      commit('setStatusByItem', {
        id: sweepId,
        status: statusListBySweep.CANCEL_SUCCESS,
      })

      // If the item was the last on the page
      // Go to the previous page
      if (!getters.collectionOnPage.length) {
        dispatch('goToPage', state.currentPage - 1)
      }
    },
  },
  getters: {
    ...utils.getters,
    collectionForDisplay: state =>
      state.collection.map(sweep => {
        return {
          ...sweep,
          amountForDisplay: sweep.amount,
          accountName: sweep.targetAccount.name,
          accountInformation: `${sweep.targetAccount.currencyID} ${sweep.targetAccount.accountId}`,
          coverAccountName: getCoverAccountName(sweep.coverAccounts[0]),
          coverAccountInformation: getCoverAccountInformations(sweep.coverAccounts[0]),
          secondCoverAccount: getSecondCoverAccount(sweep.coverAccounts[1]),
          sweepTypeToSearch: i18n.t(`sweeps.sweepTypes.${sweep.type}`),
        }
      }),
    getSearchStringByItemForCollection: () => item =>
      `
        ${item.accountName}
        ${item.accountInformation}
        ${item.coverAccountName}
        ${item.coverAccountInformation}
        ${item.coverAccountToSearch}
        ${item.targetAccount.accountId}
        ${item.sweepTypeToSearch}
        ${item.amountForDisplay}`,
  },
}
