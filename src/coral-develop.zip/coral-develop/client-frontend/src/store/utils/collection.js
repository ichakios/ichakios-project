export const sortOrderList = {
  ASCENDING: 'ascending',
  DESCENDING: 'descending',
}

export default {
  initialState: {
    collection: [],
    statusForCollection: 'IDLE',
    statusByItem: {},
    currentPage: 1,
    pageSize: 10,
    searchTerm: '',
    sortProp: 'name',
    sortOrder: sortOrderList.ASCENDING,
    statusForBulk: 'IDLE',
  },

  mutations: {
    setCollection: (state, newCollection) => {
      state.collection = [...newCollection]
    },
    setStatusForCollection: (state, status) => {
      state.statusForCollection = status
    },
    setStatusByItem: (state, { id, status, errors = [] }) => {
      state.statusByItem = {
        ...state.statusByItem,
        [id]: {
          status,
          errors,
          updatedAt: new Date(),
        },
      }
    },
    setCurrentPage: (state, page) => {
      state.currentPage = Math.max(1, page)
    },
    setSearchTerm: (state, searchTerm) => {
      state.searchTerm = searchTerm || ''
    },
    setSort: (state, { prop, order }) => {
      state.sortProp = prop || state.sortProp
      state.sortOrder = order || sortOrderList.ASCENDING
      state.currentPage = 1
    },
    setStatusForBulk(state, status) {
      state.statusForBulk = status
    },
  },

  actions: {
    goToPage: ({ commit }, page) => {
      commit('setCurrentPage', page)
    },

    search: ({ commit }, searchTerm) => {
      commit('setSearchTerm', searchTerm)
    },

    sort: ({ state, commit }, { prop, order, group }) => {
      if (prop !== state.sortProp || order) {
        const propToChange = prop || (!group || group.includes(state.sortProp) ? state.sortProp : group[0])
        commit('setSort', { prop: propToChange, order })
        return
      }

      if (state.sortOrder === sortOrderList.ASCENDING) {
        commit('setSort', { order: sortOrderList.DESCENDING })
        return
      }

      commit('setSort', { order: sortOrderList.ASCENDING })
    },

    updateItemInCollection: ({ commit, state, getters }, { id, attrs = {}}) => {
      const newCollection = [...state.collection]
      const itemIndex = newCollection.findIndex(item => getters.getItemIdentifier(item) === id)
      if (itemIndex < 0) {
        return
      }
      newCollection[itemIndex] = { ...newCollection[itemIndex], ...attrs }
      commit('setCollection', newCollection)
    },
  },

  getters: {
    getSortOrder: (state) => (props = []) => {
      if (!props.length) {
        return state.sortOrder
      }
      return props.indexOf(state.sortProp) !== -1 ? state.sortOrder : null
    },
    getStatusByItem: (state) => (id) => {
      const statusObject = state.statusByItem[id]
      if (!statusObject || !statusObject.status) {
        return null
      }
      return statusObject.status
    },
    getErrorsByItem: (state) => (id) => {
      const statusObject = state.statusByItem[id]
      if (!statusObject || !statusObject.errors) {
        return null
      }
      return statusObject.errors
    },
    getItem: (state, getters) => (id) => {
      const item = state.collection.find((x) => getters.getItemIdentifier(x) === id)
      return item || null
    },
    getItemForDisplay: (state, getters) => (id) => {
      const item = getters.collectionForDisplay.find((x) => getters.getItemIdentifier(x) === id)
      return item || null
    },
    getEnumSortFunction: (state) => (enumKeys) => {
      return (a, b) => state.sortOrder === sortOrderList.ASCENDING
        ? enumKeys.indexOf(a[state.sortProp]) - enumKeys.indexOf(b[state.sortProp])
        : enumKeys.indexOf(b[state.sortProp]) - enumKeys.indexOf(a[state.sortProp])
    },
    sortStrings: (state) => (a, b) => {
      const predicate = state.sortOrder === sortOrderList.ASCENDING ? 1 : -1
      return (JSON.stringify(a) || '').localeCompare(JSON.stringify(b)) * predicate
    },
    sortNumbers: (state) => (a, b) => {
      const predicate = state.sortOrder === sortOrderList.ASCENDING ? 1 : -1
      return (a - b) * predicate
    },
    getDefaultSortFunction: (state, getters) => () => {
      return (a, b) => {
        const aValue = a[state.sortProp]
        const bValue = b[state.sortProp]
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          return getters.sortNumbers(aValue, bValue)
        }
        return getters.sortStrings(aValue, bValue)
      }
    },
    collectionFiltered: (state, getters) => {
      return getters.collectionForDisplay
        .filter(getters.getFilterByItemForCollection)
        .filter((item) => {
          if (!state.searchTerm) return true
          const searchString = getters.getSearchStringByItemForCollection(item).toLowerCase()
          return searchString.indexOf(state.searchTerm.trim().toLowerCase()) !== -1
        })
        .sort(getters.getSortFunctionForCollection())
    },
    collectionFilteredCount: (state, getters) => {
      return getters.collectionFiltered.length
    },
    collectionOnPage: (state, getters) => {
      const startIndexToShow = (state.currentPage - 1) * state.pageSize
      const endIndex = startIndexToShow + state.pageSize
      return getters.collectionFiltered
        .slice(startIndexToShow, endIndex)
    },

    // Override for custom collection display
    collectionForDisplay: (state) => {
      return state.collection
    },

    // Override for custom item identifier
    getItemIdentifier: () => (item) => {
      return item.id
    },

    // Override for custom search
    getSearchStringByItemForCollection: () => (item) => {
      return JSON.stringify(item)
    },

    // Override for custom sorting
    getSortFunctionForCollection: (state, getters) => () => {
      return getters.getDefaultSortFunction()
    },

    // Override for custom filter
    getFilterByItemForCollection: () => (item) => {
      return !!item
    },
  },
}
