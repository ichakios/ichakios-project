import { getFromStorage } from '@/utils/auth'
import { StoreState } from '@/store/getters'
import { Customer, StoreUserState } from '../modules/user'

/**
 * Returns the list of keys to watch.
 *
 * @type {{tokenKey: string, rememberMeKey: string, currentCustomerKey: string, customersKey: string}}
 */
const LOCAL_STORAGE_KEYS = {
  usernameKey: 'user/SET_NAME',
  rememberMeKey: 'user/SET_REMEMBER_ME',
  customersKey: 'user/SET_CUSTOMERS',
  currentCustomerKey: 'user/SET_CURRENT_CUSTOMER',
  typeKey: 'user/SET_TYPE',
}

/**
 * Returns the plugin to add to the store configuration.
 *
 * @returns {function(...[*]=)}
 */
export default function localStoragePlugin() {
  return (store: any) => {
    store.subscribe((mutation: any, state: StoreState) => {
      if (Object.values(LOCAL_STORAGE_KEYS).includes(mutation.type)) {
        if (!mutation.payload || mutation.payload.length === 0) {
          // remove item
          localStorage.removeItem(mutation.type)
          sessionStorage.removeItem(mutation.type)
          return
        }

        const storage = state.user.rememberMe ? localStorage : sessionStorage
        storage.setItem(mutation.type, JSON.stringify(mutation.payload))

        // special case for the default customer
        if (mutation.type === LOCAL_STORAGE_KEYS.customersKey) {
          const customers = mutation.payload
          if (customers && customers.length !== 0) {
            const defaultCustomer = getDefaultCustomer(customers)
            store.commit(LOCAL_STORAGE_KEYS.currentCustomerKey, defaultCustomer)
          }
        }
      }
    })
  }
}

export type StorageContent = Partial<StoreUserState>;

/**
 * Creates an object that contains the elements stored in the storage.
 */
export const getInitStateFromStorage = (): StorageContent => {
  return {
    rememberMe: getFromStorage(LOCAL_STORAGE_KEYS.rememberMeKey),
    name: getFromStorage(LOCAL_STORAGE_KEYS.usernameKey),
    customers: getFromStorage(LOCAL_STORAGE_KEYS.customersKey),
    currentCustomer: getFromStorage(LOCAL_STORAGE_KEYS.currentCustomerKey),
    type: getFromStorage(LOCAL_STORAGE_KEYS.typeKey),
  }
}

/**
 * Gets the default customer among a list of customer. The current algorithm is simply taken the first one when
 * ordered in alphabetical order.
 *
 * @param customers the list of customers
 * @returns the choosen customer to be the default
 */
const getDefaultCustomer = (customers: Customer[]): Customer | undefined => {
  const first = customers.map(c => c.name).sort()[0] // take the first element for now
  return customers.find(c => c.name === first)
}
