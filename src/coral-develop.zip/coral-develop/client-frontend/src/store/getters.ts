import { StoreUserState } from './modules/user'

export interface StoreState {
  user: StoreUserState
}

const getters = {
  sidebar: (state: any) => state.app.sidebar,
  size: (state: any) => state.app.size,
  device: (state: any) => state.app.device,
  visitedViews: (state: any) => state.tagsView.visitedViews,
  cachedViews: (state: any) => state.tagsView.cachedViews,
  avatar: (state: StoreState) => state.user.avatar,
  username: (state: StoreState) => state.user.name,
  introduction: (state: StoreState) => state.user.introduction,
  roles: (state: StoreState) => state.user.roles,
  customers: (state: StoreState) => state.user.customers,
  currentCustomer: (state: StoreState) => state.user.currentCustomer,
  permission_routes: (state: any) => state.permission.routes,
  errorLogs: (state: any) => state.errorLog.logs,
}
export default getters
