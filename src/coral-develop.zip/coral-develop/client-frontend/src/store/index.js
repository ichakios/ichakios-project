import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'
import localStoragePlugin from './plugins/localStoragePlugin'
import accountDetails from './modules/accountDetails'
import accounts from './modules/accounts'
import sweeps from './modules/sweeps'
import app from './modules/app'
import beneficiaries from './modules/beneficiaries'
import deposits from './modules/deposits'
import depositRequests from './modules/depositRequests'
import facilitiesRequests from './modules/facilitiesRequests'
import myTransfers from './modules/myTransfers'
import payments from './modules/payments'
import pendingDeposits from './modules/pendingDeposits'
import pendingPayments from './modules/pendingPayments'
import pendingSweeps from './modules/pendingSweeps'
import pendingStandingInstructions from './modules/pendingStandingInstructions'
import permission from './modules/permission'
import roles from './modules/roles'
import settings from './modules/settings'
import tagsView from './modules/tagsView'
import user from './modules/user'
import users from './modules/users'
import pendingDrawdowns from './modules/pendingDrawdowns'
import standingInstructions from './modules/standingInstructions'
import sweepRequests from './modules/sweepRequests'
import standingInstructionsRequests from './modules/standingInstructionsRequests'

Vue.use(Vuex)

export const modules = {
  accountDetails,
  accounts,
  app,
  beneficiaries,
  deposits,
  depositRequests,
  facilitiesRequests,
  myTransfers,
  payments,
  pendingDeposits,
  pendingPayments,
  pendingSweeps,
  pendingStandingInstructions,
  pendingDrawdowns,
  permission,
  roles,
  settings,
  tagsView,
  standingInstructions,
  sweeps,
  user,
  users,
  sweepRequests,
  standingInstructionsRequests,
}

const store = new Vuex.Store({
  plugins: [localStoragePlugin()],
  modules,
  getters,
})

export default store
