import Layout from '@/layout'

const othersRouter = {
  path: '/others-services',
  component: Layout,
  redirect: '/others-services/user-management',
  meta: {
    title: 'routes.otherServices',
    icon: 'Other',
  },
  children: [
    {
      path: 'user-management',
      component: () => import('@/views/OtherServices/UserManagement'),
      name: 'Others/UserManagement',
      meta: { title: 'routes.userManagement', icon: 'peoples', affix: true },
    },
    {
      path: 'authority-matrix',
      component: () => import('@/views/OtherServices/AuthorityMatrix'),
      name: 'Others/AuthorityMatrix',
      meta: { title: 'routes.authorityMatrix', icon: 'lock', affix: true },
    },
    {
      path: 'sweeps',
      component: () => import('@/views/OtherServices/Sweeps'),
      name: 'Others/Sweeps',
      meta: { title: 'routes.sweeps', icon: 'lock', affix: true },
    },
    {
      path: 'standing-instructions',
      component: () => import('@/views/OtherServices/StandingInstructions'),
      name: 'Others/StandingInstructions',
      meta: { title: 'routes.standingInstructions', affix: true },
    },
  ],
}

export default othersRouter
