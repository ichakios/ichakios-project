import Layout from '@/layout'

const paymentRouter = {
  path: '/payments',
  component: Layout,
  redirect: '/payments/new',
  meta: {
    title: 'routes.payments',
    icon: 'Transfers',
  },
  children: [
    {
      path: 'new',
      component: () => import('@/views/Payment/NewPayment'),
      name: 'Payment/New',
      meta: { title: 'routes.newPayment', icon: 'documentation', affix: true },
    },
    {
      path: 'beneficiary-management',
      component: () => import('@/views/Payment/BenificiaryManagement'),
      name: 'Payment/BeneficiaryManagement',
      meta: { title: 'routes.beneficiaryList', icon: 'peoples', affix: true },
    },
  ],
}

export default paymentRouter
