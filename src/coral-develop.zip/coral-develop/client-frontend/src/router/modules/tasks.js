import Layout from '@/layout'

const tasksRouter = {
  path: '/tasks',
  component: Layout,
  children: [
    {
      path: '',
      component: () => import('@/views/Tasks'),
      name: 'Tasks',
      meta: { title: 'routes.tasks', icon: 'Visa', affix: true },
    },
  ],
}

export default tasksRouter
