import Layout from '@/layout'
import { userTypes } from '@/constants/user'

const onboardingRouter = {
  path: '/onboarding',
  component: Layout,
  redirect: '/onboarding',
  hidden: true,
  meta: {
    title: 'routes.onboardingRequests',
    icon: 'Onboarding',
  },
  children: [
    {
      path: 'requests',
      component: () => import('@/views/Onboarding'),
      name: 'Onboarding',
      meta: {
        title: 'routes.onboardingRequests',
        affix: true,
        userTypes: [userTypes.ZAND_RELATIONSHIP_MANAGER],
      },
    },
  ],
}

export default onboardingRouter
