import Layout from '@/layout'

const messagesRouter = {
  path: '/messages',
  component: Layout,
  children: [
    {
      path: '',
      component: () => import('@/views/Messages'),
      name: 'Messages',
      meta: { title: 'routes.messages', icon: 'Messages', affix: true },
    },
  ],
}

export default messagesRouter
