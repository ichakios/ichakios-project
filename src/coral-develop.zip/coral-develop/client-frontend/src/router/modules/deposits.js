import Layout from '@/layout'

const depositsRouter = {
  path: '/deposits',
  component: Layout,
  children: [
    {
      path: '',
      component: () => import('@/views/Deposits'),
      name: 'Deposits',
      meta: { title: 'routes.deposits', icon: 'Deposit', affix: true },
    },
  ],
}

export default depositsRouter
