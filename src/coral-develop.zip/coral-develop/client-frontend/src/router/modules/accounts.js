import Layout from '@/layout'

const accountsRouter = {
  path: '/account',
  component: Layout,
  redirect: '/account',
  meta: {
    title: 'routes.account',
    icon: 'Account',
    withSeparator: true,
  },
  children: [
    {
      path: '',
      component: () => import('@/views/Account'),
      name: 'Account',
      meta: { title: 'routes.accounts', affix: true },
    },
    {
      path: 'new',
      component: () => import('@/views/NewAccount'),
      name: 'NewAccount',
      meta: { title: 'routes.newAccount', affix: true },
    },
    {
      path: 'close',
      component: () => import('@/views/CloseAccount'),
      name: 'CloseAccount',
      meta: { title: 'routes.closeAccount', affix: true },
    },
    {
      hidden: true,
      path: ':accountId',
      component: () => import('@/views/AccountDetails'),
      name: 'AccountDetails',
      meta: { title: 'routes.accountDetails', affix: true, activeMenu: '/account' },
    },
  ],
}

export default accountsRouter
