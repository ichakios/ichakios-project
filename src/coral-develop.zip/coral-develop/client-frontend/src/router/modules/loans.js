import Layout from '@/layout'
import guaranteesRouter from './guarantees'

const loansRouter = {
  path: '/loans',
  component: Layout,
  meta: { title: 'routes.loans', icon: 'Loans', affix: true },
  children: [
    {
      path: '',
      component: () => import('@/views/Loans'),
      name: 'Loans',
      meta: { title: 'routes.loansOverview' },
      hidden: true,
    },
    guaranteesRouter,
  ],
}

export default loansRouter
