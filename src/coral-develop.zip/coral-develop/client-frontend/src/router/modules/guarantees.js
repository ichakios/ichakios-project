import i18n from '@/i18n'
import { guaranteeTypesList } from '@/constants/guarantees'

const guaranteesRouter = {
  path: 'guarantees',
  component: () => import('@/views/Guarantees'),
  meta: { title: 'routes.guarantees' },
  hidden: true,
  children: [
    {
      path: '',
      name: 'guarantees',
      component: () => import('@/views/Guarantees/Overview'),
      meta: { title: 'routes.guaranteesOverview', activeMenu: '/loans' },
    },
    {
      path: ':type',
      component: () => import('@/views/Guarantees/ListByType'),
      name: 'guaranteesType',
      meta: {
        title: (route) => [
          'routes.guaranteesType',
          { type: i18n.t((Object.values(guaranteeTypesList).find(x => x.url === route.params.type) || {}).label) },
        ],
        activeMenu: '/loans',
      },
    },
  ],
}

export default guaranteesRouter
