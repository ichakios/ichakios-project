import Layout from '@/layout'

const myTransfersRouter = {
  path: '/transfer-status',
  component: Layout,
  meta: {
    withSeparator: true,
  },
  children: [
    {
      path: '',
      component: () => import('@/views/TransferStatus'),
      name: 'myTransfers',
      meta: {
        title: 'routes.transferStatus',
        icon: 'Transaction Status',
        affix: true,
      },
    },
  ],
}

export default myTransfersRouter
