<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
import dayjs from 'dayjs'

export default {
  name: 'App',
  computed: {
    locale() {
      return this.$i18n.locale
    },
  },
  watch: {
    locale() {
      this.udpateLocale()
    },
  },
  mounted() {
    this.udpateLocale()
  },
  methods: {
    udpateLocale() {
      dayjs.locale(this.$i18n.locale.split('-')[0])
      const localeIsAR = ['ar-ae'].includes(this.$i18n.locale)
      const htmlEl = document.documentElement
      htmlEl.dir = (localeIsAR ? 'rtl' : 'ltr')
      htmlEl.lang = this.$i18n.locale
    },
  },
}
</script>
