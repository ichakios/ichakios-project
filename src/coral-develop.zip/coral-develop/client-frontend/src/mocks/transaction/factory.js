import { Factory } from 'miragejs'
import { random, finance, date, lorem } from 'faker'
import dayjs from 'dayjs'

const currency = ['EUR', 'AED', 'GBP'] // Some random currency to play with
const transactionType = ['Credit', 'Debit']

export const transactionFactory = Factory.extend({
  accountDetails: {
    accountID: '0150100001438402',
    accountName: 'SIT TEST Account',
    clientID: '000014384',
    productName: 'Corporate Current Account',
    currencyID: () => random.arrayElement(currency),
    currencyName: 'UAE DIRHAMS',
    address: '4/c block a',
  },
  statementRecords: new Array(random.number({ min: 5, max: 300 })).fill(null).map(() => {
    const workingDate = date.recent()
    const valueDate = dayjs(workingDate).add(1, 'day').toISOString()
    return {
      trxReferenceNo: '34',
      channelRefID: '',
      narrationID: 'FD0',
      workingDate,
      valueDate,
      chequeID: 'V',
      chequeDate: date.recent(),
      description: lorem.sentence(),
      trxType: () => random.arrayElement(transactionType),
      amount: () => finance.amount(100, 500000, 2),
      foreignAmount: 0.00,
      balance: () => finance.amount(100, 500000, 2),
    }
  }),
})
