import { Server, Model } from 'miragejs'

/* eslint-disable @typescript-eslint/no-unused-vars */
import { accountFactory, getAllAccounts } from './account'
import { beneficiaryFactory, getAllBeneficiaries } from './beneficiary'
import {
  standingInstructionFactory,
  standingInstructionRoutes,
} from './standingInstruction'
import {
  pendingStandingInstructionFactory,
  pendingStandingInstructionRoutes,
} from './pendingStandingInstruction'
import {
  guaranteeFactory,
  guaranteeRoutes,
} from './guarantee'
import { transactionFactory } from './transaction'
/* eslint-enabled */

export function makeServer({ environment = 'development' } = {}) {
  const server = new Server({
    environment,

    models: {
      account: Model,
      beneficiary: Model,
      transaction: Model,
      standingInstruction: Model,
      guarantee: Model,
      pendingStandingInstruction: Model,
    },

    factories: {
      account: accountFactory,
      beneficiary: beneficiaryFactory,
      transaction: transactionFactory,
      standingInstruction: standingInstructionFactory,
      guarantee: guaranteeFactory,
      pendingStandingInstruction: pendingStandingInstructionFactory,
    },

    seeds(serv) {
      serv.createList('account', 20)
      serv.createList('beneficiary', 20)
      serv.createList('standingInstruction', 20)
      serv.createList('guarantee', 100)
      serv.createList('pendingStandingInstruction', 23)
      serv.db.accounts.forEach(
        (accountDetails) => serv.create('transaction', { accountDetails }),
      )
    },

    routes() {
      this.urlPrefix = process.env.VUE_APP_CORAL_BASE_API
      this.namespace = '/api'

      /**
       * FIXME
       * Uncomment the below to allow mirage passthrough
       * if commented the actual channel api will be called
       * uncomment to use mock data
	     * this.get('/v1/accounts/transactions/date-range', getAccountTransactionList)
       */

      // this.get('/v1/accounts', getAllAccounts)
      // this.get('/v1/beneficiaries', getAllBeneficiaries)

      // standingInstructionRoutes(this)
      // pendingStandingInstructionRoutes(this)

      guaranteeRoutes(this)

      // Routes whitelist
      // these routes will override the ones declared upward
      this.passthrough()

      this.namespace = '/sso'
      this.passthrough()
    },
  })

  return server
}
