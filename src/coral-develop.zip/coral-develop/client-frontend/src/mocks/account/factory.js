import { Factory } from 'miragejs'
import { random, finance } from 'faker'

const currencies = ['AED']
const accountStatusList = ['Deceased', 'Active', 'InActive']

export const accountFactory = Factory.extend({
  totalBalance: () => parseInt(finance.amount(10000, 1000000000, 2), 10),
  availableBalance: () => parseInt(finance.amount(10000, 1000000000, 2), 10),
  drawableBalance: () => parseInt(finance.amount(10000, 1000000000, 2), 10),
  accountId: () => finance.account(),
  productID: 'CCAAED',
  name: () => finance.accountName(),
  currencyID: () => random.arrayElement(currencies),
  status: () => random.arrayElement(accountStatusList),
  clientID: '000082671',
  iban: () => finance.iban(),
  openDate: '2020-01-22 14:28:00',
  productType: 'AE',
  productDesc: 'Corporate Current Account',
  groupCode: '',
  econoActCode: '1200',
  countryCode: 'AE',
  accountType: 'C',
  debitFrozen: '0',
  creditFrozen: '0',
})
