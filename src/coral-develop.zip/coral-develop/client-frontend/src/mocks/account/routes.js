import dayjs from 'dayjs'

export const getAllAccounts = (schema) => {
  const accounts = schema.accounts.all()

  return {
    'header': [
      {
        'name': 'totalBalance',
        'label': 'Total Balance',
        'type': 'number',
      },
      {
        'name': 'availableBalance',
        'label': 'Available Balance',
        'type': 'number',
      },
      {
        'name': 'drawableBalance',
        'type': 'number',
      },
      {
        'name': 'accountID',
        'type': 'number',
      },
      {
        'name': 'productID',
        'type': 'string',
      },
      {
        'name': 'name',
        'type': 'string',
      },
      {
        'name': 'currencyID',
        'type': 'number',
      },
      {
        'name': 'clientID',
        'type': 'number',
      },
      {
        'name': 'iban',
        'type': 'number',
      },
      {
        'name': 'openDate',
        'type': 'date',
      },
      {
        'name': 'productType',
        'type': 'string',
      },
      {
        'name': 'productDesc',
        'type': 'string',
      },
      {
        'name': 'groupCode',
        'type': 'string',
      },
      {
        'name': 'countryCode',
        'type': 'number',
      },
      {
        'name': 'econoActCode',
        'type': 'number',
      },
      {
        'name': 'accountType',
        'type': 'string',
      },
      {
        'name': 'debitFrozen',
        'type': 'number',
      },
      {
        'name': 'creditFrozen',
        'type': 'number',
      },
    ],
    response: accounts.models,
  }
}

export const getAccountTransactionList = (schema, request) => {
  const { accountID } = request.params
  const transactions = schema.transactions.findBy({ accountId: accountID })
  const response = {
    requestDateTime: dayjs().toISOString(),
    logId: '029f4e19-f40f-43e9-b3e2-643b7feb70ac',
    status: {
      code: 'MSG-000000',
      severity: 'Success',
      statusMessage: 'Success',
    },
    content: transactions,
  }
  return response
}
