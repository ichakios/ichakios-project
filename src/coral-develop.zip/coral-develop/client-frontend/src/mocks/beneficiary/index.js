export { beneficiaryFactory } from './factory'
export * from './routes'
