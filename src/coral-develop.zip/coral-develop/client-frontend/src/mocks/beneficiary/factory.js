import { Factory } from 'miragejs'
import { random, finance, internet } from 'faker'

const accountStatusList = ['DECEASED', 'ACTIVE', 'INACTIVE', 'DELETED']
const paymentTypes = ['INTRA', 'LOCAL']

export const beneficiaryFactory = Factory.extend({
  customerId: () => finance.account(),
  name: () => finance.accountName(),
  fromAccount: () => finance.account(),
  nickname: () => finance.accountName(),
  paymentType: () => random.arrayElement(paymentTypes),
  beneficiaryAccountNumber: () => finance.account(),
  beneficiaryIban: () => finance.iban(),
  beneficiaryStatus: () => random.arrayElement(accountStatusList),
  bankCountry: 'UAE',
  bic: '',
  beneficiaryAddress: null,
  bankName: '',
  bankAddress: '',
  email: () => internet.email(),
  otherReferenceCode: null,
  phone: '4312',
  createdBy: 'user1',
  createdOn: '2020-05-14T07:56:19.408154Z',
})
