export const getAllBeneficiaries = (schema) => {
  const beneficiaries = schema.beneficiaries.all()

  return {
    content: beneficiaries.models,
  }
}
