import { random } from 'faker'
import { standingInstructionStatusList } from '@/constants/standingInstruction'

export const standingInstructionRoutes = (server) => {
  server.get('/v1/standing-instructions', getAll)
  server.post('/v1/standing-instructions/validate', validate)
  server.post('/v1/standing-instructions', create)
  server.post('/v1/standing-instructions/:id', update)
  server.post('/v1/standing-instructions/:id/hold', hold)
  server.post('/v1/standing-instructions/:id/resume', resume)
  server.post('/v1/standing-instructions/:id/cancel', cancel)
}

const getAll = (schema) => {
  const standingInstructions = schema.standingInstructions.all()

  return {
    content: standingInstructions.models,
  }
}

const validate = () => {
  return {}
}

const create = (schema, request) => {
  const attrs = JSON.parse(request.requestBody)

  return schema.db.standingInstructions
    .insert({
      status: 'ACTIVE',
      referenceId: random.number(),
      ...attrs,
    })
}

const update = (schema, request) => {
  const attrs = JSON.parse(request.requestBody)

  return schema.db.standingInstructions
    .update({ id: request.params.id }, { ...attrs })[0]
}

const hold = (schema, request) => {
  return schema.db.standingInstructions
    .update({ id: request.params.id }, { status: standingInstructionStatusList.HOLD.value })[0]
}

const resume = (schema, request) => {
  return schema.db.standingInstructions
    .update({ id: request.params.id }, { status: standingInstructionStatusList.ACTIVE.value })[0]
}

const cancel = (schema, request) => {
  return schema.db.standingInstructions
    .update({ id: request.params.id }, { status: standingInstructionStatusList.CANCELED.value })[0]
}
