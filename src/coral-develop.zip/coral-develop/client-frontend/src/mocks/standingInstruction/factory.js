import { Factory } from 'miragejs'
import { random, finance, date } from 'faker'
import {
  standingInstructionStatusList,
  standingInstructionFrequencyList,
  repeatUntilList,
  chargeBearerList,
} from '@/constants/standingInstruction'

export const standingInstructionFactory = Factory.extend({
  nickname: () => finance.accountName(),
  paymentType: 'OWN_ACCOUNT',
  referenceId: () => random.number(),
  status: () => random.arrayElement(Object.keys(standingInstructionStatusList)),
  amount: () => parseInt(finance.amount(), 10),
  currency: 'AED',
  startDate: () => date.past(),
  frequency: () => random.arrayElement(Object.keys(standingInstructionFrequencyList)),
  chargeBearer: () => random.arrayElement(Object.keys(chargeBearerList)),
  repeatUntil: () => random.arrayElement(Object.keys(repeatUntilList)),
  repeatCount: () => random.number({ min: 10, max: 50 }),
  repeatEndDate: () => date.future(),
  from: {
    accountId: '0310100000067103',
    name: 'Omar',
    nickname: 'Omar',
    status: 'Active',
  },
  to: {
    accountId: '0310100000067102',
    name: 'Omar',
    nickname: 'Omar',
    status: 'Active',
  },
})
