export const pendingStandingInstructionRoutes = (server) => {
  server.get('/v1/payments/standing-instructions/pending', getPendingStandingInstructions)

  server.patch('/v1/payments/standing-instructions/:reference/approve', approve)
  server.patch('/v1/payments/standing-instructions/:reference/reject', reject)
}

const getPendingStandingInstructions = (schema) => {
  const pendingStandingInstructions = schema.pendingStandingInstructions.all()

  return {
    content: pendingStandingInstructions.models,
  }
}

const approve = () => {
  return {}
}

const reject = () => {
  return {}
}
