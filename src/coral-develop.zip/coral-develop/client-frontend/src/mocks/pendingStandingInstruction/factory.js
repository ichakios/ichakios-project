import { Factory } from 'miragejs'
import { random, finance, internet, name, phone, lorem } from 'faker'
import {
  standingInstructionStatusList,
  standingInstructionFrequencyList,
  chargeBearerList,
} from '@/constants/standingInstruction'
import { paymentType } from '@/constants/payment'
import dayjs from 'dayjs'

const purposeCodes = ['ACM', 'AES', 'AFA', 'AFL', 'ALW', 'ATS', 'BON', 'CBP', 'CCP', 'CEA', 'CEL', 'CHC', 'CIN', 'COM', 'COP', 'CRP', 'DCP', 'DIF', 'DIL', 'DIV', 'DLA', 'DLF', 'DLL', 'DOE', 'DSA', 'DSF', 'DSL', 'EDU', 'EMI', 'EOS', 'FAM', 'FDA', 'FDL', 'FIA', 'FIL', 'FIS', 'FSA', 'FSL', 'GDE', 'GDI', 'GDS', 'GMS', 'GOS', 'GRI', 'IFS', 'IGD', 'IGT', 'IID', 'INS', 'IOD', 'IOL', 'IPC', 'IPO', 'IRP', 'IRW', 'ISH', 'ISL', 'ISS', 'ITS', 'LAS', 'LDL', 'LDS', 'LEA', 'LEL', 'LIP', 'LLA', 'LLL', 'LNC', 'LND', 'MCR', 'MWI', 'MWO', 'MWP', 'OAT', 'OTS', 'OVT', 'PEN', 'PIN', 'PIP', 'PMS', 'POR', 'POS', 'PPA', 'PPL', 'PRP', 'PRR', 'PRS', 'PRW', 'RDA', 'RDL', 'RDS', 'REA', 'REL', 'RFS', 'RLS', 'RNT', 'SAA', 'SAL', 'SCO', 'SLA', 'SLL', 'STR', 'STS', 'SVI', 'SVO', 'SVP', 'TAX', 'TCP', 'TCR', 'TCS', 'TKT', 'TOF', 'TTS', 'UFP', 'UTL', 'XAT']

export const pendingStandingInstructionFactory = Factory.extend({
  actionType: 'CREATE',
  approvedBy: null,
  approvedOn: null,
  attachmentKey: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
  attachmentName: 'string',
  beneficiaryAccount: () => finance.account(),
  beneficiaryAddress: 'string',
  beneficiaryBankAddress: 'string',
  beneficiaryBankBic: 'string',
  beneficiaryBankCode: 'string',
  beneficiaryBankCountryCode: 'string',
  beneficiaryBankName: 'string',
  beneficiaryEmail: () => Math.random() >= 0.75 ? internet.email() : null,
  beneficiaryIban: () => finance.iban(),
  beneficiaryName: () => Math.random() >= 0.75 ? name.findName() : null,
  beneficiaryPhone: () => phone.phoneNumber(),
  chargeBearer: () => random.arrayElement(Object.keys(chargeBearerList)),
  createdBy: () => name.findName(),
  createdOn: () => dayjs().format('YYYY-MM-DD'),
  debitAccount: finance.account(),
  debitAmount: () => parseFloat(finance.amount()),
  debitAmountFixed: true,
  debitCurrency: 'EAD',
  endDate: () => dayjs().add(2, 'day').format('YYYY-MM-DD'),
  featureCode: null,
  frequencyType: () => random.arrayElement(Object.keys(standingInstructionFrequencyList)),
  hostReference: null,
  numberOfInstallments: 0,
  paymentAmount: () => parseFloat(finance.amount()),
  paymentCurrency: 'EAD',
  paymentInterval: 0,
  paymentType: () => random.arrayElement(Object.values(paymentType)),
  processId: null,
  purposeCode() { return this.paymentType !== 'OWN' ? random.arrayElement(purposeCodes) : null },
  reference: () => random.uuid(),
  rejectReason: null,
  remarks: () => lorem.sentence(),
  startDate: () => dayjs().format('YYYY-MM-DD'),
  status: () => random.arrayElement(Object.keys(standingInstructionStatusList)),
  title: () => Math.random() >= 0.75 ? finance.accountName() : null,
})
