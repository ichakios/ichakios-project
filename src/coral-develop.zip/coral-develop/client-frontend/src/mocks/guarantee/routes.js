import { finance, date } from 'faker'
import dayjs from 'dayjs'
import { guaranteeTypesList } from '@/constants/guarantees'

export const guaranteeRoutes = (server) => {
  server.get('/v1/guarantees/overview', getGuaranteesOverview)
  server.get('/v1/guarantees/:type', getGuarantees)
  server.post('/v1/guarantees/validate', validate)
  server.post('/v1/guarantees', create)
  server.post('/v1/guarantees/:id', update)
}

const getGuaranteesOverview = (schema) => {
  return {
    renewalDate: dayjs(date.future()).format('YYYY-MM-DD'),
    currency: 'AED',
    approvedLimit: 97000,
    utilizedLimit: 14000,
    availableLimit: 83000,
    guaranteesTypes: Object.keys(guaranteeTypesList).map((type) => {
      const guarantees = schema.guarantees.where({ type })
      const utilizedLimit = Math.round(guarantees.models.reduce((acc, cur) => acc + parseFloat(cur.amount), 0))
      const availableLimit = 83000
      const approvedLimit = utilizedLimit + availableLimit

      return {
        referenceId: finance.account(),
        type,
        approvedLimit,
        utilizedLimit,
        availableLimit,
        tenor: Math.floor(Math.random() * 20),
        openDate: dayjs(date.past()).format('YYYY-MM-DD'),
      }
    }),
  }
}

const getGuarantees = (schema, request) => {
  const guarantees = schema.guarantees.where({ type: request.params.type })
  const utilizedLimit = Math.round(guarantees.models.reduce((acc, cur) => acc + parseFloat(cur.amount), 0))
  const availableLimit = 83000
  const approvedLimit = utilizedLimit + availableLimit
  return {
    renewalDate: dayjs(date.future()).format('YYYY-MM-DD'),
    currency: 'AED',
    approvedLimit,
    utilizedLimit,
    availableLimit,
    guarantees: guarantees.models,
  }
}

const validate = () => {
  return {}
}

const create = (schema, request) => {
  const attrs = JSON.parse(request.requestBody)

  return schema.db.guarantees
    .insert({
      referenceId: finance.account(),
      status: 'ACTIVE',
      ...attrs,
    })
}

const update = (schema, request) => {
  const attrs = JSON.parse(request.requestBody)

  return schema.db.guarantees
    .update({ id: request.params.id }, { ...attrs })[0]
}
