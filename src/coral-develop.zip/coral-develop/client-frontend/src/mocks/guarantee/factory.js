import { Factory } from 'miragejs'
import dayjs from 'dayjs'
import { random, finance, date, address, name } from 'faker'
import { guaranteeTypesList, guaranteeStatusList } from '@/constants/guarantees'

export const guaranteeFactory = Factory.extend({
  referenceId: () => finance.account(),
  type: () => random.arrayElement(Object.keys(guaranteeTypesList)),
  status: () => random.arrayElement(Object.keys(guaranteeStatusList)),
  amount: () => parseInt(finance.amount(), 10),
  currency: 'AED',
  issueDate: () => dayjs(date.past()).format('YYYY-MM-DD'),
  expiryDate: () => dayjs(date.future()).format('YYYY-MM-DD'),
  debitAccount: {
    accountId: '0310100000067103',
    name: 'Omar',
    nickname: 'Omar',
    status: 'Active',
  },
  beneficiaryName: () => name.findName(),
  beneficiaryAddress: () => `${address.streetAddress()}, ${address.zipCode()}, ${address.city()}`,
  beneficiaryCountryCode: 'AE',
  tradeLicense: () => finance.account(),
  contractReference: () => finance.account(),
  attachments: [],
})
