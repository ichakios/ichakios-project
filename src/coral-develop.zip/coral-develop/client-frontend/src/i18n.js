import Vue from 'vue'
import VueI18n from 'vue-i18n'
import elUiEnLocale from 'element-ui/lib/locale/lang/en'
import elUiArLocale from 'element-ui/lib/locale/lang/ar'
import enLocale from '@/locales/en'
import arLocale from '@/locales/ar-ae'

Vue.use(VueI18n)

export default new VueI18n({
  locale: process.env.VUE_APP_I18N_LOCALE || 'en',
  fallbackLocale: process.env.VUE_APP_I18N_FALLBACK_LOCALE || 'en',
  messages: {
    en: {
      ...elUiEnLocale,
      ...enLocale,
    },
    'ar-ae': {
      ...elUiArLocale,
      ...arLocale,
    },
  },
})
