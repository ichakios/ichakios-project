import { service } from '@/utils/request'

export function login(data) {
  return service({
    url: '/sso/login',
    method: 'post',
    auth: {
      username: data.username,
      password: data.password,
    },
    maxRedirects: 0,
  })
}

export function logout() {
  return service({
    url: '/sso/logout',
    method: 'post',
    maxRedirects: 0,
  })
}
