
import Vue from 'vue'
import 'normalize.css/normalize.css' // a modern alternative to CSS resets
import '@/styles/index.scss' // global css

import App from './App.vue'
import store from './store'
import router from './router'
import { makeServer } from './mocks/server'
import './icons' // icon
import './permission' // permission control

import Vuelidate from 'vuelidate'
import Nl2br from 'vue-nl2br'
import i18n from '@/i18n'
import '@/config/dayjs'
import '@/config/i18n-iso-countries'
import '@/config/element-ui'
import '@/config/vue-currency-input'

Vue.use(Vuelidate)
Vue.component('nl2br', Nl2br)
Vue.config.productionTip = false

// MIRAGEJS CONFIG
makeServer()

new Vue({
  el: '#app',
  router,
  store,
  i18n,
  render: h => h(App),
})
