<template>
  <div class="sidebar-container" :class="{'has-logo': showLogo}">
    <SidebarLogo
      v-if="showLogo"
      :collapse="isCollapse"
    />
    <app-scrollbar id="app-sidemenu__wrapper">
      <el-menu
        :default-active="activeMenu"
        :collapse="isCollapse"
        :background-color="variables.menuBg"
        :text-color="variables.menuText"
        :unique-opened="false"
        :collapse-transition="false"
        mode="vertical"
      >
        <slot />
      </el-menu>
    </app-scrollbar>
    <slot name="footer" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import SidebarLogo from './SidebarLogo'
import variables from '@/styles/_settings/index.scss'
import AppScrollbar from '@/components/Scrollbar/scrollbar'

export default {
  components: { SidebarLogo, AppScrollbar },
  data() {
    return {
      i18n: this.$i18n,
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
    ]),
    activeMenu() {
      const route = this.$route
      const { meta, path } = route
      // if set path, the sidebar will highlight the path you set
      if (meta.activeMenu) {
        return meta.activeMenu
      }
      return path
    },
    showLogo() {
      return this.$store.state.settings.sidebarLogo
    },
    variables() {
      return variables
    },
    isCollapse() {
      return !this.sidebar.opened
    },
  },
}
</script>

<style lang="scss">
@import "@/styles/_settings/index.scss";

#app-sidemenu__wrapper {
  width: 100%;
  height: 100%;
  overflow: auto;
}
</style>
