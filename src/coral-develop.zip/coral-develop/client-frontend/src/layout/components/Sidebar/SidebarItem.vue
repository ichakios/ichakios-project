<template>
  <el-tooltip
    effect="dark"
    :content="title"
    :placement="lang.key === 'ar-ae' ? 'left' : 'right'"
    :disabled="sidemenuIsOpened || hasSubitems || isNest"
  >
    <div :class="hasSubitems && sidemenuIsOpened ? 'app-sidemenu__item has--subitems' : 'app-sidemenu__item'">
      <svg-icon
        :icon-class="icon"
        class="app-sidemenu__item__icon"
      />
      <div class="app-sidemenu__item__title">
        <span>
          {{ title }}
        </span>
      </div>
      <el-badge
        v-if="isTaskItem && tasks && tasks > 0"
        :value="tasks"
        :max="99"
      />
    </div>
  </el-tooltip>
</template>
<script>
import { getPendingTasksCount } from '@/services/history/history.service'
/**
 * Interval time needed to refresh the api call to fetch number of tasks
 */
const TASK_INTERVAL_POLLING = 10000
export default {
  name: 'MenuItem',
  props: {
    icon: {
      type: String,
      default: '',
    },
    title: {
      type: String,
      default: '',
    },
    hasSubitems: {
      type: Boolean,
      default: false,
    },
    isNest: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      lang: this.$i18n.locale,
      sidemenuIsOpened: this.$store.state.app.sidebar.opened,
      tasks: 0,
      intervalId: null,
    }
  },
  computed: {
    isTaskItem() {
      return this.title === 'routes.tasks'
    },
  },
  mounted() {
    if (this.isTaskItem) {
      this.intervalId = setInterval(() => {
        this.loadTasksCount()
      }, TASK_INTERVAL_POLLING)
    }
  },
  destroyed() {
    clearInterval(this.intervalId)
  },
  methods: {
    async loadTasksCount() {
      const [error, data] = await getPendingTasksCount()
      if (error) {
        this.$message({
          message: this.$t('tasks.tasksCountError'),
          type: 'warning',
        })
      } else {
        this.tasks = data
      }
    },
  },
}
</script>

<style lang="scss">
  @import "@/styles/_settings/index.scss";
  .el-badge__content {
    border-radius: 15px;
    padding: 0 6px;
    text-align: center;
    border: 1px solid #FFFFFF;
    background-color: $--color-primary;
  }
  .app-sidemenu__item {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    width: 100%;
    height: 100%;
    font-size: 16px;
    font-weight: 500;
    padding-bottom: 2px;
    &.has--subitems {
      margin-right: 15px;
    }
    .svg-icon {
      flex-shrink: 0;
      color: $iconColor;
    }
    &__title {
      overflow: hidden;
      text-overflow: ellipsis;
      transition: opacity 0.3s ease;
    }
    &__badge {
      .el-badge__content {
        background-color: transparent;
        color: darken($iconColor, 5%);
      }
    }
  }
  .app-wrapper.openSidebar {
    .svg-icon{
      margin-left: 0;
    }
  }
  .app-sidemenu__item__title{
    opacity: 1;
  }
  .app-wrapper.hideSidebar {
    #app & .submenu-title-noDropdown .el-tooltip .svg-icon {
      margin-left: 16px;
      margin-right: 16px;
    }
    .app-sidemenu__item__title{
      opacity: 0;
    }
  }
  .nest-menu .app-sidemenu__item {
    &__title {
      font-size: 14px;
    }
    .svg-icon{
      display: none;
    }
  }
</style>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";
  .el-menu-item.is-active .app-sidemenu__item .svg-icon {
    color: $--color-primary;
  }
  .el-submenu.is-active .app-sidemenu__item .svg-icon {
    color: $--color-primary;
  }
</style>
