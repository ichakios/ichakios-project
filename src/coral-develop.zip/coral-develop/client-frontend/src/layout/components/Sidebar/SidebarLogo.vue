<template>
  <div
    class="sidebar-logo-container"
    :class="{'collapse': collapse}"
  >
    <transition name="sidebarLogoFade">
      <!-- COLLAPSE -->
      <router-link
        key="collapse"
        class="sidebar-logo-link"
        to="/"
      >
        <img
          :src="logo"
          class="sidebar-logo"
        >
      </router-link>
    </transition>
  </div>
</template>

<script>
import logo from '@/assets/zand-logo.png'

export default {
  name: 'SidebarLogo',
  props: {
    collapse: {
      type: Boolean,
      required: true,
    },
  },
  data() {
    return {
      title: 'Zand',
      logo: logo,
    }
  },
}
</script>

<style lang="scss" scoped>
@import "@/styles/_settings/index.scss";

.sidebarLogoFade-enter-active {
  transition: opacity 1.5s;
}

.sidebarLogoFade-enter,
.sidebarLogoFade-leave-to {
  opacity: 0;
}

#app .sidebar-logo-container {

  & .sidebar-logo-link {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 35px 0;

    & .sidebar-logo {
      width: 150px;
      height: 188px;
      transition: all .3s ease;
    }

    & .sidebar-title {
      margin: 15px 0 0;
      color: $menuText;
      font-weight: 600;
      font-size: 18px;
      transition: all .3s ease;
    }
  }

  &.collapse {
    .sidebar-logo {
      margin-top: -4px;
      width: 50px;
      height: 62px;

      &-link {
        padding: 27px 0;
      }
    }
    .sidebar-title {
      font-size: 0;
    }
  }
}
</style>
