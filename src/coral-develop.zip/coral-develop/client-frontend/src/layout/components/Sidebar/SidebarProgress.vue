<template>
  <div class="_progress-bar" :class="{ 'is-condensed': isCondensed }">
    <template v-if="!isCondensed">
      <div class="_progress-bar__header">
        <span>{{ $t('onboarding.sidebar.progress') }}</span>
        <span>{{ percentage }}%</span>
      </div>
      <el-progress :stroke-width="15" :show-text="false" :percentage="percentage" />
    </template>
    <template v-if="isCondensed">
      <div class="_progress-bar__number">{{ percentage }}%</div>
    </template>
  </div>
</template>
<script>
export default {
  name: 'SidebarProgress',
  props: {
    percentage: {
      type: Number,
      default: 0,
    },
    isCondensed: {
      type: Boolean,
      default: false,
    },
  },
}
</script>
<style lang="scss" scoped>
._progress-bar {
  @import "@/styles/_settings/index.scss";

  display: flex;
  flex-direction: column;
  padding: 20px;

  &.is-condensed {
    padding: 10px;
  }

  &__header {
    display: flex;
    justify-content: space-between;
    color: black;
    font-size: 14px;
    margin-bottom: 10px;
    font-weight: 500;
  }

  &__number {
    font-weight: bold;
    font-size: 14px;
    text-align: center;
  }
}
</style>
