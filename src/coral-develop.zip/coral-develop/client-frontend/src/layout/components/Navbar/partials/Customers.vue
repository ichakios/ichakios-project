<template>
  <div class="app-l-cust">
    <el-dropdown :hide-on-click="true" @command="handleChange">
      <span class="el-dropdown-link app-l-cust__last-login">
        {{ $t('headerNavbar.loggedInto') }}
        <span class="u-color-primary">{{ value && value.name }}<i class="el-icon-arrow-down el-icon--right" /></span>
      </span>

      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item
          v-for="c in customers"
          :key="c.key"
          class="app-l-cust__last-login"
          :command="c.name"
        >
          {{ c.name }}
        </el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </div>
</template>

<script>
export default {
  name: 'AppCustomers',
  data() {
    return {
      customers: this.$store.state.user.customers,
      value: this.$store.state.user.currentCustomer, // the current selected value
    }
  },
  methods: {
    handleChange(newValue) {
      this.value = this.customers.find(c => c.name === newValue)
      this.$store.commit('user/SET_CURRENT_CUSTOMER', this.value)
    },
  },
}
</script>

<style
  lang="scss"
  scoped
>
  @import '~element-ui/packages/theme-chalk/src/common/var.scss';

  .app-l-cust {

    align-items: center;
    display: flex;
    padding-right: 10px;

    .el-dropdown-link {
      cursor: pointer;
    }

    .el-icon-arrow-down {
      font-size: 12px;
    }

    &__last-login {
      font-size: 12px;
    }
  }
</style>
