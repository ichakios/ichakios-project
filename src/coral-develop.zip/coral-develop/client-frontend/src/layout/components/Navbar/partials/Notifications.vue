<template>
  <div class="app-notifications">
    <div
      class="app-notifications__btn"
      @click="toggleNotifications"
    >
      <el-badge
        :value="messages.length || 0"
        :max="99"
        type="primary"
      >
        <i class="el-icon-bell app-notifications__icon" />
      </el-badge>
    </div>

    <!-- DRAWER -->
    <el-drawer
      :visible.sync="areNotificationsOpened"
      direction="rtl"
      :before-close="toggleNotifications"
    >
      <div class="app-notifications__body">
        <app-scrollbar
          ref="messages"
          class="app-notifications__scrollbar"
        >
          <h4 class="ml-3 mt-3">
            {{ $t('navbar.today') }}
          </h4>
          <router-link
            v-for="message in messages"
            :key="message.id"
            to="/"
            class="app-notifications__item"
            :class="message.isNew && 'is--new'"
            @click.native="toggleNotifications"
          >
            <small>
              {{ message.date.format('hh:mmA') }}
              {{ ' • ' }}
              {{ message.serviceName }}
            </small>

            <div class="app-notifications__item__title my-2 mt-2">
              {{ message.title }}
            </div>
            <small>
              {{ message.description }}
            </small>

            <span class="app-notifications__item__badge" />
          </router-link>
        </app-scrollbar>

        <router-link
          to="/tasks"
          @click.native="toggleNotifications"
        >
          <el-button
            type="primary"
            size="medium"
            class="app-notifications__see-all-btn"
          >
            {{ $t('navbar.seeAllTasks') }}
          </el-button>
        </router-link>
      </div>
    </el-drawer>
  </div>
</template>

<script>
import dayjs from 'dayjs'
import AppScrollbar from '../../../../components/Scrollbar/scrollbar'

export default {
  name: 'AppNotifications',
  components: { AppScrollbar },
  data() {
    return {
      areNotificationsOpened: false,
      messages: [
        {
          id: 1,
          title: 'New pending authorisation',
          description: 'John Do need your authorisation to access the #132468737 loan.',
          serviceName: 'Loans',
          date: dayjs(),
          isNew: true,
        }, {
          id: 2,
          title: 'Loan due date arrive soon',
          description: '#13573872132 loan will soon arrived to due date.',
          serviceName: 'Loans',
          date: dayjs(),
          isNew: true,
        }, {
          id: 3,
          title: 'New deposit on #79245757357',
          description: 'John Do make new deposit of 1,000,000.00 AED on #132468737 account.',
          serviceName: 'Deposits',
          date: dayjs(),
          isNew: true,
        }, {
          id: 4,
          title: 'New payment on #789564332357',
          description: 'John Do make new payment of 500,000.00 AED from #132468737 account.',
          serviceName: 'Payments',
          date: dayjs(),
          isNew: false,
        }, {
          id: 5,
          title: 'New payment on #789564332357',
          description: 'John Do make new payment of 500,000.00 AED from #132468737 account.',
          serviceName: 'Payments',
          date: dayjs(),
          isNew: false,
        }, {
          id: 6,
          title: 'New payment on #789564332357',
          description: 'John Do need your authorisation to access the #132468737 account.',
          serviceName: 'Payments',
          date: dayjs(),
          isNew: false,
        }, {
          id: 7,
          title: 'New payment on #789564332357',
          description: 'John Do need your authorisation to access the #132468737 account.',
          serviceName: 'Payments',
          date: dayjs(),
          isNew: false,
        }, {
          id: 8,
          title: 'New payment on #789564332357',
          description: 'John Do need your authorisation to access the #132468737 account.',
          serviceName: 'Payments',
          date: dayjs(),
          isNew: false,
        }, {
          id: 9,
          title: 'New payment on #789564332357',
          description: 'John Do need your authorisation to access the #132468737 account.',
          serviceName: 'Payments',
          date: dayjs(),
          isNew: false,
        },
      ],
    }
  },
  methods: {
    toggleNotifications() {
      this.areNotificationsOpened = !this.areNotificationsOpened
    },
  },
}
</script>

<style lang="scss">
  @import "@/styles/_settings/index.scss";

  .app-notifications {
    height: 100%;
    border-left: 1px solid $--border-color-lighter;

    .el-drawer__header {
      padding: 0;
      margin: 0;
    }

    .el-drawer__close-btn {
      position: absolute;
      top: 9px;
      right: 0;
      z-index: 2;
    }

    &__body {
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    &__scrollbar {
      height: 100%;
      overflow: auto;
      flex: 1;
    }

    &__btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 60px;
      padding-right: 5px;
      height: 100%;
      transition: background 0.3s ease;
      cursor: pointer;

      &:hover {
        background-color: lighten($bg, 7%);
      }
    }

    & &__see-all-btn { // Hack to increase CSS priority
      border-radius: 0;
      width: 100%;
      padding-top: 20px;
      padding-bottom: 20px;
    }

    &__icon {
      font-size: 1.5rem;
    }

    & &__item { // Hack to increase CSS priority
      position: relative;
      display: block;
      color: $--color-text-regular;
      padding: 20px 15px;
      transition:
        background-color 0.3s ease,
        color 0.3s ease;

      &:nth-child(even) {
        background: $subMenuBg;
      }

      &:hover {
        background-color: $menuHover;
        color: $--color-text-regular;
      }

      &__title {
        color: $--color-text-primary;
        font-weight: 500;
      }

      &__badge {
        position: absolute;
        top: 12.5px;
        right: 12.5px;
        width: 10px;
        height: 10px;
        border-radius: 5px;
        background-color: $--color-primary;
        opacity: 0;
      }

      &.is--new {
        .app-notifications__item__badge {
          opacity: 1;
        }
      }
    }
  }
</style>
