<template>
  <div class="app-l-navbar">
    <Hamburger
      :is-active="sidebar.opened"
      class="app-l-navbar__hamburger"
      @toggleClick="toggleSideBar"
    />

    <app-breadcrumb />

    <div class="app-l-navbar__user">
      <app-customers />

      <!-- USER DROPDOWN -->
      <el-dropdown
        class="app-l-navbar__user"
      >
        <div class="app-l-navbar__user__container">
          <el-avatar :src="user.avatar && user.avatar.length > 0 ? avatar+user.avatar : null">
            {{ displayInitials(user.name) }}
          </el-avatar>
        </div>

        <el-dropdown-menu
          slot="dropdown"
        >
          <router-link to="/">
            <el-dropdown-item>
              {{ $t('navbar.account') }}
            </el-dropdown-item>
          </router-link>
          <el-dropdown-item
            divided
            @click.native="logout"
          >
            {{ $t('navbar.logout') }}
          </el-dropdown-item>
          <el-dropdown-item
            class="app-l-navbar__language-switcher"
            divided
          >
            {{ $t('languages') }}
            <div>
              <app-button
                v-for="lang in languagesList"
                :key="lang.key"
                @click="updateLocale(lang.key)"
              >
                {{ lang.name }}
              </app-button>
            </div>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>

    <!-- NOTIFICATIONS -->
    <app-notifications />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Hamburger from '@/components/Hamburger'
import AppButton from '@/components/Button'
import AppBreadcrumb from '@/components/Breadcrumb'
import AppNotifications from './partials/Notifications'
import AppCustomers from './partials/Customers'
import { languagesList } from '@/constants/languages'

export default {
  components: {
    AppCustomers,
    Hamburger,
    AppButton,
    AppBreadcrumb,
    AppNotifications,
  },
  data() {
    return {
      user: {
        name: this.$store.state.user.name,
        lastLogin: this.$store.state.user.lastLogin,
        avatar: this.$store.state.user.avatar,
      },
      languagesList,
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'avatar',
    ]),
  },
  methods: {
    updateLocale(lang) {
      this.$store.dispatch('user/updateCurrentLang', lang)
    },
    toggleSideBar() {
      this.$store.dispatch('app/toggleSideBar')
    },
    async logout() {
      await this.$store.dispatch('user/logout')
      this.$router.push(`/login?redirect=${this.$route.fullPath}`)
    },
    toggleNotifications() {
      this.areNotificationsOpened = !this.areNotificationsOpened
    },
    displayInitials(name) {
      const initials = []
      name.split(' ').map((string) => initials.push(string[0]))
      return initials.join('').substring(0, 2)
    },
  },
}
</script>

<style lang="scss" scoped>
@import "@/styles/_settings/index.scss";

.app-l-navbar {
  height: 50px;
  display: flex;
  overflow: hidden;
  position: relative;
  background: #fff;
  box-shadow: $box-shadow;
  margin: 16px 32px 0;
  border-radius: 2px;

  &__hamburger {
    line-height: 46px;
    height: 100%;
    float: left;
    cursor: pointer;
    transition: background .3s;
    -webkit-tap-highlight-color:transparent;

    &:hover {
      background: rgba(0, 0, 0, .025)
    }
  }

  &__language-switcher {
    display: flex;
    flex-direction: column;

    &.el-dropdown-menu__item:not(.is-disabled):hover,
    &.el-dropdown-menu__item:focus {
      background-color: white;
      color: $--color-text-regular;
    }
  }

  &__user {
    display: flex;
    margin-left: auto;
    padding-right: 10px;
    cursor: pointer;

    &__container {
      display: flex;
      align-self: center;
      align-items: center;
    }

    &__title {
      text-align: right;
      margin-right: 10px;
    }

    &__name{
      font-size: 12px;
    }

    &__last-login{
      font-size: 10px;
    }
  }
}
</style>
