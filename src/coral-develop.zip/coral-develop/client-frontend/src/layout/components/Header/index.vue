<template>
  <header class="o-header">
    <div class="container">
      <div class="o-header__title">Zand</div>
      <nav class="o-header__nav">
        <el-dropdown @command="updateLocale">
          <el-link :underline="false" class="el-dropdown-link">
            {{ $t('languages') }} <i class="el-icon-arrow-down el-icon--right" />
          </el-link>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item
              v-for="(lang, i) in langs"
              :key="`Lang${i}`"
              :command="lang.key"
            >
              {{ lang.name }}
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <el-link
          :underline="false"
          class="o-header__nav--item"
        >
          {{ $t('faq') }}
        </el-link>
      </nav>
    </div>
  </header>
</template>

<script>
export default {
  data() {
    return {
      // TODO: use vuex to store these infos
      langs: [
        { key: 'ar-ae', name: 'عربى' },
        { key: 'en', name: 'English' },
      ],
    }
  },
  methods: {
    updateLocale(lang) {
      this.$i18n.locale = lang
    },
  },
}
</script>

<style lang="scss" scoped>
@import "@/styles/_settings/index.scss";

.container {
  max-width: 1080px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.o-header {
  padding: 1rem;
  border-bottom: 1px solid $--border-color-base;
  background-color: white;
  filter: opacity(80%);
  backdrop-filter: blur(10px);

  &__title {
    font-weight: bold;
  }

  &__nav {
    &--item {
      padding: .5rem 1rem;
      margin: 0 1rem;
    }
  }
}
</style>
