<template>
  <div
    class="_app-fixed-bottom"
    :class="{
      'is--full' : isMobile,
      'is--wide' : !isMobile && isCollapse,
      'is--small' : !isMobile && !isCollapse
    }"
  >
    <app-container
      direction="horizontal"
      class="_app-fixed-bottom__container"
    >
      <slot />
    </app-container>
  </div>
</template>

<script>
import AppContainer from '@/components/Container'
export default {
  components: {
    AppContainer,
  },
  computed: {
    isCollapse() {
      if (this.$store) {
        return !this.$store.state.app.sidebar.opened
      }
      return null
    },
    isMobile() {
      if (this.$store) {
        return this.$store.state.app.device === 'mobile'
      }
      return null
    },
  },
}
</script>

<style lang="scss" scoped>
  @import '@/styles/_settings/index.scss';
  ._app-fixed-bottom {
    position: fixed;
    bottom: 0;
    right: 0;
    left: 0;
    height: $fixedBottomHeight;
    text-align: right;
    transition: all 0.3s ease;
    min-width: $appMinWidth;
    z-index: 1;

    &__container {
      margin-top: 15px;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: flex-end;
    }

    &.is--small {
      left: $sideBarWidth;
    }

    &.is--wide {
      left: $sideBarWidthSmall;
    }

    &.is--full {
      left: 0;
    }
  }
</style>

<!-- USE THIS CLASS ON PAGES TO ADD ENOUGH PADDING ON PAGE BOTTOM -->
<style lang="scss">
  @import '@/styles/_settings/index.scss';
  .has--fixed-bottom {
    padding-bottom: $paddingBottomWithFixedBottom;
  }
</style>
