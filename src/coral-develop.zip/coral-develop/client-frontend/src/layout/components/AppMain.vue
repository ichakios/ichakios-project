<template>
  <section class="app-main">
    <transition
      :name="routerTransition"
      mode="out-in"
    >
      <router-view :key="key" />
    </transition>
  </section>
</template>

<script>
export default {
  name: 'AppMain',
  data() {
    return {
      routerTransition: 'fade-transform',
    }
  },
  computed: {
    key() {
      return this.$route.path
    },
  },
  watch: {
    '$route'(to, from) {
      if (to.name === from.name) {
        this.routerTransition = undefined
      } else {
        this.routerTransition = 'fade-transform'
      }
    },
  },
}
</script>

<style lang="scss" scoped>
@import "@/styles/_settings/index.scss";

.app-main {
  /*50 = navbar  */
  min-height: calc(100vh - 66px);
  width: 100%;
  position: relative;
  overflow: hidden;
  padding-bottom: 75px;
}
.fixed-header+.app-main {
  padding-top: 50px;
}
</style>

<style lang="scss">
// fix css style bug in open el-dialog
.el-popup-parent--hidden {
  .fixed-header {
    padding-right: 15px;
  }
}
</style>
