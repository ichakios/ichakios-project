export default {
  computed: {
    formMixin() {
      return {
        /* Usage
          :error="formMixin.getFieldError($v.formValues.name, 'pageName.form.name')"
        */
        getFieldError: this.formMixin_getFieldError,
      }
    },
  },
  methods: {
    formMixin_getTranslation(translationKey, ruleKey) {
      const rule = ruleKey ? `.${ruleKey}` : ''
      return typeof translationKey === 'object'
        ? this.$t(`${translationKey.key}${rule}`, translationKey.params)
        : this.$t(`${translationKey}${rule}`)
    },

    formMixin_getFieldError(input, translationKey, form) {
      const showError = input.$error || (form && form.$dirty && input.$invalid)
      if (!showError) return ''

      // Get translated error message with params based on errors keys
      return Object.keys(input.$params || {})
        .reduce((messages, ruleKey) => !input[ruleKey]
          ? `${messages}${messages ? ' - ' : ''}${this.formMixin_getTranslation(translationKey, ruleKey)}`
          : messages, '')
    },
  },
}
