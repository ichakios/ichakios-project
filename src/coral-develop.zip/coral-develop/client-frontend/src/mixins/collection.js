export const sortOrderList = {
  ASCENDING: 'ascending',
  DESCENDING: 'descending',
}

export default {
  data() {
    return {
      collectionMixin_collection: [],
      collectionMixin_currentPage: 1,
      collectionMixin_pageSize: 10,
      collectionMixin_searchTerm: '',
      collectionMixin_sortProp: 'name',
      collectionMixin_sortOrder: sortOrderList.ASCENDING,
    }
  },
  computed: {
    collectionMixin_collectionFiltered() {
      return this.collectionMixin_collectionForDisplay
        .filter(this.collectionMixin_getFilterByItemForCollection)
        .filter((item) => {
          if (!this.collectionMixin_searchTerm) return true
          const searchString = this.collectionMixin_getSearchStringByItemForCollection(item).toLowerCase()
          return searchString.indexOf(this.collectionMixin_searchTerm.trim().toLowerCase()) !== -1
        })
        .sort(this.collectionMixin_getSortFunctionForCollection())
    },
    collectionMixin_collectionFilteredCount() {
      return this.collectionMixin_collectionFiltered.length
    },
    collectionMixin_collectionOnPage() {
      const startIndexToShow = (this.collectionMixin_currentPage - 1) * this.collectionMixin_pageSize
      const endIndex = startIndexToShow + this.collectionMixin_pageSize
      return this.collectionMixin_collectionFiltered
        .slice(startIndexToShow, endIndex)
    },

    // Override for custom collection display
    collectionMixin_collectionForDisplay() {
      return this.collectionMixin_collection
    },
  },
  methods: {
    /**
     * Mutations
     */

    collectionMixin_setCollection(newCollection) {
      this.collectionMixin_collection = [...newCollection]
    },
    collectionMixin_setCurrentPage(page) {
      this.collectionMixin_currentPage = Math.max(1, page)
    },
    collectionMixin_setSearchTerm(searchTerm) {
      this.collectionMixin_searchTerm = searchTerm || ''
    },
    collectionMixin_setSort({ prop, order }) {
      this.collectionMixin_sortProp = prop || this.collectionMixin_sortProp
      this.collectionMixin_sortOrder = order || sortOrderList.ASCENDING
      this.collectionMixin_currentPage = 1
    },

    /**
     * Actions
     */

    collectionMixin_goToPage(page) {
      this.collectionMixin_setCurrentPage(page)
    },
    collectionMixin_search(searchTerm) {
      this.collectionMixin_setSearchTerm(searchTerm)
    },
    collectionMixin_sort({ prop, order, group }) {
      if (prop !== this.collectionMixin_sortProp || order) {
        const propToChange = prop || (!group || group.includes(this.collectionMixin_sortProp) ? this.collectionMixin_sortProp : group[0])
        this.collectionMixin_setSort({ prop: propToChange, order })
        return
      }

      if (this.collectionMixin_sortOrder === sortOrderList.ASCENDING) {
        this.collectionMixin_setSort({ order: sortOrderList.DESCENDING })
        return
      }

      this.collectionMixin_setSort({ order: sortOrderList.ASCENDING })
    },
    collectionMixin_updateItemInCollection({ id, attrs = {}}) {
      const newCollection = [...this.collectionMixin_collection]
      const itemIndex = newCollection.findIndex(item => this.collectionMixin_getItemIdentifier(item) === id)
      if (itemIndex < 0) {
        return
      }
      newCollection[itemIndex] = { ...newCollection[itemIndex], ...attrs }
      this.collectionMixin_setCollection(newCollection)
    },

    /**
     * Getters
     */

    collectionMixin_getSortOrder(props = []) {
      if (!props.length) {
        return this.collectionMixin_sortOrder
      }
      return props.indexOf(this.collectionMixin_sortProp) !== -1 ? this.collectionMixin_sortOrder : null
    },
    collectionMixin_getItem(id) {
      const item = this.collectionMixin_collection.find((x) => this.collectionMixin_getItemIdentifier(x) === id)
      return item || null
    },
    collectionMixin_getItemForDisplay(id) {
      const item = this.collectionMixin_collectionForDisplay.find((x) => this.collectionMixin_getItemIdentifier(x) === id)
      return item || null
    },
    collectionMixin_getEnumSortFunction(enumKeys) {
      return (a, b) => this.collectionMixin_sortOrder === sortOrderList.ASCENDING
        ? enumKeys.indexOf(a[this.collectionMixin_sortProp]) - enumKeys.indexOf(b[this.collectionMixin_sortProp])
        : enumKeys.indexOf(b[this.collectionMixin_sortProp]) - enumKeys.indexOf(a[this.collectionMixin_sortProp])
    },
    collectionMixin_sortStrings(a, b) {
      const predicate = this.collectionMixin_sortOrder === sortOrderList.ASCENDING ? 1 : -1
      return (JSON.stringify(a) || '').localeCompare(JSON.stringify(b)) * predicate
    },
    collectionMixin_sortNumbers(a, b) {
      const predicate = this.collectionMixin_sortOrder === sortOrderList.ASCENDING ? 1 : -1
      return (a - b) * predicate
    },
    collectionMixin_getDefaultSortFunction() {
      return (a, b) => {
        const aValue = a[this.collectionMixin_sortProp]
        const bValue = b[this.collectionMixin_sortProp]
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          return this.collectionMixin_sortNumbers(aValue, bValue)
        }
        return this.collectionMixin_sortStrings(aValue, bValue)
      }
    },

    // Override for custom item identifier
    collectionMixin_getItemIdentifier(item) {
      return item.id
    },

    // Override for custom search
    collectionMixin_getSearchStringByItemForCollection(item) {
      return JSON.stringify(item)
    },

    // Override for custom sorting
    collectionMixin_getSortFunctionForCollection() {
      return this.collectionMixin_getDefaultSortFunction()
    },

    // Override for custom filter
    collectionMixin_getFilterByItemForCollection(item) {
      return !!item
    },
  },
}
