<template>
  <el-tabs
    type="card"
    class="_tabs"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />
  </el-tabs>
</template>

<script>
export default {
  name: 'AppTabs',
}
</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";

  ._tabs /deep/ {
    .el-tabs__header {
      border-bottom: none;
    }

    .el-tabs__item {
      transition: all ease-in-out 200ms;
      background-color: white;

      &.is-active {
        background-color: $--color-primary;
        border-bottom-color: $--color-primary;
        color: white;
      }
    }

    .el-tabs__nav {
      overflow: hidden;
      border: 1px rgb(228, 231, 237) solid;
      border-radius: 4px;
    }
  }
</style>
