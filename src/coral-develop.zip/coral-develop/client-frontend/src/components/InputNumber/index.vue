<template>
  <el-input-number
    v-bind="$attrs"
    :class="`_input-number ${!!customColor && 'is--' + customColor}`"
    v-on="$listeners"
  >
    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />

    <!-- Pass on all scoped slots -->
    <template
      v-for="slot in Object.keys($scopedSlots)"
      :slot="slot"
      slot-scope="scope"
    >
      <slot :name="slot" v-bind="scope" />
    </template>
  </el-input-number>
</template>

<script>

export default {
  props: {
    customColor: {
      type: String,
      default: 'default',
    },
  },
}
</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";

  ._input-number.el-input-number {
    $isError: ".el-form-item.is-error";

    #{$isError} & {
      /deep/ .el-input__inner {
        border-color: $--color-danger;
      }
    }

    &.is--light {
      /deep/ .el-input__inner {
        border-color: $--color-white;
      }
    }

    &.is--dark {
      /deep/.el-input__inner {
        border-color: $--border-color-dark;
      }
    }

    &.is--light,
    &.is--dark {
      /deep/.el-input__inner {
        background-color: $bg;

        &:focus {
          border-color: $--input-focus-border;
        }
      }

      /deep/ .el-input-number__increase,
      /deep/ .el-input-number__decrease {
        background-color: darken($bg, 7%);
      }

      &.is-disabled {
        /deep/.el-input__inner {
          background-color: $--disabled-fill-base;
          border-color: $--disabled-border-base;
        }
      }
    }
  }

</style>
