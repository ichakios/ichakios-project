<template>
  <div
    :is="isInline ? 'span' : 'div'"
    :class="{
      'u-text-ellipsis': !withoutEllipsis,
    }"
    class="_app-amount"
  >
    <small class="currency" style="opacity: 0.7">{{ currency }}</small>
    <span
      class="u-text-medium"
      :class="{
        'u-color-danger': withNegativeStyle && parseFloat(amount) < 0,
      }"
    >
      <slot :amount="formatedAmount">
        {{ formatedAmount }}
      </slot>
    </span>
  </div>
</template>

<script>
import { getLocalizedNumber } from '@/utils/formatNumber'

export default {
  name: 'AppAmount',
  props: {
    currency: {
      type: String,
      default: '',
    },
    amount: {
      type: [String, Number],
      default: 0,
    },
    withNegativeStyle: {
      type: Boolean,
      default: false,
    },
    withoutEllipsis: {
      type: Boolean,
      default: false,
    },
    isInline: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    formatedAmount() {
      return getLocalizedNumber(parseFloat(this.amount), this.$i18n.locale)
    },
  },
}

</script>
