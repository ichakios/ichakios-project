<template>
  <el-switch
    v-bind="$attrs"
    :class="`_switch ${!!customColor && 'is--' + customColor}`"
    v-on="$listeners"
  >
    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />

    <!-- Pass on all scoped slots -->
    <template
      v-for="slot in Object.keys($scopedSlots)"
      :slot="slot"
      slot-scope="scope"
    >
      <slot :name="slot" v-bind="scope" />
    </template>
  </el-switch>
</template>

<script>

export default {
  props: {
    customColor: {
      type: String,
      default: 'default',
    },
  },
}
</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";

  ._switch:not(.is-checked) {
    &:not(.is--light):not(.is--dark) {
      /deep/.el-switch__core {
        background-color: $--color-white;
        border-color: $--border-color-base;

        &:after {
          border: 1px solid $--color-white;
          background-color: $bg-dark;
        }
      }
    }

    &.is--light,
    &.is--dark {
      /deep/.el-switch__core {
        background-color: $bg-dark;
        border-color: $bg-dark;
      }

      &.is-disabled {
        /deep/.el-switch__core {
          background-color: $--disabled-fill-base;
          border-color: $--disabled-border-base;
        }
      }
    }

    &.is--dark {
      /deep/.el-switch__core {
        border-color: $--border-color-dark;
      }
    }
  }

  ._switch.is-checked {
    &:not(.is--light):not(.is--dark) {
      /deep/.el-switch__core:after {
          border: 1px solid $--color-primary;
        }
      }
    }

</style>
