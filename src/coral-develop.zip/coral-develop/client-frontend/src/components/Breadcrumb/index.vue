<template>
  <el-breadcrumb
    class="app-breadcrumb"
    separator="/"
  >
    <transition-group name="breadcrumb">
      <el-breadcrumb-item
        v-for="(item,index) in levelList"
        :key="item.path"
      >
        <span
          v-if="item.redirect==='noRedirect'||index === levelList.length-1"
          class="no-redirect"
        >
          {{ getPageTitle(item.meta.title, $route) }}
        </span>
        <a
          v-else
          class="app-breadcrumb__link"
          @click.prevent="handleLink(item)"
        >{{ getPageTitle(item.meta.title, $route) }}</a>
      </el-breadcrumb-item>
    </transition-group>
  </el-breadcrumb>
</template>

<script>
import { compile } from 'path-to-regexp'
import { getPageTitle } from '@/utils/getPageTitle'

export default {
  data() {
    return {
      i18n: this.$i18n,
      levelList: null,
    }
  },
  watch: {
    $route() {
      this.getBreadcrumb()
    },
  },
  created() {
    this.getBreadcrumb()
  },
  methods: {
    getPageTitle,
    getBreadcrumb() {
      // only show routes with meta.title
      let matched = this.$route.matched.filter(item => item.meta && item.meta.title)
      const first = matched[0]

      if (!this.isDashboard(first)) {
        matched = [{ path: '/dashboard', meta: { title: 'routes.dashboard' }}]
          .concat(matched.map(match => match.meta && match.meta.breadcrumbExtra ? [...match.meta.breadcrumbExtra, match] : match).flat())
      }

      this.levelList = matched.filter(item => item.meta && item.meta.title && item.meta.breadcrumb !== false)
    },
    isDashboard(route) {
      const name = route && route.name
      if (!name) {
        return false
      }
      return name.trim().toLocaleLowerCase() === 'Dashboard'.toLocaleLowerCase()
    },
    pathCompile(path) {
      // To solve this problem https://github.com/PanJiaChen/vue-element-admin/issues/561
      const { params } = this.$route
      var toPath = compile(path)
      return toPath(params)
    },
    handleLink(item) {
      const { redirect, path } = item
      if (redirect) {
        this.$router.push(redirect)
        return
      }
      this.$router.push(this.pathCompile(path))
    },
  },
}
</script>

<style lang="scss" scoped>
@import "@/styles/_settings/index.scss";

.app-breadcrumb.el-breadcrumb {
  display: flex;
  align-items: center;
  font-size: 16px;

  .no-redirect {
    color: $--color-text-regular;
    cursor: text;
    font-weight: 500;
  }

  .app-breadcrumb__link {
    color: $--color-primary;
    text-decoration: underline;
    font-weight: 500 !important;
    &:hover,
    &:active {
      color: darken($color: $--color-primary, $amount: 10%);
    }
  }
}
</style>
