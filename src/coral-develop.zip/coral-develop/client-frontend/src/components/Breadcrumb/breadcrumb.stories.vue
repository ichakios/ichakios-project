<template>
  <el-container direction="vertical">
    <el-row>
      <app-breadcrumb />
    </el-row>
  </el-container>
</template>

<script>

import VueI18n from 'vue-i18n'
import AppBreadcrumb from './'

export default {
  components: { AppBreadcrumb },
  i18n: new VueI18n({
    locale: 'en',
    messages: {
      en: {
        routes: {
          dashboard: 'Home',
        },
      },
    },
  }),
}
</script>
