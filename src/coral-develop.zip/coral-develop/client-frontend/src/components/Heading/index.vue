<template>
  <div
    :is="`h${Math.max(Math.min(size, 6), 1)}`"
    class="_heading"
    :class="{
      'is--thin': weight === 'thin',
      'is--extra-light': weight === 'extra-light',
      'is--light': weight === 'light',
      'is--normal': weight === 'normal',
      'is--medium': weight === 'medium',
      'is--semi-bold': weight === 'semi-bold',
      'is--bold': weight === 'bold',
      'is--extra-bold': weight === 'extra-bold',
      'is--black': weight === 'black',
    }"
  >
    <slot />
  </div>
</template>

<script>
export default {
  props: {
    size: {
      type: Number,
      default: 1,
    },
    weight: {
      type: String,
      default: '',
    },
    title: {
      type: String,
      default: '',
    },
  },
}
</script>

<style lang="scss" scoped>

h1._heading {
  color: black;
  font-size: 24px;
  font-weight: 500;
  margin: 20px 0;
}
h2._heading {
  color: black;
  font-size: 22px;
  font-weight: 500;
  margin-bottom: 20px;
}
h3._heading {
  color: black;
  font-size: 18px;
  font-weight: 500;
}
h4._heading {
  color: black;
  font-size: 14px;
  font-weight: 500;
}
h5._heading {
  color: black;
  font-size: 12px;
  font-weight: 500;
}

// Displayed all the font weight, if oneday we add fonts weights

.is--thin {
  font-weight: 100 !important;
}

.is--extra-light {
  font-weight: 200 !important;
}

.is--light {
  font-weight: 300 !important;
}

.is--normal {
  font-weight: 400 !important;
}

.is--medium {
  font-weight: 500 !important;
}

.is--semi-bold {
  font-weight: 600 !important;
}

.is--bold {
  font-weight: 700 !important;
}

.is--extra-bold {
  font-weight: 800 !important;
}

.is--black {
  font-weight: 900 !important;
}

</style>
