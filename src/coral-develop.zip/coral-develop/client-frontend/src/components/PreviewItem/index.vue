<template>
  <div class="_preview-item">
    <div
      class="_preview-item__label"
      :style="{ width: computedLabelWidth }"
    >
      {{ label }}
    </div>
    <div class="_preview-item__value">
      <slot v-if="!isEmpty" />
      <small v-if="isEmpty" class="_preview-item__value-empty">{{ emptyValue }}</small>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    label: {
      type: String,
      default: '',
    },
    labelWidth: {
      type: String,
      default: null,
    },
    emptyValue: {
      type: String,
      default: '',
    },
    isEmpty: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    computedLabelWidth() {
      const parent = this.$parent

      if (this.labelWidth) {
        return this.labelWidth
      }

      if (parent.$options._componentTag === 'el-form' && parent.$options.propsData.labelWidth) {
        return parent.$options.propsData.labelWidth
      }

      return '200px'
    },
  },
}
</script>
<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";
  ._preview-item {
    display: flex;
    margin: 0 0 40px 0;

    &__label {
      flex: none;
      font-weight: bold;
      font-size: 16px;
    }

    &__value {
      min-width: 0;
      width: 100%;
      padding-top: 2px;

      &-empty {
        opacity: 0.5;
      }
    }
  }
</style>
