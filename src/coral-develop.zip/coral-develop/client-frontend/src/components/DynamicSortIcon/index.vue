<template>
  <div class="a-sort-icon">
    <app-button
      type="text"
      icon="el-icon-caret-top"
      :class="{
        'a-sort-icon__top': true,
        'is--active': order === 'ascending'
      }"
      @click="handleSort('ascending')"
    />
    <app-button
      type="text"
      icon="el-icon-caret-bottom"
      :class="{
        'a-sort-icon__bottom': true,
        'is--active': order === 'descending'
      }"
      @click="handleSort('descending')"
    />
  </div>
</template>

<script>
import AppButton from '@/components/Button'

export default {
  name: 'AppDynamicSortIcon',
  components: {
    AppButton,
  },
  props: {
    order: {
      validator: value => {
        return [
          'ascending',
          'descending',
          null,
        ].indexOf(value) !== -1
      },
      default: null,
    },
  },
  methods: {
    handleSort(sortOrder) {
      this.$emit('sortOrderChange', sortOrder)
    },
  },
}
</script>

<style lang="scss" scoped>
@import "@/styles/_settings/index.scss";

.a-sort-icon {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100%;

  &__top {
    border-radius: 0;
    padding: 0;
    margin: 0;
    color: $brown;
    transform: translateY(.25rem);
  }

  &__bottom {
    border-radius: 0;
    padding: 0;
    margin: 0 !important;
    color: $brown;
    transform: translateY(-.25rem);
  }

  .is--active {
    color: $--color-primary
  }
}
</style>
