<template>
  <div
    v-loading="loading"
    element-loading-spinner="el-icon-loading"
    class="_app-file-preview"
    :class="{
      'is--error': isError,
      'is--downloadable': downloadable && !!imageUrlOrBase64,
      'has--no-border': noBorder,
    }"
    @click="onDownload()"
  >
    <div class="_app-file-preview__content">
      <em
        v-if="!isImage"
        class="el-icon-document _app-file-preview__icon"
        :class="{
          'el-icon-document': !isError,
          'el-icon-warning': isError
        }"
      />
      <div
        v-if="(raw || url) && isImage"
        class="_app-file-preview__image-preview"
      >
        <img
          :src="imageUrlOrBase64 || url"
          :alt="name"
          class="_app-file-preview__image"
        >
      </div>
      <div class="_app-file-preview__text">
        <span class="_app-file-preview__name">
          {{ name || '-' }}
        </span>
        <span class="_app-file-preview__size">
          {{ size && `(${formatBytes(size)})` }}
        </span>
      </div>
      <app-button
        v-if="onRemove"
        class="_app-file-preview__remove"
        type="text"
        icon="el-icon-delete"
        @click="remove()"
      />
    </div>
    <div
      v-if="isError"
      class="_app-file-preview__error"
    >
      {{ $t('components.filePreview.exceedLimit', { maxSize: formatBytes(maxSize) }) }}
    </div>
  </div>
</template>

<script>
import { formatBytes } from '@/utils/formatNumber'
import AppButton from '@/components/Button'

const formatFile = [
  'image/png',
  'image/jpg',
  'image/jpeg',
]

export default {
  components: {
    AppButton,
  },
  props: {
    raw: {
      type: File,
      default: null,
    },
    name: {
      type: String,
      default: '',
    },
    size: {
      type: Number,
      default: null,
    },
    maxSize: {
      type: Number,
      default: null,
    },
    url: {
      type: String,
      default: null,
    },
    type: {
      type: String,
      default: null,
    },
    onRemove: {
      type: Function,
      default: null,
    },
    downloadable: {
      type: Boolean,
      default: false,
    },
    noBorder: {
      type: Boolean,
      default: false,
    },
    loading: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      imageUrlOrBase64: null,
      formatFile,
    }
  },
  computed: {
    isError() {
      return this.maxSize ? this.size > this.maxSize : false
    },
    isImage() {
      return this.formatFile.includes(this.type)
    },
  },
  watch: {
    raw() {
      this.loadImage()
    },
    url() {
      this.loadImage()
    },
  },
  mounted() {
    this.loadImage()
  },
  methods: {
    formatBytes,
    loadImage() {
      this.imageUrlOrBase64 = null

      if (this.raw) {
        const reader = new FileReader()
        reader.readAsDataURL(this.raw)
        reader.addEventListener('load', () => {
          this.imageUrlOrBase64 = reader.result
        }, false)
        return
      }
      if (this.url) {
        this.imageUrlOrBase64 = this.url
      }
    },
    onDownload() {
      if (this.downloadable && !!this.imageUrlOrBase64) {
        const link = document.createElement('a')
        link.href = this.imageUrlOrBase64
        link.setAttribute('download', this.name)
        link.setAttribute('target', '_blank')
        document.body.appendChild(link)
        link.click()
        window.URL.revokeObjectURL(link.href)
        document.body.removeChild(link)
      }
    },
    remove() {
      this.onRemove()
      event.stopPropagation()
    },
  },
}
</script>
<style lang="scss" scoped>
@import "@/styles/_settings/index.scss";

  ._app-file-preview {
    background-color: white;
    box-shadow: 0 0 2px rgba(0,0,0,0.2);
    border-radius: 4px;
    overflow: hidden;
    margin: 0 0 8px 0;
    font-size: 14px;

    &__content {
      display: flex;
      align-items: center;
      line-height: 1.2;
      padding: 2px;
    }

    &__error {
      background: $--color-danger;
      color: white;
      line-height: 1.2;
      padding: 5px;
      text-align: center;
      font-size: 12px;
      font-weight: bold;
    }

    &__icon {
      padding: 10px;
      opacity: 0.6;
    }

    &__name {
      min-width: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      padding: 5px 0;
    }

    &__size {
      font-size: 0.8em;
      margin: 0 5px;
      flex: none;
      opacity: 0.6;
    }

    &__remove {
      padding: 10px;
      margin-left: auto;
      color: inherit;
      opacity: 0.4;

      &:hover,
      &:focus {
        opacity: 1;
        color: $--color-danger;
      }
    }

    &__text {
      display: flex;
      align-items: center;
      overflow: hidden;
      width: 100%;
    }

    &__image {
      width: 100px;
      overflow: hidden;
      border-radius: 4px;
      box-shadow: 0px 2px 8px rgba(0, 0, 0, 0.15);
      margin: 4px;
      padding: 4px;
      height: 70px;
      object-fit: contain;
    }

    &__image-preview {
      display: flex;
      margin-right: 10px;
    }

    &__remove {
      color: $--color-primary;

      &:hover {
        cursor: pointer;
        text-decoration: underline;
      }
    }

    &.has--no-border {
      box-shadow: none;
      border: 0;

      &:hover &__button {
        background-color: transparent;
      }
    }

    &.has--no-border &__icon {
      padding: 0 10px 0 0;
    }

    &.has--no-border &__error {
      background-color: transparent;
      color: $--color-danger;
      text-align: left;
      padding-top: 0;
      margin-top: -3px;
    }

    &.is--error {
      color: $--color-danger;

      &__icon {
        opacity: 1;
      }

      &__image-preview {
        opacity: 0.5;
      }

      &__name {
        text-decoration: line-through;
      }

      &__size {
        opacity: 1;
        font-weight: bold;
      }
    }

    &.is--downloadable &__icon,
    &.is--downloadable &__size {
      color: $--color-primary;
      opacity: 1;
    }

    &.is--downloadable {
      cursor: pointer;
      transition:
        background-color 0.3s ease,
        color 0.3s ease;

      &:hover {
        color: darken($--color-primary, 10%);
      }
    }

    &.is--downloadable:not(.has--no-border):hover {
      background-color: rgba($--color-primary, 0.05);
    }

    /deep/ .el-loading-mask {
      background: rgba(255, 255, 255, 0.5)
    }
    /deep/ .el-loading-spinner {
      margin-top: 0;
      transform: translateY(-50%)
    }
  }
</style>
