<template>
  <div
    :id="`app-scrollbar-${id}`"
    class="app-scrollbar"
  >
    <slot />
  </div>
</template>

<script>
import OverlayScrollbars from 'overlayscrollbars/js/jquery.overlayScrollbars.min'

export default {
  props: {
    id: {
      type: String,
      default: null,
    },
  },
  data() {
    return {
      i18n: this.$i18n,
    }
  },
  watch: {
    i18n() {
      this.updateScrollbar()
    },
  },
  mounted() {
    this.updateScrollbar()
  },
  methods: {
    updateScrollbar() {
      OverlayScrollbars(
        document.querySelectorAll(`#app-scrollbar-${this.id}`),
        {
          autoUpdate: true,
          scrollbars: {
            autoHide: 'move',
          },
        },
      )
    },
  },
}
</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";

  .app-scrollbar {
    width: 100%;
    height: 100%;
    overflow: auto;
  }

  .os-theme-dark > .os-scrollbar > .os-scrollbar-track > .os-scrollbar-handle {
    background: darken($bg, 5%);

    &:hover,
    &:active {
      background-color: darken($bg, 20%);
    }
  }

  /* rtl:begin:ignore */
  .os-host-rtl > .os-scrollbar-vertical {
    right: auto!important;
    left: 0!important;
  }
  /* rtl:end:ignore */
</style>
