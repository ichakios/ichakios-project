<template>
  <div>
    Simple scrollbar
    <br>
    <div class="scrollbar__container">
      <app-scrollbar id="scroll1">
        <ul>
          <li
            v-for="item in items"
            :key="item"
          >
            Item {{ item }}
          </li>
        </ul>
      </app-scrollbar>
    </div>

    <br>
    Simple scrollbar with RTL support
    <br>
    <div class="scrollbar__container" dir="rtl">
      <app-scrollbar id="scroll2">
        <ul>
          <li
            v-for="item in items"
            :key="item"
          >
            Item {{ item }}
          </li>
        </ul>
      </app-scrollbar>
    </div>
  </div>
</template>

<script>
import AppScrollbar from './scrollbar'
export default {
  components: {
    AppScrollbar,
  },
  data() {
    return {
      items: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    }
  },
}
</script>

<style lang="scss" scoped>
  .scrollbar__container {
    position: relative;
    height: 150px;
    width: 150px;
    border: 1px solid rgba(0, 0, 0, 0.2);
    overflow: auto;
  }
</style>
