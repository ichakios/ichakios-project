<template>
  <div
    ref="accountSelect"
    class="_account-select"
    :style="{ minHeight : minHeight ? `${minHeight}px` : 'default' }"
  >
    <app-select
      :show-labels="false"
      :allow-empty="allowEmpty"
      v-bind="$attrs"
      :options="options"
      :custom-label="labelForSearch"
      :placeholder="placeholder || $t('components.accountSelect.placeholder')"
      :option-height="minHeight"
      :multiple="multiple"
      v-on="$listeners"
    >
      <!-- SELECTED MULTIPLE TAG -->
      <template v-slot:tag="{ option, remove }">
        <div>
          <div class="_account-select__tag">
            <app-account-preview
              :type="type"
              :account-nickname="option.accountNickname"
              :account-name="option.accountName"
              :account-number="option.accountNumber"
              :account-iban="option.accountIban"
              :status="option.status"
              :show-name-and-nickname="showNameAndNickname"
            />
            <span
              class="el-icon-close"
              @click.stop="() => handleRemove(remove, option)"
            />
          </div>
        </div>
      </template>

      <!-- SELECTED SINGLE OPTION -->
      <template v-slot:singleLabel="{ option }">
        <app-account-preview
          :type="type"
          :account-nickname="option.accountNickname"
          :account-name="option.accountName"
          :account-number="option.accountNumber"
          :account-iban="option.accountIban"
          :status="option.status"
          :currency="option.currency"
          :current-balance="option.currentBalance"
          :available-balance="option.availableBalance"
          :show-name-and-nickname="showNameAndNickname"
          class="_account-select__selected-option"
        />
      </template>

      <!-- OPTION -->
      <template v-slot:option="{ option }">
        <div class="_account-select__option">
          <app-checkbox
            v-if="multiple"
            :key="isMultipleOptionSelected(option)"
            :checked="isMultipleOptionSelected(option)"
            class="_account-select__option__checkbox"
          />
          <app-account-preview
            :type="type"
            :account-nickname="option.accountNickname"
            :account-name="option.accountName"
            :account-number="option.accountNumber"
            :account-iban="option.accountIban"
            :status="option.status"
            :currency="option.currency"
            :current-balance="option.currentBalance"
            :available-balance="option.availableBalance"
            :show-name-and-nickname="showNameAndNickname"
          />
        </div>
      </template>
      <span slot="noResult">
        {{ noResultLabel || $t('components.accountSelect.noResult') }}
      </span>
      <span slot="noOptions">
        {{ noOptionsLabel || $t('components.accountSelect.noOptions') }}
      </span>
    </app-select>
  </div>
</template>

<script>
import AppCheckbox from '@/components/Checkbox'
import AppSelect from '@/components/Select'
import AppAccountPreview from '@/components/AccountPreview'

export default {
  components: {
    AppCheckbox,
    AppSelect,
    AppAccountPreview,
  },
  props: {
    type: {
      type: String,
      default: '',
    },
    options: {
      type: Array,
      default: () => [],
    },
    placeholder: {
      type: String,
      default: '',
    },
    noResultLabel: {
      type: String,
      default: '',
    },
    noOptionsLabel: {
      type: String,
      default: '',
    },
    allowEmpty: {
      type: Boolean,
      default: false,
    },
    showNameAndNickname: {
      type: Boolean,
      default: false,
    },
    minHeight: {
      type: Number,
      default: 40,
    },
    multiple: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    labelForSearch(option) {
      return `${option.accountName || ''}${option.accountNickname || ''}${option.accountIban || ''}${option.accountNumber || ''}` || JSON.stringify(option)
    },
    isMultipleOptionSelected(option) {
      if (!option || !this.$attrs.value || !this.$attrs['track-by']) {
        return false
      }

      const index = this.$attrs.value.findIndex(o => o[this.$attrs['track-by']] === option[this.$attrs['track-by']])
      return index > -1
    },
    handleRemove(remove, option) {
      // Fix to avoid select from opening when removing tags
      // Related to: https://github.com/shentao/vue-multiselect/issues/740
      const content = this.$refs.accountSelect.querySelectorAll('.multiselect__content-wrapper')
      content[0].style.display = 'none'
      document.activeElement.blur()

      remove(option)
    },
  },
}
</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";

  ._account-select {
    display: flex;

    /deep/ .multiselect {
      display: flex;
      flex-direction: column;
      flex-grow: 1;

      &__tags {
        flex-grow: 1;

        .multiselect__placeholder {
          color: $--color-text-placeholder;
        }
      }

      &:not(.multiselect--above) .multiselect__content-wrapper {
        top: 100%;
      }

    }

    /deep/ .multiselect__option {

      font-size: 14px;
      color: black;

      &--selected {
        color: $--color-primary;
        background-color: rgba($--color-primary, 0.1);
      }
    }

    &__option {
      display: flex;
      align-items: center;

      &__checkbox {
        pointer-events: none;
        margin-right: 14px;
      }

      /deep/ .el-checkbox__inner {
        width: 18px;
        height: 18px;
      }

      /deep/ .el-checkbox__inner::after {
        height: 10px;
        left: 6px;
      }
    }

    &__tag {
      display: inline-flex;
      align-items: center;
      margin-bottom: 9px;
      cursor: pointer;

      & + & {
        margin-top: 9px;
      }

      .el-icon-close {
        margin-top: 2px;
        margin-left: 5px;
        opacity: 0.6;
        padding: 3px;
        border-radius: 50%;
        background-color: $bg;
        font-size: 12px;
        transition: opacity 0.2s ease;

        @media screen and (min-width: $--sm) {
          opacity: 0;
        }
      }

      &:hover .el-icon-close {
        opacity: 0.6;
      }

      .el-icon-close:hover {
        opacity: 1;
      }
    }
    &__selected-option {
      font-size: 14px;
      color: black;
    }
  }
</style>
