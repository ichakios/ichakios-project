<template>
  <div class="_account-preview" :class="{ 'is-compact': type === 'compact' }">
    <div
      v-if="accountNickname || accountName"
      class="_account-preview__line"
    >
      <div class="_account-preview__account-name">
        <template v-if="showNameAndNickname && accountNickname && accountName">
          {{ accountName }}
          {{ accountName && accountNickname && ' - ' }}
          {{ accountNickname }}
        </template>
        <template v-else>
          {{ accountNickname || accountName }}
        </template>
      </div>
    </div>

    <div class="_account-preview__line">
      <app-tag
        v-if="status && accountStatuses[status.toLowerCase()]"
        size="mini"
        :type="accountStatuses[status.toLowerCase()].color"
        class="_account-preview__status"
      >
        {{ $t(accountStatuses[status.toLowerCase()].label) }}
      </app-tag>
      <span v-if="accountNumber || accountIban" class="_account-preview__account-number">
        {{ accountNumber ? accountNumber : `IBAN ${accountIban}` }}
      </span>
    </div>
    <div v-if="currentBalance || currentBalance === 0" class="_account-preview__line">
      <div class="_account-preview__balance" :class="{ 'is--negative': parseFloat(currentBalance) < 0 }">
        <small>{{ $t('components.accountSelect.currentBalance') }}: </small>
        <app-amount is-inline :amount="currentBalance" :currency="currency" />
        <!-- <span class="u-text-medium">{{ formatAmount(currentBalance, currency) }}</span> -->
      </div>
    </div>
    <div v-if="availableBalance || availableBalance === 0" class="_account-preview__line">
      <div class="_account-preview__balance" :class="{ 'is--negative': parseFloat(availableBalance) < 0 }">
        <small>{{ $t('components.accountSelect.availableBalance') }}: </small>
        <app-amount is-inline :amount="availableBalance" :currency="currency" />
      </div>
    </div>
  </div>
</template>

<script>
import { getLocalizedNumber } from '@/utils/formatNumber'
import { accountStatuses } from '@/constants/account'
import AppTag from '@/components/Tag'
import AppAmount from '@/components/Amount'

export default {
  components: {
    AppTag,
    AppAmount,
  },
  props: {
    type: {
      type: String,
      default: '',
    },
    accountNickname: {
      type: String,
      default: '',
    },
    accountName: {
      type: String,
      default: '',
    },
    accountNumber: {
      type: String,
      default: '',
    },
    accountIban: {
      type: String,
      default: '',
    },
    status: {
      type: String,
      default: '',
    },
    currency: {
      type: String,
      default: '',
    },
    currentBalance: {
      type: [Number, String],
      default: undefined,
    },
    availableBalance: {
      type: [Number, String],
      default: undefined,
    },
    showNameAndNickname: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      accountStatuses,
    }
  },
  methods: {
    formatAmount(amount, currency) {
      return getLocalizedNumber(amount, this.$i18n.locale, currency)
    },
  },
}
</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";
  ._account-preview {
    $this: &;
    line-height: 1.2;
    max-width: 100%;

    &__line + &__line {
      margin-top: 4px;
      #{$this}.is-compact & {
        margin-top: 2px;
      }
    }
    &__account-name {
      font-weight: bold;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 100%;
    }
    &__status {
      margin-right: 5px;
      padding: 0;
    }
    &__account-number {
      font-weight: bold;
      display: inline-block;
      vertical-align: middle;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 100%;

      #{$this}.is-compact & {
        font-size: 0.9em;
        font-weight: regular;
      }
    }
    &__balance {
      font-weight: 500;
      small {
        font-size: 0.9em;
      }
      #{$this}.is-compact & {
        font-size: 0.9em;
      }
      &.is--negative span {
        color: $--color-danger;
      }
    }
  }
</style>
