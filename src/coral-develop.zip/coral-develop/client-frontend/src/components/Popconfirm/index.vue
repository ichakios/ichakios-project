<template>
  <el-popover
    v-model="isVisible"
    :trigger="trigger"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <div
      class="_app-popconfirm"
      @mouseleave="handleMouseLeave"
    >
      <div
        class="_app-popconfirm__content"
        :style="{ maxWidth: contentMaxWidth }"
      >
        <slot name="content" :title="title">
          <p>{{ title }}</p>
        </slot>
      </div>
      <div class="_app-popconfirm__footer">
        <slot name="cancel" :cancel="cancel">
          <app-button
            :type="cancelButtonType"
            :size="buttonSize"
            @click="cancel()"
          >
            {{ cancelButtonText }}
          </app-button>
        </slot>

        <slot name="confirm" :confirm="confirm">
          <app-button
            :type="confirmButtonType"
            :size="buttonSize"
            @click="confirm()"
          >
            {{ confirmButtonText }}
          </app-button>
        </slot>
      </div>
    </div>
    <template slot="reference">
      <slot />
    </template>
  </el-popover>
</template>

<script>
import AppButton from '@/components/Button'

export default {
  components: {
    AppButton,
  },
  props: {
    title: {
      type: String,
      default: '',
    },
    contentMaxWidth: {
      type: String,
      default: '240px',
    },
    buttonSize: {
      type: String,
      default: 'small',
    },
    confirmButtonText: {
      type: String,
      default: 'Confirm',
    },
    confirmButtonType: {
      type: String,
      default: 'primary',
    },
    cancelButtonText: {
      type: String,
      default: 'Cancel',
    },
    cancelButtonType: {
      type: String,
      default: 'default',
    },
    open: {
      type: Boolean,
      default: false,
    },
    trigger: {
      type: String,
      default: 'click',
    },
    closeOnMouseLeave: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      isVisible: this.open || false,
    }
  },
  watch: {
    open() {
      this.isVisible = this.open
    },
  },
  methods: {
    openPopover() {
      this.isVisible = true
    },
    closePopover() {
      this.isVisible = false
      this.$emit('update:open', false)
    },
    handleMouseLeave() {
      if (this.trigger === 'manual' || this.closeOnMouseLeave) {
        this.closePopover()
      }
    },
    cancel() {
      this.closePopover()
      this.$emit('on-cancel')
    },
    confirm() {
      this.closePopover()
      this.$emit('on-confirm')
    },
  },
}
</script>

<style lang="scss" scoped>
  ._app-popconfirm {
    &__content {
      text-align: center;
      margin: 0 auto 8px auto;
      word-break: normal;
    }

    &__footer {
      display: flex;
      justify-content: space-between;
    }
  }
</style>
