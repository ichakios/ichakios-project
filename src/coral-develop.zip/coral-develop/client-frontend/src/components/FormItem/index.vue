<template>
  <div class="_form-item" :class="{ 'is--disabled': disabled }">
    <el-form-item
      :class="customClass"
      :style="cssVars"
      v-bind="$attrs"
      :required="required"
      v-on="$listeners"
    >
      <template v-slot:label>
        <div v-if="$attrs.label || $slots.label" class="_form-item__label">

          <div v-if="info" class="_form-item__label-info">
            <el-tooltip
              content="Tooltip"
              effect="light"
              placement="top"
            >
              <template v-slot:content>
                <div class="_form-item__tooltip">
                  <slot name="info">
                    {{ info }}
                  </slot>
                </div>
              </template>
              <app-icon-info class="_form-item__label-info-icon" />
            </el-tooltip>
          </div>
          <div class="_form-item__label-content">
            <slot name="label">
              {{ $attrs.label }}
            </slot>
            <span v-if="required" class="_form-item__required-hint">
              *
            </span>
          </div>
        </div>
      </template>

      <!-- Pass on all named slots -->
      <slot
        v-for="slot in Object.keys($slots).filter((x) => x !== 'label')"
        :slot="slot"
        :name="slot"
      />

      <!-- Pass on all scoped slots -->
      <template
        v-for="slot in Object.keys($scopedSlots).filter((x) => x !== 'label')"
        :slot="slot"
        slot-scope="scope"
      >
        <slot :name="slot" v-bind="scope" />
      </template>
    </el-form-item>
  </div>
</template>

<script>
import AppIconInfo from './IconInfo'

export default {
  inject: ['elForm'],
  components: {
    AppIconInfo,
  },
  props: {
    customClass: {
      type: String,
      default: '',
    },
    required: {
      type: Boolean,
      default: false,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    info: {
      type: String,
      default: '',
    },
  },
  computed: {
    cssVars() {
      return {
        '--margin-size': this.marginSize,
      }
    },
    form() {
      let parent = this.$parent
      let parentName = parent.$options.componentName
      while (parentName !== 'ElForm') {
        parent = parent.$parent
        parentName = parent.$options.componentName
      }
      return parent
    },
    marginSize() {
      const labelWidth = this.$attrs['label-width'] || this.form.labelWidth
      return labelWidth
    },
  },
}
</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";

  ._form-item {

    &.is--disabled &__label-content,
    &.is--disabled /deep/ .el-form-item__content {
      pointer-events: none;
      opacity: 0.5;
    }

    /deep/ .el-form-item {
      margin-bottom: 40px;
    }

    /deep/ label::after  {
      display: none !important; // Remove Element UI required asterisk
    }

    /deep/ .el-form-item__content {
      margin-left: var(--margin-size) !important;
      margin-right: 0 !important;
    }

    /deep/ .el-form-item__label {
      color: $--color-text-primary;
    }

    &__tooltip {
      max-width: 300px;
    }

    &__required-hint {
      color: $--color-danger;
    }

    &__label {
      display: flex;
      flex-wrap: nowrap;
      min-height: 40px;
      align-items: center;
      z-index: 1;
      position: relative;

      &-info {
        margin-left: -10px;
        padding: 10px;
        font-size: 16px;
        color: $--color-primary;
        opacity: 0.8;
        display: flex;
        align-items: center;
        justify-content: center;

        &-icon {
          width: 20px;
          height: 20px;
          fill: currentColor;
        }

        &:hover {
          opacity: 1;
        }
      }

      &-content {
        font-size: 16px;
        font-weight: 500;
        line-height: 1.4;
      }
    }
  }
</style>
