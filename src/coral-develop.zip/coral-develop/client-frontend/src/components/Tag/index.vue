<template>
  <el-tag
    v-bind="$attrs"
    class="_tag"
    v-on="$listeners"
  >
    <slot />
  </el-tag>
</template>

<script>
export default {
  name: 'AppTag',
}
</script>

<style lang="scss" scoped>
  @import '@/styles/_settings/index.scss';

  ._tag {
    background: transparent;
    border: none;
    font-size: 16px;
    font-weight: 500;
    padding: 0;

    &.el-tag--danger {
      color: $red;
    }

    &.el-tag--success {
      color: $green;
    }

    &.el-tag--medium {
      font-size: 16px;
    }

    &.el-tag--small {
      font-size: 14px;
    }

    &.el-tag--mini {
      font-size: 12px;
    }
  }

</style>
