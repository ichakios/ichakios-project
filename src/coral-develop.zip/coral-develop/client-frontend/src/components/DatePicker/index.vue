<template>
  <el-date-picker
    v-bind="$attrs"
    :class="`_date-picker _date-picker__icon ${!!customColor && 'is--' + customColor}`"
    popper-class="_date-picker__panel"
    prefix-icon="u-display-none"
    clear-icon="u-display-none"
    :format="format"
    v-on="$listeners"
  >
    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />

    <!-- Pass on all scoped slots -->
    <template
      v-for="slot in Object.keys($scopedSlots)"
      :slot="slot"
      slot-scope="scope"
    >
      <slot :name="slot" v-bind="scope" />
    </template>
  </el-date-picker>
</template>

<script>
export default {
  props: {
    customColor: {
      type: String,
      default: 'default',
    },
    format: {
      type: String,
      default: 'dd - MMM - yyyy',
    },
  },
}
</script>

<style lang="scss">
  @import "@/styles/_settings/index.scss";

  [dir] .el-date-table td.in-range div {
    background-color: rgba($bg, 0.6);
  }
</style>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";

  ._date-picker {
    $isError: ".el-form-item.is-error";

    /deep/ .el-input__inner,
    /deep/ .el-range-input {
      text-transform: uppercase;

      &::placeholder {
        text-transform: none;
      }
    }

    #{$isError} & {
      &.el-range-editor,
      /deep/ .el-input__inner {
        border-color: $--color-danger;
      }
    }

    &.is--light {
      &.el-range-editor,
      /deep/ .el-input__inner {
        border-color: $bg;
      }
    }

    &.is--dark {
      &.el-range-editor,
      /deep/.el-input__inner,
      /deep/.el-range-input {
        border-color: $--border-color-dark;
      }
    }

    &.is--light,
    &.is--dark {

      &.el-range-editor,
      /deep/.el-input__inner,
      /deep/ .el-range-input {
        background-color: $bg;

        &:focus {
          border-color: $--input-focus-border;
        }
      }

      &.is-disabled {
        &.el-range-editor,
        /deep/.el-input__inner {
          background-color: $--disabled-fill-base;
          border-color: $--disabled-border-base;
        }
      }
    }
  }

  ._date-picker__icon {
    display: flex;
    align-items: center;
    &::before {
      content: '';
      display: block;
      // this background image call the custom svg icon. to override the colour you need to use the fill props
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 27 27'%3E%3Cpath fill='%23EF8550' fill-rule='evenodd' d='M4.37 6.2a.56.56 0 01-.56-.56V4.55h-2.7v3.81h24.3v-3.8h-2.69v1.08a.56.56 0 11-1.11 0V4.55H4.93v1.1a.56.56 0 01-.56.55zM0 4v21.64a.56.56 0 00.56.56h25.42a.56.56 0 00.55-.56V4a.56.56 0 00-.55-.55h-3.26V.56a.56.56 0 10-1.11 0v2.88H4.93V.56a.56.56 0 00-1.12 0v2.88H.56a.56.56 0 00-.56.55zm1.11 21.09V9.48h24.3v15.6H1.12zm4.35-7.25h4.46v2.79H5.46v-2.8zm0-1.12h4.46v-2.78H5.46v2.78zm5.58 3.9v-2.78h4.46v2.79h-4.46zm-1.12 3.24v-2.12H5.46v2.12a.56.56 0 01-1.11 0v-2.12H2.68a.56.56 0 010-1.11h1.67v-2.8H2.68a.56.56 0 010-1.1h1.67v-2.8H2.68a.56.56 0 010-1.1h1.67v-2.34a.56.56 0 111.11 0v2.33h4.46V10.5a.56.56 0 111.12 0v2.33h4.46V10.5a.56.56 0 111.11 0v2.33h4.46V10.5a.56.56 0 111.12 0v2.33h1.67a.56.56 0 010 1.12h-1.67v2.78h1.67a.56.56 0 010 1.12h-1.67v2.79h1.67a.56.56 0 010 1.11h-1.67v2.12a.56.56 0 01-1.12 0v-2.12h-4.46v2.12a.56.56 0 01-1.11 0v-2.12h-4.46v2.12a.56.56 0 11-1.12 0zm11.15-3.23v-2.8h-4.46v2.8h4.46zm0-3.9v-2.8h-4.46v2.8h4.46zm-5.57-2.8h-4.46v2.8h4.46v-2.8z' clip-rule='evenodd'/%3E%3C/svg%3E%0A");
      background-size: contain;
      background-repeat: no-repeat;
      position:absolute;
      right: 10px;
      width: 30px;
      height: 20px;
      border-left: 7px solid #fff;
      box-shadow: -1px 0 0 $--border-color-base;
    }

    &.is--light {
      &::before{
        border-left: 7px solid $bg;
      }
    }

    &.is--dark {
      &::before{
        border-left: 7px solid $bg;
        box-shadow: -1px 0 0 $--border-color-dark;
      }
    }
    &.is-disabled{
      &::before{
        border-left: 7px solid $--disabled-fill-base;
        box-shadow: -1px 0 0 $--border-color-dark;
      }
    }

    &[type="daterange"] {
      &::before {
        margin-left: 0;
      }
    }

    // add padding due to the custom icon
    /deep/ input.el-input__inner {
      padding-left: 10px;
      color: black;
    }
  }

</style>

<style lang="scss">
  ._date-picker__panel {
    *[slot=sidebar],
    .el-picker-panel__sidebar {
      width: 160px;
    }
    *[slot=sidebar] + .el-picker-panel__body,
    .el-picker-panel__sidebar + .el-picker-panel__body {
      margin-left: 160px;
    }

    .el-picker-panel__shortcut {
      line-height: 1.4;
      padding: 4px 10px;
    }
  }
</style>
