<template>
  <multiselect
    v-bind="$attrs"
    :class="`${!!customColor && 'is--' + customColor}`"
    :placeholder="$attrs.placeholder || $t('components.multiselect.placeholder')"
    :tag-placeholder="$attrs['tag-placeholder'] || $t('components.multiselect.tagPlaceholder')"
    :select-label="$attrs['select-label'] || $t('components.multiselect.selectLabel')"
    :select-group-label="$attrs['select-group-label'] || $t('components.multiselect.selectGroupLabel')"
    :selected-label="$attrs['selected-label'] || $t('components.multiselect.selectedLabel')"
    :deselect-label="$attrs['deselect-label'] || $t('components.multiselect.deselectLabel')"
    :deselect-group-label="$attrs['deselect-group-label'] || $t('components.multiselect.deselectGroupLabel')"
    v-on="$listeners"
  >
    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />

    <!-- Pass on all scoped slots -->
    <template
      v-for="slot in Object.keys($scopedSlots)"
      :slot="slot"
      slot-scope="scope"
    >
      <slot :name="slot" v-bind="scope" />
    </template>
  </multiselect>
</template>

<script>
import Multiselect from 'vue-multiselect'

export default {
  components: {
    Multiselect,
  },
  props: {
    customColor: {
      type: String,
      default: 'default',
    },
  },
}
</script>

<style lang="scss">
  @import "@/styles/_settings/index.scss";
  body .el-form-item.is-error {
    .multiselect__tags {
      border: 1px solid $--color-danger;
    }
  }

  .multiselect {
    $this: &;
    color: black;
    &__tags {
      border-color: $--border-color-base;
      transition: border-color 0.2s;
      border-radius: 0!important;

      #{$this}--active & {
        border-color: $--color-primary !important;
      }
    }

    &__tag {
      .multiselect__placeholder {
        color: black;
        padding-left: 6px;
      }
    }

    &__spinner {
      &::before,
      &::after {
        border-top-color: $--color-primary;
      }
    }

    &__select {
      &::before {
        content: "\e6e1";
        color: $--color-primary;
        font-family: 'element-icons' !important;
        font-style: normal;
        font-weight: normal;
        font-variant: normal;
        text-transform: none;
        line-height: 1;
        vertical-align: baseline;
        display: flex;
        justify-content: center;
        align-items: center;
        border: none;
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        margin-top: 0 !important;
        transform: rotate(180deg);
      }
    }

    &__content {
      max-width: 100%;
    }

    &__content-wrapper {
      margin-top: 5px;
      border: 1px solid #dfe4ed;
      box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
      border-radius: 4px;
    }

    &__option,
    &__single,
    &__input {
      font-size: 14px;
      padding-left: 6px;
    }

    &__option {
      padding: 14px;

      &--highlight {
        background-color: #F5F7FA;
        color: $--color-text-primary;

        &::after {
          background: transparent !important;
          color: $--color-text-primary;
        }
      }

      &--selected {
        background-color: #fff;
        color: $--color-primary;

        &::after {
          color: $--color-primary;
        }
      }

      &--highlight#{&}--selected {
        background-color: #F5F7FA;
        color: $--color-primary;

        &::after {
          color: $--color-text-primary;
        }
      }

      &--disabled {
        background-color: #fbfbfb !important;
        color: #909090 !important;
      }
    }

    &__tag {
      background-color: $--color-primary;
      border-radius: 2px;
    }

    &__tag-icon {
      border-radius: 0 2px 2px 0;

      &:after {
        color: $--color-white;
        font-size: 18px;
        opacity: 0.5;
        transition: opacity 0.3s ease;
      }

      &:hover {
        background-color: darken($--color-primary, 5%);
        &:after {
          opacity: 1;
        }
      }
    }

    &.is--light #{$this},
    &.is--dark #{$this}{
      &__input,
      &__single,
      &__tags,
      &__spinner {
        background-color: $bg;
      }
    }

    &.is--dark #{$this} {
      &__tags {
        border-color: $--border-color-dark;
      }
    }

    &.is--light #{$this} {
      &__tags {
        border-color: $bg;
      }
    }
  }

</style>
