<template>
  <app-approval-history-ui
    :history="history"
    :loading="isLoading"
    v-bind="$attrs"
    v-on="$listeners"
  />
</template>

<script>
import { getHistoryById } from '@/services/history/history.service'
import AppApprovalHistoryUi from './ApprovalHistoryUI'

export default {
  components: {
    AppApprovalHistoryUi,
  },
  props: {
    processId: {
      type: [String, Number],
      default: null,
    },
  },
  data() {
    return {
      history: null,
      isLoading: false,
    }
  },
  watch: {
    processId: {
      immediate: true,
      async handler(processId) {
        if (!processId) {
          this.history = null
          return
        }

        this.isLoading = true

        const [error, data] = await getHistoryById(processId)

        this.isLoading = false

        if (error) {
          this.$message({
            message: this.$t('approvalHistory.messages.loadError'),
            type: 'error',
          })
          return
        }

        this.history = (data || {}).history
      },
    },
  },
}
</script>
