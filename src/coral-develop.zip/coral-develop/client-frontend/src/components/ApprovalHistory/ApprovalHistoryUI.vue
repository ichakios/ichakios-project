<template>
  <div>
    <span v-if="loading" class="el-icon-loading" />
    <el-timeline
      v-if="history && !loading"
      class="u-pl-1 u-mt-1 _approval-history"
    >
      <el-timeline-item
        v-for="(item, index) in displayHistory"
        :key="index"
        class="_approval-history__item"
      >
        <div class="_approval-history__item-content">
          <div>
            {{ getLabelActionBy(item) }}
            <span
              v-for="(user, i) in (item.candidates || []).filter(x => x && x.isUser)"
              :key="user.name"
            >{{ i > 0 ? ', ' : '' }}{{ user.name }}</span>
          </div>
          <small v-if="showDate && item.instant" class="u-text-medium u-display-block u-mt-1">
            {{ dayjs(item.instant).format('DD - MMM - YYYY HH:mm').toUpperCase() }}
          </small>
        </div>
      </el-timeline-item>
    </el-timeline>
  </div>
</template>

<script>
import dayjs from 'dayjs'
import { approvalHistoryStepList } from '@/constants/approvalHistory'

export default {
  props: {
    history: {
      type: Array,
      default: () => [],
    },
    loading: {
      type: Boolean,
      default: false,
    },
    showDate: {
      type: Boolean,
      default: true,
    },
  },
  data() {
    return {
      dayjs,
    }
  },
  computed: {
    displayHistory() {
      return (this.history || []).filter(item => (item.candidates || []).some(user => user.isUser))
    },
  },
  methods: {
    getLabelActionBy(item) {
      if (
        !item ||
        !item.step ||
        !Object.keys(approvalHistoryStepList).includes(item.step) ||
        !Object.keys(approvalHistoryStepList[item.step].labelsBy).includes(item.state)
      ) {
        return this.$t('approvalHistory.undefinedActionBy')
      }

      return this.$t(approvalHistoryStepList[item.step].labelsBy[item.state])
    },
  },
}
</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";

  ._approval-history {
    &__item {
      position: relative;
      padding-top: 14px;
      padding-bottom: 10px;
    }

    &__item-content {
      margin-top: -14px;
      padding: 15px 20px;
      background: rgba(0, 0, 0, 0.05);
      font-size: 14px;
    }
  }
</style>
