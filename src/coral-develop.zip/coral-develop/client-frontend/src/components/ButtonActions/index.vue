<template>
  <app-button
    class="_app-button-actions"
    :icon="icon"
    circle
    v-bind="$attrs"
    v-on="$listeners"
  />
</template>

<script>
import AppButton from '@/components/Button'

export default {
  name: 'AppButtonActions',
  components: {
    AppButton,
  },
  props: {
    icon: {
      type: String,
      default: 'el-icon-more',
    },
  },
}
</script>

<style lang="scss" scoped>
  @import '@/styles/_settings/index.scss';

  ._app-button-actions {
    background-color: transparent;
    transform: rotate(90deg);
    transition: 0.2s;
    border-color: transparent;

    &:hover {
      background-color: $--color-primary;
      color: $--color-white;
      border-color: transparent;
    }

    &.is-disabled {
      background-color: rgba($--color-text-secondary, 0.1);
      color: rgba($--color-text-primary, 0.8);
    }
  }
</style>
