<template>
  <el-button
    ref="button"
    :class="{
      '_button': true,
      'is--full': full,
      'is--large': size === 'huge',
    }"
    :size="size"
    :type="type"
    :native-type="nativeType"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />

    <!-- Pass on all scoped slots -->
    <template
      v-for="slot in Object.keys($scopedSlots)"
      :slot="slot"
      slot-scope="scope"
    >
      <slot :name="slot" v-bind="scope" />
    </template>
  </el-button>
</template>

<script>
export default {
  name: 'AppButton',
  props: {
    full: {
      type: Boolean,
      default: false,
    },
    large: {
      type: Boolean,
      default: false,
    },
    size: {
      type: String,
      default: null,
    },
    nativeType: {
      type: String,
      default: 'button',
    },
    type: {
      type: String,
      default: 'button',
    },
  },
  watch: {
    type() {
      this.checkButtonType()
    },
  },
  mounted() {
    this.checkButtonType()
  },
  methods: {
    checkButtonType() {
      const button = this.$refs.button

      if (button.type !== this.nativeType) {
        button.$el.type = this.nativeType
      }
    },
  },
}
</script>

<style lang="scss" scoped>
  @import '@/styles/_settings/index.scss';

// Default button
.el-button--button {
  &:hover,
  &:active,
  &:focus {
    background: darken(white, 2%);
    color: lighten(black, 20%);
    border: 1px solid darken($bg, 10%);
  }
}

._button {
  font-weight: 500;
  &:not(.el-button--mini):not(.el-button--small):not(.el-button--medium):not(.el-button--large):not(.el-button--huge) {
    font-size: 16px;
  }

  & + ._button {
    // needed to override the default .el-button + .el-button
    margin: 0;
  }

  :not(html[lang^="ar"]) &::first-letter  {
    text-transform: uppercase;
  }

  &.is--large {
    padding: 2rem 2.4rem;
    font-size: 1.3em;
  }

  &.is--full {
    border-radius: 0;
    display: block;
    width: 100%;
  }
}

</style>
