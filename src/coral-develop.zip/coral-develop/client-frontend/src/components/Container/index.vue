<template>
  <el-container
    class="_container"
    :class="{'_container--has-fixed-bottom': hasFixedBottom}"
    v-bind="$attrs"
    direction="vertical"
    v-on="$listeners"
  >
    <slot />
  </el-container>
</template>

<script>
export default {
  props: {
    hasFixedBottom: {
      type: Boolean,
      default: false,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '@/styles/_settings/index.scss';

._container {
  margin: 2rem;

  &--has-fixed-bottom {
    padding-bottom: $paddingBottomWithFixedBottom;
  }
}
</style>
