<template>
  <app-select
    v-bind="$attrs"
    :show-labels="false"
    :options="countries"
    :custom-label="displayCountry"
    :loading="loading || isLoading"
    :disabled="loading || isLoading || disabled"
    v-on="$listeners"
  >
    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />

    <!-- Pass on all scoped slots -->
    <template
      v-for="slot in Object.keys($scopedSlots)"
      :slot="slot"
      slot-scope="scope"
    >
      <slot :name="slot" v-bind="scope" />
    </template>
  </app-select>
</template>

<script>
import AppSelect from '@/components/Select'
import countries from 'i18n-iso-countries'

export default {
  name: 'AppCountrySelect',
  components: {
    AppSelect,
  },
  props: {
    loading: {
      type: Boolean,
      default: false,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      countries: [],
      isLoading: true,
    }
  },
  computed: {
    locale() {
      return this.$i18n.locale
    },
  },
  watch: {
    locale() {
      this.getCountries()
    },
  },
  mounted() {
    this.getCountries()
  },
  methods: {
    getCountries() {
      this.isLoading = true
      this.countries = Object.keys(countries.getNames('en'))
      this.isLoading = false
    },
    displayCountry(alpha2) {
      return countries.getName(alpha2, this.locale.substring(0, 2))
    },
  },
}
</script>
