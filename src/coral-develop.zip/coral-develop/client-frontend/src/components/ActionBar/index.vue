<template>
  <transition name="el-fade-in">
    <div v-show="isOpen" class="_action-bar u-shape-card">
      <slot />
    </div>
  </transition>
</template>

<script>
export default {
  name: 'AppActionBar',
  props: {
    isOpen: {
      type: Boolean,
      default: false,
    },
  },
}
</script>

<style lang="scss">
  @import '@/styles/_settings/index.scss';
  $baseMargin: 32px;

  ._action-bar {
    margin: $baseMargin;
  }

  .hideSidebar.mobile ._action-bar {
    margin-left: $baseMargin;
  }

  .hideSidebar ._action-bar {
    margin-left: $sideBarWidthSmall + $baseMargin;
  }

  .openSidebar ._action-bar {
    margin-left: $sideBarWidth + $baseMargin;
  }
</style>

<style lang="scss" scoped>
  ._action-bar {
    transition: all linear 200ms;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 999;

    /deep/ .a-button + .a-button {
      margin-top: 0;
    }
  }
</style>
