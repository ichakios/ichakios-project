<template>
  <div
    class="_card"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <div
      v-if="$slots.header"
      :style="{
        padding: padding + 'px',
        paddingBottom: $slots.body ? 0 : padding + 'px',
      }"
    >
      <slot name="header" />
    </div>

    <div
      v-if="$slots.body"
      class="_card__body"
      :style="{ padding: padding + 'px' }"
    >
      <slot name="body" />
    </div>

    <slot />
  </div>
</template>

<script>
export default {
  name: 'AppCard',
  props: {
    padding: {
      type: Number,
      default: 20,
    },
  },
}
</script>

<style lang="scss" scoped>
  @import '@/styles/_settings/index.scss';

  ._card {
    display: flex;
    flex-direction: column;
    background: #fff;
    box-shadow: $box-shadow;
    border-radius: $--border-radius-base;
    width: 100%;
    text-align: left;
  }
</style>
