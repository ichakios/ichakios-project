<template>
  <el-link
    class="a-link"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <slot />
  </el-link>
</template>
