<template>
  <div>
    <app-link href="https://element.eleme.io" target="_blank">Default</app-link>
    <app-link type="primary">Primary</app-link>
    <app-link type="success">Success</app-link>
    <app-link type="warning">Warning</app-link>
    <app-link type="danger">Danger</app-link>
    <app-link type="info">Info</app-link>
  </div>
</template>

<script>

import AppLink from './'

export default {
  components: { AppLink },
}
</script>
