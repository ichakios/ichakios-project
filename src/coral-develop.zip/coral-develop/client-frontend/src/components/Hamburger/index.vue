<template>
  <div
    style="padding: 0 15px;"
    @click="toggleClick"
  >

    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="36"
      height="36"
      viewBox="0 0 36 36"
      class="hamburger"
      :class="{'is-active': isActive}"
    >
      <g id="Group_49" data-name="Group 49" transform="translate(-376.734 -669.965)">
        <path id="Path_120" data-name="Path 120" d="M394.734,669.965h0a18,18,0,1,1-18,18,18,18,0,0,1,18-18" fill="#f26731" />
        <path id="Path_121" data-name="Path 121" d="M388.856,692.741l5.878-4.408,5.877,4.408m-11.755-7.347,5.878-4.408,5.877,4.408" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.837" />
      </g>
    </svg>

  </div>
</template>

<script>
export default {
  name: 'Hamburger',
  props: {
    isActive: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    toggleClick() {
      this.$emit('toggleClick')
    },
  },
}
</script>

<style scoped>
.hamburger {
  display: inline-block;
  vertical-align: middle;
  transform: rotate(90deg);
}

.hamburger.is-active {
  transform: rotate(-90deg);
}
</style>
