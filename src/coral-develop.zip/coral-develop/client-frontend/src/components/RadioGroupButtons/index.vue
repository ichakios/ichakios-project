<template>
  <el-radio-group
    class="_app-radio-group-buttons"
    :class="{ 'is--full': isFull }"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <el-radio-button
      v-for="option in options"
      :key="option.value"
      :label="option.value"
      :disabled="option.disabled"
    >
      {{ option.label }}
      <template v-if="option.sublabel">
        <br>
        <small>{{ option.sublabel }}</small>
      </template>
    </el-radio-button>
  </el-radio-group>
</template>

<script>
export default {
  props: {
    isFull: {
      type: Boolean,
      default: false,
    },
    options: {
      type: Array,
      default: () => [],
    },
  },
}

</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";
  ._app-radio-group-buttons {
    display: inline-flex;

    &:not(.el-radio-button--mini):not(.el-radio-button--small):not(.el-radio-button--medium):not(.el-radio-button--large):not(.el-radio-button--huge) {
      /deep/ .el-radio-button__inner {
        display: flex;
        flex-direction: column;
        justify-content: center;
        width: 100%;
        font-size: 16px;
        font-weight: 500;

        small {
          font-size: 0.8em;
        }
      }
    }

    &.is--full {
      width: 100%;
    }

    &[disabled] /deep/ .el-radio-button,
    /deep/ .el-radio-button.is-disabled {
      opacity: 0.6;
    }

    /deep/ .el-radio-button {
      vertical-align: middle;
      display: flex;
      flex-grow: 1;
    }

    /deep/ .el-radio-button.is-active {
      .el-radio-button__inner {
        background: black;
        border-color: black;
        box-shadow: -1px 0 0 0 black;
      }
    }
  }
</style>
