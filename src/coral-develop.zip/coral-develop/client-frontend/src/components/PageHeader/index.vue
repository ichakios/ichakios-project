<template>
  <el-container class="o-heading">
    <el-row :gutter="20">
      <el-col :xs="24">
        <app-heading :size="1">
          {{ computedTitle }}
        </app-heading>
      </el-col>
    </el-row>
    <el-row
      v-if="!!$slots.default"
      class="o-heading__right"
    >
      <slot />
    </el-row>
  </el-container>
</template>

<script>
import AppHeading from '@/components/Heading'
import { getPageTitle } from '@/utils/getPageTitle'
export default {
  components: {
    AppHeading,
  },
  props: {
    title: {
      type: String,
      default: null,
    },
  },
  data() {
    return {
      i18n: this.$i18n,
    }
  },
  computed: {
    computedTitle() {
      return this.title ? this.title : getPageTitle(this.$route.meta.title, this.$route)
    },
  },
}
</script>

<style lang="scss" scoped>
.o-heading {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;

  &__right {
    display: flex;
  }
}
</style>
