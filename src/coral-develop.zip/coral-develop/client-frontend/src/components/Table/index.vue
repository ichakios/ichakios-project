<template>
  <el-table
    :class="{
      _table: true,
      'is-expanded-with-shadow': expandWithShadow,
    }"
    :header-cell-class-name="`m-cell ${$attrs['header-cell-class-name'] || ''}`"
    :stripe="$attrs['stripe']"
    :border="true"
    :empty-text="$attrs['empty-text'] || $t('components.table.noData')"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />

    <!-- Pass on all scoped slots -->
    <template
      v-for="slot in Object.keys($scopedSlots)"
      :slot="slot"
      slot-scope="scope"
    >
      <slot :name="slot" v-bind="scope" />
    </template>
  </el-table>
</template>

<script>

export default {
  name: 'AppTable',
  props: {
    expandWithShadow: {
      type: Boolean,
      default: false,
    },
  },
}
</script>

<style lang="scss" scoped>
@import '@/styles/_settings/index.scss';

._table {
  &.is-expanded-with-shadow {
    /deep/ .el-table__expanded-cell {
      box-shadow: 0 2px 2px rgba(black, 0.08) inset,
                  0 7px 7px rgba(black, 0.04) inset;

      padding: 30px 0;
      padding-left: 57px;
      border-bottom: 1px solid $--border-color-light;
    }
  }

 /deep/ th.is-leaf {
   border-bottom-width: 4px;
 }
}
</style>
