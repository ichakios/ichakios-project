<template>
  <div
    class="_app-table-column-head"
    :class="setAlign()"
  >
    <div class="_app-table-column-head__content">
      <div
        v-for="(option, index) in options"
        :key="option.value"
      >
        <el-link
          :underline="false"
          :type="sort.prop === option.value ? 'primary' : 'default'"
          :class="sort.prop === option.value ? 'underline-link' : ''"
          @click="handleSort({ prop: option.value })"
        >
          {{ option.label }}
        </el-link>

        <span
          v-if="index + 1 < options.length"
          class="mx-1"
        >
          {{ ' / ' }}
        </span>
      </div>
    </div>
    &nbsp;
    <app-dynamic-sort-icon
      :order="getSortOrderForProps(options.map(option => option.value))"
      @sortOrderChange="handleSort({ order: $event, group: options.map(option => option.value) })"
    />
  </div>
</template>

<script>
import AppDynamicSortIcon from '@/components/DynamicSortIcon'

export default {
  name: 'AppTableColumnHead',
  components: {
    AppDynamicSortIcon,
  },
  props: {
    minWidth: {
      type: Number,
      default: 50,
    },
    align: {
      type: String,
      default: 'left',
    },
    options: {
      type: Array,
      default: () => [],
    },
    sort: {
      type: Object,
      default: () => {},
    },
  },
  methods: {
    getSortOrderForProps(props = []) {
      return props.indexOf(this.sort.prop) !== -1 ? this.sort.order : null
    },
    handleSort({ prop, order, group }) {
      this.$emit('update-sort', { prop, order, group })
    },
    setAlign() {
      switch (this.align) {
        case 'right': return 'is--right'
        case 'center': return 'is--center'
        default: return
      }
    },
  },
}
</script>

<style lang="scss" scoped>
  ._app-table-column-head {
    display: flex;
    align-items: center;
    width: 100%;
    font-size: 16px;

    &.is--right {
      justify-content: flex-end
    }

    &.is--center {
      justify-content: center
    }

    &__content {
      display: flex;
      overflow: hidden;

      > div:last-child {
        overflow: hidden;
      }
    }
  }
</style>
