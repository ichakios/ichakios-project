<template>
  <app-input
    ref="input"
    v-model="inputValue"
    v-currency
    v-bind="_attrs"
    v-on="_listeners"
  >
    <span v-if="currency" slot="append">
      {{ currency }}
    </span>

    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />

    <!-- Pass on all scoped slots -->
    <template
      v-for="slot in Object.keys($scopedSlots)"
      :slot="slot"
      slot-scope="scope"
    >
      <slot :name="slot" v-bind="scope" />
    </template>
  </app-input>
</template>

<script>
import AppInput from '@/components/Input'
import { getLocalizedNumber } from '../../utils/formatNumber'

export default {
  name: 'AppInputCurrency',
  components: {
    AppInput,
  },
  props: {
    value: {
      type: Number,
      default: 0,
    },
    currency: {
      type: String,
      default: null,
    },
  },
  data() {
    return {
      innerValue: '0',
    }
  },
  computed: {
    inputValue: {
      get() {
        return this.innerValue
      },
      set(value) {
        this.innerValue = value
        this.$emit('input', this.$parseCurrency(value))
      },
    },
    _attrs() {
      const { 'value': _, ...attrs } = this.$attrs
      return attrs
    },
    _listeners() {
      const { 'input': _, ...listeners } = this.$listeners
      return listeners
    },
  },
  watch: {
    value: {
      immediate: true,
      handler(value) {
        if (value === null || value === this.$parseCurrency(this.innerValue)) {
          return
        }
        this.innerValue = getLocalizedNumber(value, this.$i18n.locale)
      },
    },
  },
  methods: {
    focus() {
      this.$refs.input.focus()
    },
  },
}
</script>
