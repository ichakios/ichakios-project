<template>
  <el-upload
    action="#"
    class="_uploader"
    :accept="accept"
    :auto-upload="false"
    :show-file-list="false"
    :on-change="onChange"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <el-button
      type="text"
      class="_uploader__button"
    >
      <em class="el-icon-plus" />
      {{ label ? label : $t('components.uploader.add') }}
      <small v-if="maxSize">
        ({{ $t('components.uploader.maxSize', { maxSize: formatBytes(maxSize) }) }})
      </small>
    </el-button>
  </el-upload>
</template>

<script>
import { formatBytes } from '@/utils/formatNumber'

export default {
  props: {
    onChange: {
      type: Function,
      default: () => {},
    },
    accept: {
      type: String,
      default: null,
    },
    maxSize: {
      type: Number,
      default: null,
    },
    label: {
      type: String,
      default: null,
    },
  },
  methods: {
    formatBytes,
  },
}
</script>

<style lang="scss" scoped>
  @import '@/styles/_settings/index.scss';

  ._uploader {
    display: block;

    /deep/ .el-upload--text {
      width: 100%;
    }

    &__button {
      display: block;
      width: 100%;
      text-align: center;
      font-weight: bold;
      padding-left: 15px;
      padding-right: 15px;
      border: 1px dashed rgba(0, 0, 0, 0.2);
      color: #6D6D6D;

      &:hover {
        border-color: $--color-primary;
      }

      &:hover,
      &:focus {
        color: $--color-primary;
      }
    }
  }
</style>
