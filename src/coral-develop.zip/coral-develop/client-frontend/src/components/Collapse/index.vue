<template>
  <el-collapse
    v-model="openedPanel"
    :class="{
      '_collapse': true,
      'u-shape-card': shape === 'card',
      'is--none': shape === 'none',
    }"
  >
    <el-collapse-item
      v-bind="$attrs"
      name="1"
      v-on="$listeners"
    >
      <!-- Pass on all named slots -->
      <slot
        v-for="slot in Object.keys($slots)"
        :slot="slot"
        :name="slot"
      />

      <!-- Pass on all scoped slots -->
      <template
        v-for="slot in Object.keys($scopedSlots)"
        :slot="slot"
        slot-scope="scope"
      >
        <slot
          :name="slot"
          v-bind="scope"
        />
      </template>
    </el-collapse-item>
  </el-collapse>
</template>

<script>
export default {
  name: 'AppCollapse',
  props: {
    defaultOpened: {
      type: Boolean,
      default: false,
    },
    shape: {
      type: String,
      default: 'card', // card | none
    },
  },
  data() {
    const openedPanel = this.defaultOpened ? ['1'] : []
    return {
      openedPanel,
    }
  },
}
</script>

<!-- ⚠ GLOBAL STYLE ⚠ -->
<style lang="scss" scoped>
@import '@/styles/_settings/index.scss';
._collapse {
  /deep/ .el-collapse-item {
    &__header {
      padding: 1rem;
    }

    &__content {
      padding: 1rem;
    }
  }

  &.is--none {
    border-top: 0;

    /deep/ .el-collapse-item {
      &__header {
        padding: 0;
        border-top: 0;
        border-bottom: 0;
        font-weight: bold;
        font-size: 14px;

        .el-collapse-item__arrow {
          margin-right: auto;
          margin-left: 5px;
          margin-top: 1px;
          color: $--color-primary
        }
      }

      &__content {
        padding: 0;
      }

      .el-collapse-item__wrap {
        border-bottom: 0;
      }
    }
  }
}
</style>
