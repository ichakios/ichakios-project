<template>
  <el-slider
    v-bind="$attrs"
    :class="`_slider ${!!customColor && 'is--' + customColor}`"
    v-on="$listeners"
  >
    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />

    <!-- Pass on all scoped slots -->
    <template
      v-for="slot in Object.keys($scopedSlots)"
      :slot="slot"
      slot-scope="scope"
    >
      <slot :name="slot" v-bind="scope" />
    </template>
  </el-slider>
</template>

<script>

export default {
  props: {
    customColor: {
      type: String,
      default: 'default',
    },
  },
}
</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";

  ._slider:not(.is-checked) {
    /deep/.el-slider__runway {
      background-color: darken($bg, 5%);
    }

    &.is-disabled {
      /deep/.el-slider__runway {
        background-color: $--disabled-fill-base;
        border-color: $--disabled-border-base;
      }
    }

    &:not(.is--dark):not(.is--light) {
      /deep/.el-slider__runway {
        background-color: $--color-white;
        outline: 1px solid $--border-color-base;
      }
    }

    &.is--dark {
      /deep/.el-slider__runway {
        background-color: darken($bg-dark, 5%);
      }
    }
  }

</style>
