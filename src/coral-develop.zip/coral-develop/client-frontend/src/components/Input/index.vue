<template>
  <el-input
    ref="input"
    :class="`_input ${!!customColor && 'is--' + customColor}`"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <!-- Pass on all named slots -->
    <slot
      v-for="slot in Object.keys($slots)"
      :slot="slot"
      :name="slot"
    />

    <!-- Pass on all scoped slots -->
    <template
      v-for="slot in Object.keys($scopedSlots)"
      :slot="slot"
      slot-scope="scope"
    >
      <slot :name="slot" v-bind="scope" />
    </template>
  </el-input>
</template>

<script>

export default {
  props: {
    customColor: {
      type: String,
      default: 'default',
    },
  },
  methods: {
    focus() {
      this.$refs.input.focus()
    },
  },
}
</script>

<style lang="scss" scoped>
  @import "@/styles/_settings/index.scss";

  ._input.el-input,
  ._input.el-textarea {
    $isError: ".el-form-item.is-error";

    /deep/ .el-input__count {
      border-radius: 3px;
      line-height: 20px;
      padding: 2px 5px;
      right: 15px;
    }

    /deep/ .el-input-group__append,
    /deep/ .el-input-group__prepend {
      background-color: $--input-addon-background-color;
      color: $--color-text-regular;
    }

    &.is-disabled {
      /deep/ .el-input-group__append,
      /deep/ .el-input-group__prepend {
        background-color: $--disabled-fill-base;
      }
    }

    #{$isError} & {
      /deep/ .el-input__inner {
        border-color: $--color-danger;
      }
    }

    &.is--light {
      /deep/ .el-input__inner,
      /deep/ .el-textarea__inner {
        border-color: $bg;
      }

      /deep/ .el-input-group__append,
      /deep/ .el-input-group__prepend {
        border: 0;
        box-shadow: inset 0 0 0 1px $bg;
      }
    }

    &.is--dark {
      /deep/.el-input__inner,
      /deep/ .el-textarea__inner {
        border-color: $--border-color-dark;
      }

      /deep/ .el-input-group__append,
      /deep/ .el-input-group__prepend {
        border-color: $--border-color-dark;
      }
    }

    &.is--light,
    &.is--dark {
      /deep/ .el-input__count-inner,
      /deep/.el-input__inner,
      /deep/ .el-textarea__inner {
        background-color: $bg;

        &:focus {
          border-color: $--input-focus-border;
        }
      }

      /deep/ .el-input-group__append,
      /deep/ .el-input-group__prepend {
        background-color: $bg;
      }

      &.is-disabled {
        /deep/.el-input__inner,
        /deep/ .el-textarea__inner {
          background-color: $--disabled-fill-base;
          border-color: $--disabled-border-base;
        }

        /deep/ .el-input-group__append,
        /deep/ .el-input-group__prepend {
          background-color: $--disabled-fill-base;
        }
      }
    }
  }
</style>
