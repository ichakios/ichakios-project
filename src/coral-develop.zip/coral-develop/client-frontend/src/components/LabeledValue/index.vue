<template>
  <div
    class="_labeled-value"
    :class="{
      'u-text-align-right': align === 'right',
      'u-text-align-center': align === 'center',
      'is--inline': isInline,
    }"
  >
    <div class="u-text-ellipsis _labeled-value__label">
      <slot name="label">
        {{ label }}
      </slot>
    </div>
    <div class="_labeled-value__value">
      <slot />
    </div>
  </div>
</template>

<script>

export default {
  props: {
    label: {
      type: String,
      required: true,
    },
    align: {
      type: String,
      required: false,
      default: 'left',
    },
    isInline: {
      type: Boolean,
      required: false,
      default: false,
    },
  },
}

</script>
<style lang="scss" scoped>
  @import '@/styles/_settings/index.scss';

  ._labeled-value {
    padding: 0 15px;

    &.is--inline > * {
      display: inline-block;
      width: auto;
      vertical-align: middle;
    }

    &.is--inline > &__value {
      margin: 0;
      padding-left: 5px;
    }

    &__label {
      font-size: 16px;
      font-weight: 500;
    }

    &__value {
      margin: 4px 0 0 0;
      font-size: 16px;
    }
  }
</style>
