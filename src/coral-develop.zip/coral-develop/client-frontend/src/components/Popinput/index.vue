<template>
  <el-popover
    v-model="isVisible"
    :trigger="trigger"
    :width="width"
    @after-leave="reset"
  >
    <div
      class="_app-input"
      @mouseleave="handleMouseLeave"
    >
      <div class="_app-input__content">
        <slot
          name="content"
          :title="title"
        >
          <p class="_app-input__title">
            {{ title }}
          </p>
        </slot>

        <el-form
          label-position="left"
          :label-width="labelWidth"
          class="u-mt-3 u-mb-4"
        >
          <app-form-item
            :label="label"
            :error="getCustomFieldError($v.input)"
            :show-message="$v.input.$error"
            required
          >
            <app-input
              v-model="input"
              custom-color="light"
              :maxlength="maxLength"
              :show-word-limit="showWordLimit"
              :placeholder="placeholder"
              :disabled="loading"
              @input="
                () => {
                  $emit('on-change')
                  $v.input.$touch
                }"
            />
          </app-form-item>
        </el-form>
      </div>
      <div class="_app-input__footer">
        <slot
          name="cancel"
          :cancel="cancel"
        >
          <app-button
            :type="cancelButtonType"
            :size="buttonSize"
            @click="cancel()"
          >
            {{ cancelButtonText }}
          </app-button>
        </slot>

        <slot
          v-if="showDeleteButton"
          name="delete"
          :onDelete="onDelete"
        >
          <app-button
            class="u-mr-auto u-ml-1"
            :type="deleteButtonType"
            :size="buttonSize"
            :disabled="$v.$error || loading"
            @click="onDelete()"
          >
            {{ deleteButtonText }}
          </app-button>
        </slot>

        <slot
          name="confirm"
          :confirm="confirm"
        >
          <app-button
            :type="confirmButtonType"
            :size="buttonSize"
            :disabled="$v.$error || loading"
            :loading="loading"
            @click="confirm()"
          >
            {{ confirmButtonText }}
          </app-button>
        </slot>
      </div>
    </div>
    <template slot="reference">
      <slot />
    </template>
  </el-popover>
</template>

<script>
import AppFormItem from '@/components/FormItem'
import AppInput from '@/components/Input'
import AppButton from '@/components/Button'

export default {
  components: {
    AppFormItem,
    AppInput,
    AppButton,
  },
  props: {
    loading: {
      type: Boolean,
      default: false,
    },
    title: {
      type: String,
      default: '',
    },
    label: {
      type: String,
      default: '',
    },
    width: {
      type: Number,
      default: 400,
    },
    labelWidth: {
      type: String,
      default: '120px',
    },
    buttonSize: {
      type: String,
      default: 'small',
    },
    confirmButtonText: {
      type: String,
      default: 'Confirm',
    },
    confirmButtonType: {
      type: String,
      default: 'primary',
    },
    cancelButtonText: {
      type: String,
      default: 'Cancel',
    },
    cancelButtonType: {
      type: String,
      default: 'default',
    },
    showDeleteButton: {
      type: Boolean,
      default: false,
    },
    deleteButtonText: {
      type: String,
      default: 'Delete',
    },
    deleteButtonType: {
      type: String,
      default: 'default',
    },
    onMouseLeave: {
      type: Function,
      default: null,
    },
    open: {
      type: Boolean,
      default: false,
    },
    trigger: {
      type: String,
      default: 'click',
    },
    closeOnMouseLeave: {
      type: Boolean,
      default: false,
    },
    placeholder: {
      type: String,
      default: null,
    },
    maxLength: {
      type: Number,
      default: null,
    },
    showWordLimit: {
      type: Boolean,
      default: false,
    },
    value: {
      type: String,
      default: null,
    },
    validations: {
      type: Object,
      default: () => ({}),
    },
    validationsMessages: {
      type: Object,
      default: () => ({}),
    },
  },
  data() {
    return {
      isVisible: false,
      input: null,
    }
  },
  watch: {
    open() {
      this.isVisible = this.open
      this.input = this.value
    },
  },
  validations() {
    return {
      input: {
        ...this.validations,
      },
    }
  },
  methods: {
    openPopover() {
      this.isVisible = true
    },
    closePopover() {
      if (this.trigger !== 'manual') {
        this.isVisible = false
        this.$emit('update:open', false)
      }
    },
    handleMouseLeave() {
      if (this.loading || this.$v.$dirty) {
        return
      }

      if (this.closeOnMouseLeave) {
        this.isVisible = false
        this.$emit('update:open', false)
      }

      if (this.trigger === 'manual' || this.onMouseLeave) {
        this.onMouseLeave()
        return
      }
    },
    reset() {
      this.input = null
      this.$v.$reset()
    },
    cancel() {
      this.closePopover()
      this.$emit('on-cancel')
    },
    onDelete() {
      this.closePopover()
      this.$emit('on-delete')
    },
    confirm() {
      this.$v.$touch()
      if (!this.$v.$invalid) {
        this.$emit('on-confirm', this.input)
      }
      if (!this.$v.$invalid && this.trigger !== 'manual') {
        this.closePopover()
        this.reset()
      }
    },
    getCustomFieldError(input) {
      return input && input.$error
        ? Object.keys(input.$params || {})
          .reduce((messages, key) => !input[key]
            ? messages +
            `${messages ? ' - ' : ''} ${this.validationsMessages[key]}`
            : messages,
          '',
          )
        : null
    },
  },
}
</script>

<style lang="scss" scoped>
  @import '@/styles/_settings/index.scss';

  ._app-input {
    &__content {
      margin: 0 auto 8px auto;
      word-break: normal;
    }

    &__title {
      color: $--color-text-primary;
      font-size: 14px;
      font-weight: 300;
      margin-bottom: 5px;
    }

    /deep/ .el-form-item {
      margin-bottom: 12px;
    }

    /deep/ .el-form-item__error {
      position: relative;
    }

    &__footer {
      display: flex;
      justify-content: space-between;
      transition: margin 0.3s ease;
    }
  }
</style>
