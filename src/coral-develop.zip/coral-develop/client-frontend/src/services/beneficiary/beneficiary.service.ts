import { serviceForCustomer } from '@/utils/request.js'
import { BeneficiaryDto } from '@/models/Beneficiary'

const BENEFICIARY_BASEPATH = '/api/v1/beneficiaries'

export const getBeneficiaries = async() => {
  try {
    const data: any = await serviceForCustomer.get(BENEFICIARY_BASEPATH)
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch beneficiaries', error)
    return [error, null]
  }
}

export const validateBeneficiary = async(payload: BeneficiaryDto) => {
  if (!payload) {
    throw new Error('validateBeneficiary: missing payload')
  }
  try {
    const data: any = await serviceForCustomer.post(
      `${BENEFICIARY_BASEPATH}/validate`,
      payload,
    )

    if (!data || !data.errors || !data.errors.length) {
      // Success
      return [null, true]
    }

    // Return error because API return 200 for errors
    return [data.errors, false]
  } catch (error) {
    // Return accountNumber error because API return 500 for this error
    return [[
      { fieldName: 'accountNumber', 'error': 'invalid' },
    ], false]
  }
}

export const validateBeneficiaryNickName = async(nickname: string) => {
  if (!nickname) {
    throw new Error('validateBeneficiaryNickName: missing nickName')
  }
  try {
    const data: any = await serviceForCustomer.get(`${BENEFICIARY_BASEPATH}/validate/nickname/${nickname}`)
    return [null, data]
  } catch (error) {
    return [error, null]
  }
}

export const createBeneficiary = async(payload: BeneficiaryDto) => {
  if (!payload) {
    throw new Error('createBeneficiary: missing payload')
  }

  try {
    const { id, ...apiPayload } = payload // Remove id from the apiPayload

    const data: any = await serviceForCustomer.post(BENEFICIARY_BASEPATH, apiPayload)
    return [null, data]
  } catch (error) {
    return [error, null]
  }
}

export const updateBeneficiary = async(
  {
    id,
    nickname,
  }: {
    id: string,
    nickname: string
  },
) => {
  if (!id || !nickname) {
    throw new Error('createBeneficiary: missing id or nickName')
  }
  try {
    const data: any = await serviceForCustomer.patch(
      `${BENEFICIARY_BASEPATH}/${id}`,
      nickname,
      { headers: { 'Content-Type': 'text/plain' }},
    )

    return [null, data]
  } catch (error) {
    return [error, null]
  }
}

export const deleteBeneficiary = async(id: string) => {
  if (!id) {
    throw new Error('deleteBeneficiary: missing id')
  }
  try {
    const data: any = await serviceForCustomer.delete(`${BENEFICIARY_BASEPATH}/${id}`)
    return [null, data]
  } catch (error) {
    return [error, null]
  }
}

/**
 * API to fetch Bank information using the Iban.
 * @param iban used to fetch bank information.
 */
export const getIbanInfo = async(iban: any) => {
  if (!iban) {
    throw new Error('getIbanInfo: missing iban')
  }
  try {
    const data: any = await serviceForCustomer({
      url: `api/v1/validate/iban`,
      method: 'POST',
      params: { param: iban },
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch iban info', error)
    return [error, null]
  }
}
