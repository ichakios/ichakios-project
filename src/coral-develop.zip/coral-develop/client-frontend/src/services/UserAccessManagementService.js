import { service, serviceForCustomer } from '@/utils/request'

const userUrl = '/api/v1/users'

class UserAccessManagementService {
  constructor({ resource }) {
    this.resource = resource
  }

  /**
   * Gets the list of customers the user belongs to
   * @returns {AxiosPromise}
   */
  getCustomers() {
    return service.get(`${this.resource}customers`)
  }

  /**
   * Returns the list of roles for the given customer.
   *
   * @returns {*}
   */
  getAllAvailableRoles() {
    return serviceForCustomer.get(`${this.resource}roles`)
  }

  /**
   * Returns the list of users for the given customer.
   *
   * @returns {*}
   */
  async getAllUsersWithRoles() {
    try {
      const data = await serviceForCustomer.get(`${this.resource}users`)
      return [null, data]
    } catch (error) {
      console.error('[UserAccessManagementService::getAllUsersWithRoles]: Error - cannot get all users with roles', error)
      return [error, null]
    }
  }

  async getAllUsersInfos() {
    try {
      const data = await serviceForCustomer.get(userUrl)
      return [null, data]
    } catch (error) {
      console.error('[UserAccessManagementService::getAllUsersInfos]: Error - cannot get all users infos', error)
      return [error, null]
    }
  }

  async createUser({
    userInfos,
  }) {
    try {
      await serviceForCustomer.post(userUrl, {
        ...userInfos,
        email: userInfos.email,
        firstName: userInfos.firstName,
        lastName: userInfos.lastName,
        login: userInfos.email,
        password: userInfos.password,
        phoneNumber: userInfos.mobileNumber,
      })
      return [null, userInfos]
    } catch (error) {
      console.error('[UserAccessManagementService::createUser]: Error - cannot create the user', error)
      if (error.response.status === 409) {
        return [[
          {
            fieldName: 'email',
            error: 'alreadyUsed',
          },
        ], null]
      }

      return [[], null]
    }
  }

  async updateUser() {
    return [null]
  }

  async deleteUser({
    userName,
  }) {
    try {
      await serviceForCustomer.delete(`${userUrl}/${userName}`)
      return [null]
    } catch (error) {
      console.error('[UserAccessManagementService::deleteUser]: Error - cannot delete the user', error)
      return [error, null]
    }
  }

  async getRoles() {
    try {
      const data = await serviceForCustomer.get(`${this.resource}roles`)
      return [null, data]
    } catch (error) {
      console.error('[UserAccessManagementService::getRoles]: Error - cannot get user roles', error)
      return [error, null]
    }
  }

  async getUserInfos() {
    try {
      const data = await serviceForCustomer.get(`${this.resource}users/current`)
      return [null, data]
    } catch (error) {
      console.error('[UserAccessManagementService::getUserInfos]: Error - cannot get user infos', error)
      return [error, null]
    }
  }

  async addRoleToUser({
    userName,
    roles,
  }) {
    try {
      const data = await serviceForCustomer.post(`${this.resource}roles/users/${userName}`, roles)
      return [null, data]
    } catch (error) {
      console.error('[UserAccessManagementService::addRoleToUser]: Error - cannot add roles to user', error)
      return [error, null]
    }
  }
}

export default new UserAccessManagementService({
  resource: 'api/uam/v1/',
})
