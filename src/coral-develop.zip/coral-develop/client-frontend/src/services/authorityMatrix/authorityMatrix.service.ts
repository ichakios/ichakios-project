import { serviceForCustomer } from '@/utils/request.js'

export const getUsers = async() => {
  try {
    const data: any = await serviceForCustomer({
      url: `/api/uam/v1/users`,
      method: 'get',
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch users', error)
    return [error, null]
  }
}

export const getRoles = async() => {
  try {
    const data: any = await serviceForCustomer({
      url: `/api/uam/v1/roles`,
      method: 'get',
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch roles', error)
    return [error, null]
  }
}

export const getRules = async() => {
  try {
    const data: any = await serviceForCustomer({
      url: `/api/v1/authority/rules`,
      method: 'get',
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch rules', error)
    return [error, null]
  }
}

export const addRule = async(
  paymentRule: any,
) => {
  try {
    const data: any = await serviceForCustomer.post(
      `/api/v1/authority/rules`,
      paymentRule,
    )
    return [null, data]
  } catch (error) {
    console.error('Cannot create rule', error)
    if (error.response.status === 500 && error.response.data && error.response.data.detail === 'The rule cannot be accepted because it conflicts with another rule') {
      return [[{ error: 'ruleRangeAlreadyUsed' }]]
    }
    return [[{ error: '500' }], null]
  }
}

export const editRule = async(
  ruleKey: string,
  paymentRule: any,
) => {
  try {
    const data: any = await serviceForCustomer.put(
      `/api/v1/authority/rules/${ruleKey}`,
      paymentRule,
    )
    return [null, data]
  } catch (error) {
    console.error('Cannot edit rule', error)
    if (error.response.status === 500 && error.response.data && error.response.data.detail === 'The rule cannot be accepted because it conflicts with another rule') {
      return [[{ error: 'ruleRangeAlreadyUsed' }]]
    }
    return [[{ error: '500' }], null]
  }
}

export const deleteRule = async(
  customer: string,
  ruleKey: string,
) => {
  try {
    const data: any = await serviceForCustomer({
      url: `/api/v1/authority/rules/${ruleKey}`,
      method: 'delete',
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot delete rule', error)
    return [error, null]
  }
}
