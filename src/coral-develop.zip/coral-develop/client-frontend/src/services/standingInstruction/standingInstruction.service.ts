import { serviceForCustomer } from '@/utils/request.js'

const STANDING_INSTRUCTION_BASEPATH = '/api/v1/payments/standing-instructions'

interface AcceptPendingStandingInstructionParams {
  reference: string
}

interface RejectPendingStandingInstructionParams extends AcceptPendingStandingInstructionParams {
  comments: string
}

/**
 * GET
 * Retrieve all the Standing Instruction
 * // TODO: Update when real API is available (Issue #262)
 */
export const getStandingInstructions = async() => {
  try {
    const data = await serviceForCustomer
      .get(`${STANDING_INSTRUCTION_BASEPATH}/summary`)
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch standing instructions', error)
    return [error, null]
  }
}

/**
 * POST
 * Validate a Standing Instruction
 * // TODO: Update when real API is available (Issue #262)
 * @params payload.from {object}
 * @params payload.toAccount.nickname {string}
 * @params payload.toAccount.name {string}
 * @params payload.toAccount.accountId {string}
 * @params payload.amount {number}
 * @params payload.currency {string}
 * @params payload.frequency {string}
 * @params payload.startDate {string} Format YYYY-MM-DD
 * @params payload.nickname {string}
 * @params payload.purpose {string}
 * @params payload.chargeBearer {string}
 * @params payload.repeatCount {number}
 * @params payload.repeatEndDate {string} Format YYYY-MM-DD
 */
export const validateStandingInstruction = async(payload: any) => {
  try {
    if (!payload) {
      throw new Error('validateStandingInstruction: missing payload')
    }

    const data = await serviceForCustomer
      .post(`${STANDING_INSTRUCTION_BASEPATH}/validate`, payload)
    return [null, data]
  } catch (error) {
    console.error('Fail to validate the standing instruction', error)
    return [error, null]
  }
}

/**
 * POST
 * Create a new Standing Instruction
 * // TODO: Update when real API is available (Issue #262)
 * @params payload.from {object}
 * @params payload.to.nickname {string}
 * @params payload.to.name {string}
 * @params payload.to.accountId {string}
 * @params payload.amount {number}
 * @params payload.currency {string}
 * @params payload.frequency {string}
 * @params payload.startDate {string} Format YYYY-MM-DD
 * @params payload.nickname {string}
 * @params payload.purpose {string}
 * @params payload.chargeBearer {string}
 * @params payload.repeatUntil {string}
 * @params payload.repeatCount {number}
 * @params payload.repeatEndDate {string} Format YYYY-MM-DD
 */
export const createStandingInstruction = async({ id, ...payload } : any) => {
  try {
    if (!payload) {
      throw new Error('createStandingInstruction: missing payload')
    }

    const standingInstruction: any = await serviceForCustomer
      .post(STANDING_INSTRUCTION_BASEPATH, { ...payload, actionType: 'CREATE' })
    return [null, standingInstruction]
  } catch (error) {
    console.error('Fail to create the standing instruction', error)
    return [error, null]
  }
}

/**
 * POST
 * Create a new Standing Instruction
 * // TODO: Update when real API is available (Issue #262)
 * @params payload.from {object}
 * @params payload.to.nickname {string}
 * @params payload.to.name {string}
 * @params payload.to.accountId {string}
 * @params payload.amount {number}
 * @params payload.currency {string}
 * @params payload.frequency {string}
 * @params payload.startDate {string} Format YYYY-MM-DD
 * @params payload.nickname {string}
 * @params payload.purpose {string}
 * @params payload.chargeBearer {string}
 * @params payload.repeatUntil {string}
 * @params payload.repeatCount {number}
 * @params payload.repeatEndDate {string} Format YYYY-MM-DD
 */
export const createWithReferenceStandingInstruction = async({ id, ...payload } : any) => {
  try {
    if (!payload) {
      throw new Error('createStandingInstruction: missing payload')
    }
    const standingInstruction: any = await serviceForCustomer
      .post(STANDING_INSTRUCTION_BASEPATH, { ...payload, actionType: 'CREATE', reference: id })
    return [null, standingInstruction]
  } catch (error) {
    console.error('Fail to create the standing instruction', error)
    return [error, null]
  }
}

/**
 * POST
 * Create a new Standing Instruction
 * // TODO: Update when real API is available (Issue #262)
 * @params payload.from {object}
 * @params payload.to.nickname {string}
 * @params payload.to.name {string}
 * @params payload.to.accountId {string}
 * @params payload.amount {number}
 * @params payload.currency {string}
 * @params payload.frequency {string}
 * @params payload.startDate {string} Format YYYY-MM-DD
 * @params payload.nickname {string}
 * @params payload.purpose {string}
 * @params payload.chargeBearer {string}
 * @params payload.repeatUntil {string}
 * @params payload.repeatCount {number}
 * @params payload.repeatEndDate {string} Format YYYY-MM-DD
 */
export const editStandingInstruction = async({ id, ...payload } : any) => {
  try {
    if (!payload) {
      throw new Error('modify error: missing payload')
    }
    const standingInstruction: any = await serviceForCustomer
      .post(`${STANDING_INSTRUCTION_BASEPATH}/modify`, { hostReference: id, ...payload, actionType: 'MODIFY' })
    return [null, standingInstruction]
  } catch (error) {
    console.error('Fail to editing the standing instruction', error)
    return [error, null]
  }
}
/**
 * POST
 * Create a new Standing Instruction
 * // TODO: Update when real API is available (Issue #262)
 * @params payload.from {object}
 * @params payload.to.nickname {string}
 * @params payload.to.name {string}
 * @params payload.to.accountId {string}
 * @params payload.amount {number}
 * @params payload.currency {string}
 * @params payload.frequency {string}
 * @params payload.startDate {string} Format YYYY-MM-DD
 * @params payload.nickname {string}
 * @params payload.purpose {string}
 * @params payload.chargeBearer {string}
 * @params payload.repeatUntil {string}
 * @params payload.repeatCount {number}
 * @params payload.repeatEndDate {string} Format YYYY-MM-DD
 */
export const cancelCoreStandingInstruction = async(id: any, reason: any) => {
  try {
    if (!id) {
      throw new Error('cancelStandingInstruction: missing payload')
    }

    const standingInstruction: any = await serviceForCustomer
      .post(`${STANDING_INSTRUCTION_BASEPATH}/cancel`, { actionType: 'CANCEL', hostReference: id, cancelReason: reason })
    return [null, standingInstruction]
  } catch (error) {
    console.error('Fail to cancel the standing instruction', error)
    return [error, null]
  }
}

/**
 * Patch
 * Cancel a Standing Instruction
 * @cancelRequest id {string} comments {string}
 */
export const cancelStandingInstruction = async(cancelRequest: any) => {
  try {
    if (!cancelRequest.reference) {
      throw new Error('cancelStandingInstruction: missing id')
    }
    const standingInstruction: any = await serviceForCustomer
      .patch(`${STANDING_INSTRUCTION_BASEPATH}/${cancelRequest.reference}/cancel`, { comments: cancelRequest.comments })

    return [null, standingInstruction]
  } catch (error) {
    console.error('Fail to cancel the standing instruction', error)
    return [error, null]
  }
}

/**
 * GET
 * Retrieve all  Standing Instruction Requests in workflow for the customer
 */
export const getStandingInstructionsRequests = async() => {
  try {
    const data = await serviceForCustomer
      .get(`${STANDING_INSTRUCTION_BASEPATH}`)
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch standing instructions', error)
    return [error, null]
  }
}

/**
 * GET
 * Retrieve Standing Instruction Request by Specific Reference in workflow for the customer
 */
export const getStandingInstructionsRequestsByReference = async(reference: any) => {
  try {
    if (!reference) {
      throw new Error('get standing instruction by reference: missing reference')
    }
    const data = await serviceForCustomer
      .get(`${STANDING_INSTRUCTION_BASEPATH}/${reference}`)
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch standing instructions by reference', error)
    return [error, null]
  }
}

/**
 * Get all pending standing instructions
 */
export const getPendingStandingInstructions = async() => {
  try {
    const pendingStandingInstruction: any = await serviceForCustomer
      .get(`${STANDING_INSTRUCTION_BASEPATH}/pending`)
    return [null, pendingStandingInstruction.content]
  } catch (error) {
    console.error('An error occurred while listing the pending standing instructions', error)
    return [error, null]
  }
}

/**
 * Approve a pending standing instruction
 */
export const approvePendingStandingInstruction = async(
  { reference }: AcceptPendingStandingInstructionParams,
) => {
  try {
    await serviceForCustomer.patch(`${STANDING_INSTRUCTION_BASEPATH}/${reference}/approve`)
    return [null, null]
  } catch (error) {
    console.error('An error occurred while approving the pending standing instruction', error)
    return [error, null]
  }
}

/**
 * Reject a pending standing instruction
 */
export const rejectPendingStandingInstruction = async(
  {
    reference,
    comments,
  }: RejectPendingStandingInstructionParams,
) => {
  try {
    await serviceForCustomer.patch(
      `${STANDING_INSTRUCTION_BASEPATH}/${reference}/reject`,
      {
        comments,
      })
    return [null, null]
  } catch (error) {
    console.error('An error occurred while rejecting the pending standing instruction', error)
    return [error, null]
  }
}
