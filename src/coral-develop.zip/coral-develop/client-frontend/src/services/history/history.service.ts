import { serviceForCustomer } from '@/utils/request.js'

const historyEndpoint = '/api/v1/approval-history'

/**
 * GET
 * Fetches Count of all pending tasks for the user to be displayed at badge level on the side menu
 */
export const getPendingTasksCount = async() => {
  try {
    const data: any = await serviceForCustomer.get(`${historyEndpoint}/tasks-count`)
    return [null, data]
  } catch (error) {
    console.error('Cannot Fetch Tasks Count', error)
    return [error, null]
  }
}

/**
 * GET
 * Fetches history for a process instance
 * @param processId
 */
export const getHistoryById = async(processId: string) => {
  try {
    const data: any = await serviceForCustomer.get(`${historyEndpoint}/${processId}`)
    return [null, data]
  } catch (error) {
    console.error('Cannot Fetch History', error)
    return [error, null]
  }
}
