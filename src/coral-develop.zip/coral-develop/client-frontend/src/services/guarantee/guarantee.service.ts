import { serviceForCustomer } from '@/utils/request.js'

const GUARANTEE_BASEPATH = '/api/v1/guarantees'

/**
 * GET
 * Retrieve all the Guarantees Instruction
 * // TODO: Update when real API is available (Issue #407)
 */
export const getGuaranteesOverview = async() => {
  try {
    const data = await serviceForCustomer
      .get(`${GUARANTEE_BASEPATH}/overview`)
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch guarantees overview', error)
    return [error, null]
  }
}

/**
 * GET
 * Retrieve all the Guarantees Instruction by type
 * // TODO: Update when real API is available (Issue #407)
 */
export const getGuaranteesListingByType = async(type: string) => {
  try {
    const data = await serviceForCustomer
      .get(`${GUARANTEE_BASEPATH}/${type}`)
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch guarantees by type listing', error)
    return [error, null]
  }
}

/**
 * POST
 * Validate a guarantee
 * // TODO: Update when real API is available (Issue #407)
 */
export const validateGuarantee = async(payload: any) => {
  try {
    if (!payload) {
      throw new Error('validateGuarantee: missing payload')
    }

    const data = await serviceForCustomer
      .post(`${GUARANTEE_BASEPATH}/validate`, payload)
    return [null, data]
  } catch (error) {
    console.error('Failed to validate the guarantee', error)
    return [error, null]
  }
}

/**
 * POST
 * Create a guarantee
 * // TODO: Update when real API is available (Issue #407)
 */
export const createGuarantee = async(payload: any) => {
  try {
    if (!payload) {
      throw new Error('createGuarantee: missing payload')
    }

    const data = await serviceForCustomer
      .post(`${GUARANTEE_BASEPATH}`, payload)
    return [null, data]
  } catch (error) {
    console.error('Failed to validate the guarantee', error)
    return [error, null]
  }
}

/**
 * POST
 * Update a guarantee
 * // TODO: Update when real API is available (Issue #407)
 */
export const updateGuarantee = async({ id, ...payload }: any) => {
  try {
    if (!payload) {
      throw new Error('updateGuarantee: missing payload')
    }

    const data = await serviceForCustomer
      .post(`${GUARANTEE_BASEPATH}/${id}`, payload)
    return [null, data]
  } catch (error) {
    console.error('Failed to udpate the guarantee', error)
    return [error, null]
  }
}
