import { v4 as uuid } from 'uuid'
import { serviceForCustomer } from '@/utils/request'

const sweepsEndpoint = '/api/v1/sweeps'

interface SweepAccount {
  name: string,
  nickname: string,
  currencyId: string,
  accountId: string,
  availableBalance: number,
  drawableBalance: number,
  status: string
}

interface Sweep {
  type: string,
  targetAccount: SweepAccount,
  coverAccounts: SweepAccount[],
  amount: string,
  id?: string,
}

interface PendingSweep extends Sweep {
  reference?: string,
  createdOn?: string,
  createdBy?: string,
  status: string,
}

interface SweepRequest extends Sweep {
  reference: string,
  createdBy: string,
  createdOn: string,
  featureCode: string,
  operationType: string,
  status: string,
}

interface SweepCancelRequestParams {
  comments: string,
  reference: string
}

interface ApiWrapper<T> {
  content: T[]
}

/**
 * getSweeps returns all sweeps of all types
 */
export const getSweeps = async() => {
  try {
    const results: Sweep[] = await serviceForCustomer.get(sweepsEndpoint) as any
    const sweeps = results.map((sweep) => ({
      ...sweep,
      id: uuid(), // Needed because the api do not return any id for a sweep
    }))
    return [null, sweeps]
  } catch (error) {
    console.error('Cannot get all sweeps', error)
    return [error, null]
  }
}

/**
 * Check that the sweep to be created is correct
 * @param {Object} payload Sweep object that needs to be checked
 */
export const checkSweepCreation = async(payload: Sweep) => {
  try {
    await serviceForCustomer.post(
      `${sweepsEndpoint}/validate/creation`,
      payload,
    )

    return [null]
  } catch (error) {
    console.error('Sweep creation check failed', error)
    let errorArray = [error]

    if (error.response && error.response.data.fieldErrors) {
      errorArray = error.response.data.fieldErrors.map((errorDetails: any) => ({
        fieldName: errorDetails.field,
        error: errorDetails.message,
      }))
    }
    return [errorArray, null]
  }
}

/**
 * Check that the sweep to be edited is correct
 * @param {Object} payload Sweep object that needs to be checked
 */
export const checkSweepEdition = async(payload: Sweep) => {
  try {
    await serviceForCustomer.post(
      `${sweepsEndpoint}/validate/edition`,
      payload,
    )

    return [null]
  } catch (error) {
    console.error('Sweep edition check failed', error)
    let errorArray = [error]

    if (error.response && error.response.data.fieldErrors) {
      errorArray = error.response.data.fieldErrors.map((errorDetails: any) => ({
        fieldName: errorDetails.field,
        error: errorDetails.message,
      }))
    }
    return [errorArray, null]
  }
}

/**
 * Create a new sweep
 * @param {Object} newSweepValues
 */
export const createSweep = async(payload: Sweep) => {
  try {
    const result = await serviceForCustomer.post(sweepsEndpoint, payload)
    return [null, result]
  } catch (error) {
    console.error('Cannot create the new sweep', error)
    return [error, null]
  }
}

/**
 * Edit a sweep
 * @param {Object} newSweepValues
 */
export const editSweep = async(payload: Sweep) => {
  try {
    const result = await serviceForCustomer.put(sweepsEndpoint, payload)
    return [null, result]
  } catch (error) {
    console.error('Cannot edit the sweep', error)
    return [error, null]
  }
}

/**
 * Cancel a sweep
 * @param {Object} newSweepValues
 */
export const cancelSweep = async(payload: Sweep) => {
  try {
    const result = await serviceForCustomer(sweepsEndpoint, {
      method: 'delete',
      data: payload,
    })
    return [null, result]
  } catch (error) {
    console.error('Cannot cancel the sweep', error)
    return [error, null]
  }
}

/**
 * Get pending validation sweeps
 */
export const getPendingSweeps = async() => {
  try {
    const pendingSweeps = await serviceForCustomer.get(`${sweepsEndpoint}/requests/pending`) as any
    return [null, pendingSweeps.content]
  } catch (error) {
    console.error('Cannot get pending sweeps', error)
    return [error, null]
  }
}

/**
 * Get all sweep requests for the current customer
 */
export const getSweepRequestsForCustomer = async() => {
  try {
    const sweepRequests: ApiWrapper<SweepRequest> = await serviceForCustomer.get(`${sweepsEndpoint}/requests`) as any
    return [null, sweepRequests.content]
  } catch (error) {
    console.error('Cannot get sweep requests for the current customer', error)
    return [error, null]
  }
}

/**
 * Approve a pending sweep
 * @param reference Reference of the pending sweep to approve
 */
export const approveSweep = async(reference: number) => {
  try {
    await serviceForCustomer.patch(`${sweepsEndpoint}/requests/${reference}/approve`)
    return [null]
  } catch (error) {
    console.error('Cannot approve sweep', error)
    return [error, null]
  }
}

/**
 * Reject a pending sweep
 * @param sweepId Id of the sweep to reject
 */
export const rejectSweep = async({
  reference,
  comments,
} : {
  reference: string,
  comments: string,
}) => {
  try {
    await serviceForCustomer.patch(
      `${sweepsEndpoint}/requests/${reference}/reject`,
      { comments },
    )
    return [null]
  } catch (error) {
    console.error('Cannot reject sweep', error)
    return [error, null]
  }
}

/**
 * Cancel a pending approval sweep request
 * @param {Object} params reference and comment values
 * @param {String} params.reference reference of the sweep request to cancel
 * @param {String} params.comments reason of the cancelation
 */
export const cancelSweepRequest = async(params: SweepCancelRequestParams) => {
  try {
    if (!params || !params.comments || !params.reference) {
      throw new Error('cancelSweepRequest: Missing required params')
    }

    await serviceForCustomer.patch(`${sweepsEndpoint}/requests/${params.reference}/cancel`, {
      comments: params.comments,
    })

    return [null, null]
  } catch (error) {
    console.error('Cannot cancel a sweep request', error)
    return [error, null]
  }
}
