import { serviceForCustomer } from '@/utils/request.js'

const drawdownEndpoint = '/api/v1/drawdown-requests'
/**
 * GET
 * Fetches all Pending Drawdown Requests for Term Loans and Credit Program for Tasks Screen
 * @param startDate Start Date parameter for Date Range
 * @param endDate End Date parameter for Date Range
 */
export const getPendingDrawdowns = async(startDate: any, endDate: any) => {
  try {
    const data: any = await serviceForCustomer({
      url: `${drawdownEndpoint}/pending`,
      method: 'get',
      params: { startDate, endDate },
    })
    return [null, data.content]
  } catch (error) {
    console.error('Cannot fetch pending drawdowns', error)
    return [error, null]
  }
}

/**
 * Request to approve a pending drawdown request
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending deposit drawdown
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const approveDrawdownRequest = async({
  reference,
} : {
  reference: string,
}) => {
  try {
    const data: any = await serviceForCustomer.patch(`${drawdownEndpoint}/${reference}/approve`)
    return [null, data.content]
  } catch (error) {
    console.error('Cannot approve drawdown request', error)
    return [error, null]
  }
}

/**
 * Request to reject a pending drawdown request
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending drawdown
 * @param {string} config.comments comments - Reject reason
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const rejectDrawdownRequest = async({
  reference,
  comments,
} : {
  reference: string,
  comments: string,
}) => {
  try {
    const data: any = await serviceForCustomer.patch(
      `${drawdownEndpoint}/${reference}/reject`,
      { comments },
    )
    return [null, data.content]
  } catch (error) {
    console.error('Cannot reject drawdown request', error)
    return [error, null]
  }
}
/**
 * GET
 * Fetches all Drawdown Requests for Term Loans and Credit Program for Transfers Screen
 * @param startDate Start Date parameter for Date Range
 * @param endDate End Date parameter for Date Range
 */
export const getAllDrawdowns = async(startDate: any, endDate: any) => {
  try {
    const data: any = await serviceForCustomer({
      url: `${drawdownEndpoint}`,
      method: 'get',
      params: { startDate, endDate },
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch pending drawdowns', error)
    return [error, null]
  }
}
