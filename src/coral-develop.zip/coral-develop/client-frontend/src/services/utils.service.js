export const sortOnProp = (prop, order) => (a, b) => {
  const predicate = order === 'ascending' ? 1 : -1

  if (typeof a[prop] === 'number' && typeof b[prop] === 'number') {
    return (a[prop] - b[prop]) * predicate
  }

  const aValue = JSON.stringify(a[prop])
  const bValue = JSON.stringify(b[prop])

  return (aValue || '').localeCompare(bValue) * predicate
}

