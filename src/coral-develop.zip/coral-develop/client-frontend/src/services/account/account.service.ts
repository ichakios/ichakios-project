import { service, serviceForCustomer } from '@/utils/request.js'

import { getApiDateFormat } from '@/utils/formatDates'

const accountsEndpoint = '/api/v1/accounts'
const statementsEndpoint = `${accountsEndpoint}/statements`
const transactionsEndpoint = `${accountsEndpoint}/transactions`

/**
 * Get all accounts for a given id
 * GET
 * @param id
 * TODO: remove the default account id when account module will be integrated into User Management.
 */
export const getAccounts = async(id: string = '000000671') => {
  if (!id) {
    throw new Error('missing id param')
  }
  try {
    const data: any = await serviceForCustomer({
      url: `${accountsEndpoint}?id=${id}`,
      method: 'get',
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch accounts', error)
    return [error, null]
  }
}

/**
 * Get all transactions from date to date for a given account id
 * @param accountID The id of the account we need to retrieve transactions
 * @param startDate
 * @param endDate
 */
export const getTransactions = async(
  accountID: string,
  startDate: Date,
  endDate: Date,
) => {
  const formattedStartDate = getApiDateFormat(startDate)
  const formattedEndDate = getApiDateFormat(endDate)
  try {
    const data: any = await serviceForCustomer({
      url: `${transactionsEndpoint}/date-range`,
      method: 'get',
      params: {
        accountID,
        fromDate: formattedStartDate,
        toDate: formattedEndDate,
      },
    })
    return [null, data.statementRecords]
  } catch (error) {
    console.error('Cannot fetch transactions', error)
    return [error, null]
  }
}

/**
 * Get range of last transactions from a given account
 * GET
 * @param accountId The id of the account we need to retrieve transactions
 * @param noOfLastTrx The number of transactions we want to get
 */
export const getLastTransactions = async(
  accountID: string,
  noOfLastTrx = 5000,
) => {
  try {
    const data: any = await serviceForCustomer({
      url: transactionsEndpoint,
      method: 'get',
      params: {
        accountID,
        noOfLastTrx,
      },
    })
    return [null, data.statementRecords]
  } catch (error) {
    console.error('Cannot fetch last transactions', error)
    return [error, null]
  }
}

/**
 * Get debit advice from a given transaction and date
 * POST
 * @param workingDate The date we need to cover
 * @param trxRefNo The reference of the transaction
 */
export const getDebitAdvice = async(
  workingDate: string,
  trxRefNo: string,
) => {
  const formattedWorkingDate = getApiDateFormat(workingDate)

  try {
    const data: any = await serviceForCustomer({
      url: `${statementsEndpoint}/debit-advice`,
      method: 'post',
      params: {
        workingDate: formattedWorkingDate,
        trxRefNo,
      },
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot get debit advice', error)
    return [error, null]
  }
}

/**
 * Get credit advice from a given transaction and date
 * POST
 * @param workingDate The date we need to cover
 * @param trxRefNo The reference of the transaction
 */
export const getCreditAdvice = async(
  workingDate: string,
  trxRefNo: string,
) => {
  const formattedWorkingDate = getApiDateFormat(workingDate)

  try {
    const data: any = await serviceForCustomer({
      url: `${statementsEndpoint}/credit-advice`,
      method: 'post',
      params: {
        workingDate: formattedWorkingDate,
        trxRefNo,
      },
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot get credit advice', error)
    return [error, null]
  }
}

/**
 * Generate pdf statement from a given account and month
 * POST
 * @param accountID The id of the account
 * @param fromDate The beginning date until now
 */
export const generateStatement = async(
  accountID: string,
  fromDate: string,
) => {
  const formattedFromDate = getApiDateFormat(fromDate)

  try {
    const data: any = await service({
      url: `${statementsEndpoint}/monthly`,
      method: 'post',
      params: {
        accountID,
        fromDate: formattedFromDate,
      },
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot generate statement', error)
    return [error, null]
  }
}

/**
 * Generate pdf statement from a given account and date range
 * POST
 * @param accountID The id of the account
 * @param fromDate The beginning date
 * @param toDate The ending date
 */
export const getStatementsPdf = async(
  accountID: string,
  fromDate: string,
  toDate: string,
) => {
  try {
    const data: any = await serviceForCustomer({
      url: `${statementsEndpoint}/date-range`,
      method: 'post',
      params: {
        accountID,
        fromDate,
        toDate,
      },
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot generate statement', error)
    return [error, null]
  }
}

/**
 * Get balance inquiry from a given account
 * GET
 * @param accountId The id of the account
 */
export const getBalanceInquiry = async(accountId: any) => {
  if (!accountId) {
    throw new Error('missing account id param')
  }
  try {
    const data: any = await serviceForCustomer({
      url: `${accountsEndpoint}/balance?accountId=${accountId}`,
      method: 'get',
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch balance inquiry', error)
    return [error, null]
  }
}

/**
 * Update account
 * PUT
 * @param payload The updated values of the payload based on AccountSummaryDto
 */
export const editAccount = async(payload: any) => {
  if (!payload) {
    throw new Error('missing payload param')
  }
  try {
    const data: any = await serviceForCustomer.put(accountsEndpoint, { ...payload })
    return [null, data]
  } catch (error) {
    console.error('Cannot edit account', error)
    return [error, null]
  }
}

/**
 * Delete nickname from a given account
 * DELETE
 * @param id The id of the account
 */
export const deleteAccountNickname = async(id: any) => {
  if (!id) {
    throw new Error('missing id param')
  }
  try {
    const data: any = await serviceForCustomer({
      url: `${accountsEndpoint}/${id}/nickname`,
      method: 'delete',
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot delete account nickname', error)
    return [error, null]
  }
}
