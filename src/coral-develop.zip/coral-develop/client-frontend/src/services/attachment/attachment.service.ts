import { serviceForCustomer } from '@/utils/request.js'
import store from '@/store'

const ATTACHMENT_BASEPATH = '/api/v1/attachments'

/**
 * POST
 * Upload an attachment
 */
export const uploadAttachment = async({
  file,
  name,
}: any) => {
  try {
    if (!file) {
      throw new Error('uploadAttachment: missing file')
    }

    const formData = new FormData()
    formData.append('file', file)

    const data = await serviceForCustomer
      .post(`${ATTACHMENT_BASEPATH}${name ? `?name=${name}` : ''}`, formData)
    return [null, data]
  } catch (error) {
    console.error('Fail to upload the attachment', error)
    return [error, null]
  }
}

export const getAttachmentUrl = (id: string) => `${process.env.VUE_APP_CORAL_BASE_API}/api/v1/attachments/${id}?customer=${store.getters.currentCustomer && store.getters.currentCustomer.key}`
