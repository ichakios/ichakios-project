import { serviceForCustomer } from '@/utils/request.js'
import { paymentPurposes } from './paymentPurposes.data'

const PAYMENT_BASEPATH = '/api/v1/payments'

/**
 * Returns all payments
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const getPayments = async() => {
  try {
    const data: any = await serviceForCustomer.get('/api/v1/payments')
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch payments', error)
    return [error, null]
  }
}

/**
 * Create a payment
 * @param {Object} payload Payment data
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const postPayment = async(payload: any) => {
  try {
    if (!payload) {
      throw new Error('postPayment: missing payload')
    }

    const data: any = await serviceForCustomer.post(
      PAYMENT_BASEPATH,
      payload,
    )
    return [null, data]
  } catch (error) {
    console.error('Cannot post new payment', error)
    return [error, null]
  }
}

/**
 * Validate a payment
 * @param {Object} payload Payment data
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const validatePayment = async(payload: any) => {
  try {
    if (!payload) {
      throw new Error('validatePayment: missing payload')
    }

    const data: any = await serviceForCustomer.post(
      `${PAYMENT_BASEPATH}/validate`,
      payload,
    )
    return [null, data]
  } catch (error) {
    console.error('Cannot validate payment', error)
    return [error, null]
  }
}

/**
 * Edit an existing payment
 * @param {Object} payload Payment data
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const editPayment = async(payload: any) => {
  if (!payload) {
    throw new Error('editPayment: missing payload')
  }

  // TODO: Update when edit request will be available by passing payload directly
  const { id, ...newPayload } = payload

  try {
    const data: any = await serviceForCustomer.post(
      PAYMENT_BASEPATH,
      newPayload,
    )
    return [null, data]
  } catch (error) {
    console.error('Cannot edit payment', error)
    return [error, null]
  }
}

/**
 * Cancel an existing payment
 * @param id Id of the payment to cancel
 * @param comments Cancel reason
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const cancelPayment = async(id: string, comments: string) => {
  try {
    if (!id) {
      throw new Error('cancelPayment: missing id')
    }

    const data: any = await serviceForCustomer.patch(
      `${PAYMENT_BASEPATH}/${id}/cancel`,
      {
        comments,
      },
    )
    return [null, data]
  } catch (error) {
    console.error('Cannot cancel payment', error)
    return [error, null]
  }
}

/**
 * Recall a payment
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
// TODO: Implement true API method
export const recallPayment = async() => {
  await new Promise((resolve) => setTimeout(resolve, 2000))
  return [null]
}

/**
 * Returns the payments purposes
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const getPaymentPurposes = async() => {
  return [null, paymentPurposes]
}

/**
 * Returns the pending payments
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const getPendingPayments = async() => {
  try {
    const data: any = await serviceForCustomer.get(`${PAYMENT_BASEPATH}/pending`)
    return [null, data.content.map((payment: any) => ({
      ...payment,
      id: payment.reference,
    }))]
  } catch (error) {
    console.error('Cannot get pending payments', error)
    return [error, null]
  }
}

/**
 * Accept a pending payment
 * @param {Number} paymentId Id of the payment that needs to be accepted
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const acceptPendingPayment = async(paymentId: number) => {
  try {
    const data: any = await serviceForCustomer.patch(`${PAYMENT_BASEPATH}/${paymentId}/approve`)
    return [null, data.content]
  } catch (error) {
    console.error('Cannot accept payment', error)
    return [error, null]
  }
}

/**
 * Reject a pending payment
 * @param {Object} config
 * @param {Number} config.paymentId Id of the payment to reject
 * @param {String} config.comments Reject reason
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const rejectPendingPayment = async({
  paymentId,
  comments,
}: { paymentId: number, comments: string }) => {
  try {
    const data: any = await serviceForCustomer.patch(
      `${PAYMENT_BASEPATH}/${paymentId}/reject`,
      { comments },
    )
    return [null, data.content]
  } catch (error) {
    console.error('Cannot reject payment', error)
    return [error, null]
  }
}
