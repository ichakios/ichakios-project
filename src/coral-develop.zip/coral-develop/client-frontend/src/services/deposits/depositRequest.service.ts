import { serviceForCustomer } from '@/utils/request'
import { featureCodeList } from '@/constants/deposits'

const depositRequestsURL = '/api/v1/deposit-requests'
const depositWithdrawalURL = '/api/v1/deposit-withdrawals'

/**
* Get Deposit Requests
* GET
*/
export const getDepositRequests = async() => {
  try {
    const data: any = await serviceForCustomer.get(depositRequestsURL)
    return [null, data.content]
  } catch (error) {
    console.error('Cannot fetch deposits', error)
    return [error, null]
  }
}

/**
* Get Deposit Withdrawal
* GET
*/
export const getPendingDepositsWithdrawals = async() => {
  try {
    const data: any = await serviceForCustomer({
      url: `${depositWithdrawalURL}/pending`,
      method: 'get',
    })
    return [null, data.content]
  } catch (error) {
    console.error('Cannot fetch pending deposits withdrawals details', error)
    return [error, null]
  }
}

/**
 * Request to cancel a pending deposit request
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending deposit
 * @param {string} config.comments comments - Cancel reason
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const cancelDepositRequest = async({
  reference,
  comments,
} : {
  reference: string,
  comments: string,
}) => {
  try {
    if (!reference || !comments) {
      throw new Error('Missing required reference and comments params')
    }

    const data: any = await serviceForCustomer.patch(
      `${depositRequestsURL}/${reference}/cancel`,
      { comments },
    )
    return [null, data.content]
  } catch (error) {
    console.error('Cannot cancel deposit request', error)
    return [error, null]
  }
}

/**
 * Request to cancel a pending withdrawal deposit
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending withdrawal deposit
 * @param {string} config.comments comments - Cancel reason
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const cancelDepositWithdrawal = async({
  reference,
  comments,
} : {
  reference: string,
  comments: string,
}) => {
  try {
    if (!reference || !comments) {
      throw new Error('Missing required reference and comments params')
    }

    const data: any = await serviceForCustomer.patch(
      `${depositWithdrawalURL}/${reference}/cancel`,
      { comments },
    )
    return [null, data.content]
  } catch (error) {
    console.error('Cannot cancel deposit withdrawal', error)
    return [error, null]
  }
}

/**
 * Utility function that calls the right cancel function
 * based on the type of the deposits.
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending deposit we want to cancel
 * @param {string} config.type type - Type of the pending deposit we want to cancel (INVESTMENT_DEPOSIT_REQUEST or INVESTMENT_DEPOSIT_WITHDRAWAL)
 * @param {string} config.comments comments - Cancel reason
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const cancelDeposit = ({
  reference,
  type,
  comments,
} : {
  reference: string,
  type: string,
  comments: string,
}) => {
  if (type === featureCodeList.INVESTMENT_DEPOSIT_REQUEST) {
    return cancelDepositRequest({ reference, comments })
  }

  if (type === featureCodeList.INVESTMENT_DEPOSIT_WITHDRAWAL) {
    return cancelDepositWithdrawal({ reference, comments })
  }

  return [new Error('Unsupported deposit type')]
}

/**
* Get Deposit Withdrawal
* GET
*/
export const getDepositsWithdrawals = async() => {
  try {
    const data: any = await serviceForCustomer({
      url: `${depositWithdrawalURL}`,
      method: 'get',
    })
    return [null, data.content]
  } catch (error) {
    console.error('Cannot fetch deposits withdrawals details', error)
    return [error, null]
  }
}

/**
* Get ALL Deposit Request
* GET
*/
export const getAllDeposits = async() => {
  try {
    const results = await Promise.all([
      getDepositRequests(),
      getDepositsWithdrawals(),
    ])
    return [null, results.flatMap(r => r[1])]
  } catch (errors) {
    console.error('Cannot fetch all request and withdrawal deposits', errors)
    return [errors.map((r: any) => r[0]), null]
  }
}

