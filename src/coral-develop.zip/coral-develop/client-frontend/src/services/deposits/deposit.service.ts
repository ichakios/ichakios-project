import { serviceForCustomer } from '@/utils/request'
import { featureCodeList } from '@/constants/deposits'

const depositUrl = '/api/v1/deposits'
const depositRequestsURL = '/api/v1/deposit-requests'
const depositWithdrawalURL = '/api/v1/deposit-withdrawals'
/**
* ALL Deposit Accounts
* GET
*/
export const getDepositAccounts = async() => {
  try {
    const data: any = await serviceForCustomer.get(depositUrl)
    return [null, data]
  } catch (error) {
    console.error('Cannot fetch deposits', error)
    return [error, null]
  }
}

/**
 * Create Deposit
 * POST
 * @param depositDTO
 */
export const createDeposit = async(depositDTO: any) => {
  try {
    const data: any = await serviceForCustomer.post(depositRequestsURL, depositDTO)
    return [null, data]
  } catch (error) {
    console.error('Cannot create deposit', error)
    return [error, null]
  }
}

/**
 * Validate New Deposit
 * POST
 * @param depositDTO
 */
export const validateNewDeposit = async(depositDTO: any) => {
  try {
    const data: any = await serviceForCustomer.post(depositRequestsURL + '/validate', depositDTO)
    return [null, data]
  } catch (error) {
    console.error('Cannot validate deposit', error)
    return [error, null]
  }
}
/**
     * Validate Withdraw
     * POST
     * @param withdrawDTO
     */
export const validateWithdraw = async(withdrawDTO: any) => {
  try {
    const data: any = await serviceForCustomer.post(depositWithdrawalURL + '/validate', withdrawDTO)
    return [null, data]
  } catch (error) {
    console.error('Cannot validate withdraw', error)
    return [error, null]
  }
}
/**
 * Generate Deposit Advice
 * POST
 * @param depositAccount
 * @param receiptId
  */
export const generateAdvice = async(depositAccount: string, receiptId: string) => {
  try {
    const data: any = await serviceForCustomer({
      url: `/api/v1/deposits/${depositAccount}/${receiptId}/advice`,
      method: 'GET',
      responseType: 'arraybuffer',
    })
    return [null, data]
  } catch (error) {
    console.error('Cannot Generate Advice', error)
    return [error, null]
  }
}
/**
 * Get Penalty Inquiry
 * POST
 * @param penaltyDTO
 */
export const getPenaltyInquiry = async(penaltyDTO: any) => {
  try {
    const data: any = await serviceForCustomer.post(depositWithdrawalURL + '/penalty-inquiry', penaltyDTO)
    return [null, data]
  } catch (error) {
    console.error('Cannot get penalty info', error)
    return [error, null]
  }
}

/**
  * Get Rate Inquiry
  * POST
  * @param inquiryDTO
  */
export const getRateInquiry = async(inquiryDTO: any) => {
  try {
    const data: any = await serviceForCustomer.post(depositRequestsURL + '/rate-inquiry', inquiryDTO)
    return [null, data]
  } catch (error) {
    console.error('Cannot get inquiry info', error)
    return [error, null]
  }
}
/**
     * Create Deposit Withdrawal
     * POST
     * @param depositDTO
     */
export const createDepositWithdrawal = async(depositDTO: any) => {
  try {
    const data: any = await serviceForCustomer.post(depositWithdrawalURL, depositDTO)
    return [null, data]
  } catch (error) {
    console.error('Cannot create deposit withdrawal', error)
    return [error, null]
  }
}
/**
 * Get Product Inquiry for Dashboard
 * GET
 */
export const getProductRates = async() => {
  try {
    const data: any = await serviceForCustomer.get(depositRequestsURL + '/rate-inquiry')
    return [null, data]
  } catch (error) {
    console.error('Cannot get Product Rates', error)
    return [error, null]
  }
}
/**
     * TO Get the Deal Information for special rates
     * POST
     * @param referenceDTO
     */
export const getDealReferenceInfo = async(referenceDTO: any) => {
  try {
    const data: any = await serviceForCustomer.post(depositRequestsURL + '/deal-inquiry', referenceDTO)
    return [null, data]
  } catch (error) {
    console.error('Cannot get reference info', error)
    return [error, null]
  }
}

/**
 * Returns all pending deposit requests from the api
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const getPendingDeposits = async() => {
  try {
    const data: any = await serviceForCustomer({
      url: `${depositRequestsURL}/pending`,
      method: 'get',
    })
    return [null, data.content]
  } catch (error) {
    console.error('Cannot fetch pending deposits details', error)
    return [error, null]
  }
}

/**
 * Returns all pending deposits withdrawal requests from the api
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const getPendingDepositsWithdrawals = async() => {
  try {
    const data: any = await serviceForCustomer({
      url: `${depositWithdrawalURL}/pending`,
      method: 'get',
    })
    return [null, data.content]
  } catch (error) {
    console.error('Cannot fetch pending deposits withdrawals details', error)
    return [error, null]
  }
}

/**
 * Utility function to get withdrawal and request deposits in parallel
 * Internally, calls the getPendingDeposits and getPendingDepositsWithdrawals
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const getAllPendingDeposits = async() => {
  try {
    const results = await Promise.all([
      getPendingDeposits(),
      getPendingDepositsWithdrawals(),
    ])
    return [null, results.map(r => r[1])]
  } catch (errors) {
    console.error('Cannot fetch all pending deposits', errors)
    return [errors.map((r: any) => r[0]), null]
  }
}

/**
 * Request to approve a pending deposit request
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending deposit request
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const approveDepositRequest = async({
  reference,
} : {
  reference: string,
}) => {
  try {
    const data: any = await serviceForCustomer.patch(`${depositRequestsURL}/${reference}/approve`)
    return [null, data.content]
  } catch (error) {
    console.error('Cannot approve deposit request', error)
    return [error, null]
  }
}

/**
 * Request to reject a pending deposit request
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending deposit
 * @param {string} config.comments comments - Reject reason
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const rejectDepositRequest = async({
  reference,
  comments,
} : {
  reference: string,
  comments: string,
}) => {
  try {
    const data: any = await serviceForCustomer.patch(
      `${depositRequestsURL}/${reference}/reject`,
      { comments },
    )
    return [null, data.content]
  } catch (error) {
    console.error('Cannot reject deposit request', error)
    return [error, null]
  }
}

/**
 * Request to approve a pending withdrawal deposit
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending withdrawal deposit
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const approveDepositWithdrawal = async({
  reference,
} : {
  reference: string,
}) => {
  try {
    const data: any = await serviceForCustomer.patch(`${depositWithdrawalURL}/${reference}/approve`)
    return [null, data.content]
  } catch (error) {
    console.error('Cannot approve deposit withdrawal', error)
    return [error, null]
  }
}

/**
 * Request to reject a pending withdrawal deposit
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending withdrawal deposit
 * @param {string} config.comments comments - Reject reason
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const rejectDepositWithdrawal = async({
  reference,
  comments,
} : {
  reference: string,
  comments: string,
}) => {
  try {
    const data: any = await serviceForCustomer.patch(
      `${depositWithdrawalURL}/${reference}/reject`,
      { comments },
    )
    return [null, data.content]
  } catch (error) {
    console.error('Cannot reject deposit withdrawal', error)
    return [error, null]
  }
}

/**
 * Utility function that calls the right reject function
 * based on the type of the deposits.
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending deposit we want to reject
 * @param {string} config.type type - Type of the pending deposit we want to reject (INVESTMENT_DEPOSIT_REQUEST or INVESTMENT_DEPOSIT_WITHDRAWAL)
 * @param {string} config.comments comments - Reject reason
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const rejectDeposit = ({
  reference,
  type,
  comments,
} : {
  reference: string,
  type: string,
  comments: string,
}) => {
  if (type === featureCodeList.INVESTMENT_DEPOSIT_REQUEST) {
    return rejectDepositRequest({ reference, comments })
  }

  if (type === featureCodeList.INVESTMENT_DEPOSIT_WITHDRAWAL) {
    return rejectDepositWithdrawal({ reference, comments })
  }

  return [new Error('Unsupported deposit type.')]
}

/**
 * Utility function that calls the right approve function
 * based on the type of the deposits.
 * @param {Object} config
 * @param {string} config.reference reference - Reference of the pending deposit we want to approve
 * @param {string} config.type type - Type of the pending deposit we want to approve (INVESTMENT_DEPOSIT_REQUEST or INVESTMENT_DEPOSIT_WITHDRAWAL)
 *
 * @returns {Promise<Array>} Returns an array containing the error in the first index, and the result in the second one.
 */
export const approveDeposit = ({
  reference,
  type,
} : {
  reference: string,
  type: string,
}) => {
  if (type === featureCodeList.INVESTMENT_DEPOSIT_REQUEST) {
    return approveDepositRequest({ reference })
  }

  if (type === featureCodeList.INVESTMENT_DEPOSIT_WITHDRAWAL) {
    return approveDepositWithdrawal({ reference })
  }

  return [new Error('Unsupported deposit type.')]
}
