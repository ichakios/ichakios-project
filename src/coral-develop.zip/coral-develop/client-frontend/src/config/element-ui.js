import Vue from 'vue'
import i18n from '@/i18n'
import ElementUI, { Message } from 'element-ui'

Vue.use(ElementUI, { i18n: (key, value) => i18n.t(key, value) })

const messageOptions = {
  default: {
    showClose: true,
    offset: 90,
    duration: 3000,
  },
  error: {
    duration: 0,
  },
}

const getMessageFunction = (options) => {
  Message({
    ...messageOptions.default,
    ...(messageOptions[options.type] || {}),
    ...options,
  })
}

Vue.prototype.$message = (options) => getMessageFunction(options)
Vue.prototype.$message.success = (message) => getMessageFunction({ type: 'success', message })
Vue.prototype.$message.error = (message) => getMessageFunction({ type: 'error', message })
Vue.prototype.$message.warning = (message) => getMessageFunction({ type: 'warning', message })
Vue.prototype.$message.info = (message) => getMessageFunction({ type: 'info', message })
