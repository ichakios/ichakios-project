import countries from 'i18n-iso-countries'
import countriesEN from 'i18n-iso-countries/langs/en.json'
import countriesAR from 'i18n-iso-countries/langs/ar.json'

countries.registerLocale(countriesEN)
countries.registerLocale(countriesAR)
