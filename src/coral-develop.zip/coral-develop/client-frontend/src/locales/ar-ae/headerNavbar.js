module.exports = {
  loggedInto: 'الدخول الى',
}
