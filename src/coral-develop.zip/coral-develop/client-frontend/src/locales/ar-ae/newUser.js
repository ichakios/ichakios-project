module.exports = {
  firstName: 'الاسم الاول',
  lastName: 'الكنية',
  email: 'البريد الإلكتروني',
  emailValidator: {
    incorrect: 'يرجى إدخال عنوان البريد الإلكتروني الصحيح',
  },
  mobileNumber: 'رقم الهاتف المحمول',
  internationalFormat: 'التنسيق الدولي +971',
  password: 'كلمه السر',
  confirmPassword: 'تأكيد كلمة المرور',
  roles: 'الأدوار',
  noRoles: 'لا أدوار',
  cancel: 'إلغاء',
  addUser: 'أضف مستخدم',
  userCreated: 'تم إنشاء المستخدم بنجاح',
  userUpdated: 'تم تحديث المستخدم بنجاح',
  rolesAdditionError: 'حدث خطأ عند تعيين أدوار {userEmail}. حاول مرة أخرى بتحرير هذا المستخدم.',
  errorCreatingUser: 'حدث خطأ في إنشاء المستخدم',
  save: 'تحديث المستخدم',
  previewUser: 'معاينة المستخدم',
  loadingRoles: 'جارٍ تحميل الأدوار ...',
  selectRoles: 'حدد الأدوار',
  rolesListingError: 'حدث خطأ عند جلب الأدوار.',
  form: {
    errors: {
      firstName: {
        required: 'الاسم الأول مطلوب',
      },
      lastName: {
        required: 'الاسم الأخير مطلوب',
      },
      email: {
        required: 'البريد الإلكتروني مطلوب',
        email: 'يرجى تقديم عنوان بريد إلكتروني صالح',
        alreadyUsed: 'هذا البريد الإلكتروني مستخدم بالفعل ، اختر واحدًا آخر',
      },
      password: {
        required: 'كلمة المرور مطلوبة',
        minLength: 'يجب أن تحتوي كلمة المرور على 8 أحرف على الأقل',
      },
      confirmPassword: {
        sameAsPassword: 'يجب أن تكون كلمات المرور متطابقة',
      },
      mobileNumber: {
        required: 'رقم الجوال مطلوب',
        validPhoneNumber: 'يرجى تقديم رقم هاتف محمول صالح (تنسيق دولي)',
      },
    },
  },
  tooltips: {
    firstName: 'الاسم الأول للمستخدم',
    lastName: 'الاسم الأخير للمستخدم',
    email: 'البريد الالكتروني للمستخدم',
    mobileNumber: 'رقم جوال المستخدم',
    roles: 'أدوار المستخدمين',
    password: 'كلمة مرور المستخدم',
    confirmPassword: 'تأكيد كلمة مرور المستخدم',
  },
}
