module.exports = {
  undefinedActionBy: 'عمل بواسطة',
  stepList: {
    by: {
      initialize: 'بتوصية من',
      check: {
        accepted: 'فحص بواسطة',
        rejected: 'مرفوض من طرف',
        pending: 'تحقق في التقدم بحلول',
      },
      authorize: {
        accepted: 'مفوض من',
        rejected: 'مرفوض من طرف',
        pending: 'التفويض قيد التقدم بحلول',
      },
      release: {
        accepted: 'صدر عن',
        rejected: 'مرفوض من طرف',
        pending: 'الإصدار قيد التقدم بحلول',
      },
    },
  },
  messages: {
    loadError: 'فشل تحميل سجل الموافقة',
  },
}
