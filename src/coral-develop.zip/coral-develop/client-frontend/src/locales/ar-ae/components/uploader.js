module.exports = {
  add: 'اضف ملف',
  maxSize: '{maxSize} كحد أقصى',
}
