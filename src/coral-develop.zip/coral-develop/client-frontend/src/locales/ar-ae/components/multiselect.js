module.exports = {
  placeholder: 'حدد الخيار',
  tagPlaceholder: 'اضغط على Enter لإنشاء علامة',
  selectLabel: 'اضغط على Enter للتحديد',
  selectGroupLabel: 'اضغط على Enter لتحديد المجموعة',
  selectedLabel: 'المحدد',
  deselectLabel: 'اضغط على Enter للإزالة',
  deselectGroupLabel: 'اضغط على Enter لإلغاء تحديد المجموعة',
}
