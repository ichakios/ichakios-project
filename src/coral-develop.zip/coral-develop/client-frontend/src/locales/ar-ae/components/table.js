module.exports = {
  noData: 'لايوجد بيانات',
}
