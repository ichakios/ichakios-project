module.exports = {
  undefined: 'لا ملف',
  exceedLimit: 'تجاوز الحد {maxSize} ، لن يتم تحميله',
}
