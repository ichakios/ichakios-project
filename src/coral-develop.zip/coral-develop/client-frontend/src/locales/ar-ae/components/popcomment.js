module.exports = {
  error: {
    required: 'هذه القيمة مطلوبة',
  },
}
