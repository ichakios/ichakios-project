module.exports = {
  noResult: 'لم يتم العثور على حسابات',
  noOptions: 'لا توجد حسابات متاحة',
  placeholder: 'حدد حسابًا',
  currentBalance: 'الرصيد الحالي',
  availableBalance: 'الرصيد المتوفر',
}
