const account = require('./account')
const accountSelect = require('./components/accountSelect')
const authorityMatrix = require('./authorityMatrix')
const beneficiary = require('./beneficiary')
const beneficiaryDrawer = require('./beneficiaryDrawer')
const constants = require('./constants')
const dashboard = require('./dashboard')
const deposits = require('./deposits')
const filePreview = require('./components/filePreview')
const loginPage = require('./login')
const multiselect = require('./components/multiselect')
const myTransfers = require('./myTransfers')
const newUser = require('./newUser')
const sweeps = require('./sweeps')
const pendingDeposits = require('./pendingDeposits')
const pendingFacilities = require('./pendingFacilities')
const pendingPayments = require('./pendingPayments')
const pendingSweeps = require('./pendingSweeps')
const popcomment = require('./components/popcomment')
const popinput = require('./components/popinput')
const routes = require('./routes')
const table = require('./components/table')
const tasks = require('./tasks')
const userManagement = require('./userManagement')
const uploader = require('./components/uploader')
const standingInstructions = require('./standingInstructions')
const facilitiesRequests = require('./facilitiesRequests')
const transfer = require('./transfer')
const guarantees = require('./guarantees')
const sweepRequests = require('./sweepRequests')
const headerNavbar = require('./headerNavbar')
const standingInstructionsRequests = require('./standingInstructionsRequests')
const approvalHistory = require('./approvalHistory')
const pendingStandingInstructions = require('./pendingStandingInstructions')

module.exports = {
  cancel: 'إلغاء',
  login: 'تسجيل الدخول',
  languages: 'اللغات',
  lang: {
    en: 'الإنجليزية',
    'ar-ae': 'عربى',
  },
  and: 'و',
  at: 'في',
  faq: 'FAQs',
  startDate: 'تاريخ البدء',
  endDate: 'تاريخ الانتهاء',
  search: 'بحث...',
  last30days: 'آخر 30 يومًا',
  thisMonth: 'الشهر الحالي',
  lastMonth: 'الشهر الماضى',
  lastThreeMonths: 'الأشهر الثلاثة الأخيرة',
  to: 'إلى',
  nothingToShow: 'لا شيء لإظهاره',
  navbar: {
    account: 'الحساب',
    logout: 'تسجيل خروج',
    welcome: 'أهلا بك',
    welcomeBack: 'مرحبا بعودتك',
    lastLogged: 'آخر تسجيل',
    today: 'اليوم',
    seeAllTasks: 'شاهد جميع المهام',
  },
  components: {
    accountSelect,
    filePreview,
    multiselect,
    popcomment,
    popinput,
    table,
    uploader,
  },
  error: {
    server: 'حدث خطأ على الخادم. يرجى المحاولة مرة أخرى لاحقًا أو الاتصال بالمسؤول إذا استمر الخطأ.',
  },
  account,
  authorityMatrix,
  beneficiary,
  constants,
  dashboard,
  loginPage,
  newUser,
  deposits,
  routes,
  beneficiaryDrawer,
  userManagement,
  myTransfers,
  sweeps,
  pendingPayments,
  pendingDeposits,
  pendingFacilities,
  pendingSweeps,
  tasks,
  standingInstructions,
  facilitiesRequests,
  transfer,
  guarantees,
  sweepRequests,
  headerNavbar,
  standingInstructionsRequests,
  approvalHistory,
  pendingStandingInstructions,
}
