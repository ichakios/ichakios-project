module.exports = {
  emptyList: 'لا توجد مهام',
  startDatePlaceholder: 'تاريخ البدء',
  endDatePlaceholder: 'تاريخ الانتهاء',
  thisMonth: 'هذا الشهر',
  twoMonthsAgo: 'قبل شهرين',
  tasksCountError: 'فشل الحصول على المهام المعلقة',
  tabs: {
    payments: 'التحويلات',
    deposits: 'الودائع',
    facilities: 'مرافق',
    sweeps: 'مداهمات',
    'standing-instructions': 'تعليمات دائمة',
  },
}
