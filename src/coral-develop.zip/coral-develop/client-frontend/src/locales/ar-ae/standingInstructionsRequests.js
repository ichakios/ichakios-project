module.exports = {
  headers: {
    title: 'عنوان',
    type: 'نوع',
    createdOn: 'تاريخ',
    siId: 'معرف التعليمات الدائمة',
    requestedBy: 'بتوصية من',
    status: 'الحالة',
    to: 'إلى',
    amount: 'كمية',
    startDate: 'تاريخ البدء',
    frequency: 'تكرر',
    actionType: 'نوع الإجراء',

  },
  actions: {
    details: 'عرض التفاصيل',
    cancel: 'إلغاء',
    close: 'قريب',
  },
  requestStatus: {
    PENDING_APPROVAL: 'في انتظار الموافقة',
    APPROVED: 'وافق',
    REJECTED: 'مرفوض',
    PROCESSED: 'تمت معالجتها',
    CANCELED: 'ألغيت',
    PROCESSED_BY_BANK: 'تمت المعالجة عن طريق البنك',
    REJECTED_BY_BANK: 'مرفوض من قبل البنك',
  },
  cancelComment: {
    reason: 'إلغاء السبب',
    cancel: 'إلغاء',
    close: 'قريب',
    confirm: 'تؤكد',
    edit: 'تعديل',

  },
  messages: {
    SIRequestCancelSuccess: 'تم إلغاء الطلب بنجاح.',
  },
  errors: {
    SIRequestFetch: 'حدث خطأ أثناء تحميل طلبات التعليمات الدائمة.',
    SIRequestCancelError: 'لا يمكن إلغاء الطلب.',
    cancelReason: {
      required: 'تحتاج إلى تقديم سبب الإلغاء',
    },
  },
  detailsLabel: {
    title: 'عنوان',
    date: 'تاريخ',
    requiredBy: 'مطلوب من قبل',
    status: 'الحالة',
    from: 'من عند',
    to: 'إلى',
    amount: 'كمية',
    startAt: 'يبدأ في',
    endAt: 'ينتهي عند',
    repeatUntil: 'كرر حتى',
    paymentFrequency: 'تكرار دفع',
    chargeBearer: 'المسؤول',
    purpose: 'غرض',
    numberOfInstallments: 'عدد الأقساط',
    paymentInterval: 'فترة',
    siId: 'معرف التعليمات الدائمة',

  },
  actionTypes: {
    create: 'خلق',
    modify: 'تعديل',
    cancel: 'إلغاء',
  },
}
