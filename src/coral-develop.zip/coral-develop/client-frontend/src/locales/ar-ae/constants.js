module.exports = {
  currency: {
    AED: 'د.إ',
  },
  productTypes: {
    SERVICES: 'خدمات',
    PAYMENT_INTERNATIONAL: 'الدفع / دولي',
  },
  roles: {
    INPUTTERS: 'المدخلات',
    CHECKERS: 'لعبة الداما',
    AUTHORIZERS: 'المخولون',
    RELEASERS: 'المثيرون',
  },
  amountTypes: {
    BETWEEN: 'ما بين',
    GREATER_THAN: 'أكثر من',
    LESS_THAN: 'أقل من',
    GREATER_THAN_OR_EQUAL: 'أكبر من أو يساوي',
    LESS_THAN_OR_EQUAL: 'اصغر من او يساوي',
  },
}

