module.exports = {
  undefinedActionBy: 'Action by',
  stepList: {
    by: {
      initialize: 'Requested by',
      check: {
        accepted: 'Checked by',
        rejected: 'Rejected by',
        pending: 'Check in progress by',
      },
      authorize: {
        accepted: 'Authorized by',
        rejected: 'Rejected by',
        pending: 'Authorization in progress by',
      },
      release: {
        accepted: 'Released by',
        rejected: 'Rejected by',
        pending: 'Release in progress by',
      },
    },
  },
  messages: {
    loadError: 'Failed to load the approval history',
  },
}
