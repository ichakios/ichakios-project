module.exports = {
  heading: {
    search: 'Search...',
  },
  body: {
    account: 'On Account',
    sweepType: 'Sweep Type',
    sweepAmount: 'Amount',
    amount: 'Amount',
    actions: 'Actions',
    accountCover: 'Cover Account',
    edit: 'Edit',
    cancel: 'Cancel',
    toAccount: 'To Account',
    fromAccount: 'From Account',
    fromAccount1: 'From Account 1',
    fromAccount2: 'From Account 2',
    noSelectedFromAccount2: 'No account selected',
    amountPlaceholder: 'Please enter amount',
    confirm: 'Are you sure you want to cancel this sweep?',
  },
  close: 'Cancel',
  confirm: 'Confirm',
  preview: 'Preview',
  submit: 'Submit',
  back: 'Back',
  clear: 'Clear',
  currency: {
    AED: 'AED',
  },
  status: {
    addedSuccess: 'Sweep successfully submitted to approval',
    addedError: 'An error occurred when creating a sweep',
    editSuccess: 'Sweep edited successfully',
    cancelSuccess: 'Sweep cancelled successfully',
    cancelError: 'An error occurred when cancelling a sweep',
    editError: 'An error occurred while editing a sweep',
    checkError: 'The sweep is invalid',
  },
  sweepTypes: {
    REAL_TIME_SWEEP: 'Maintain Insufficient Balance/Realtime Sweep',
    MAINTAIN_MIN_BALANCE: 'Maintain Minimum Balance',
    MAINTAIN_MAX_BALANCE: 'Maintain Maximum Balance',
  },
  errors: {
    failSweeps: 'Failed to load the sweeps',
    errorLoadingAccounts: 'An error occurred when loading accounts',
    circularDependency: 'This sweep setup is not allowed as accounts are already linked',
    fromAccount: {
      isRequired: 'From account is required',
      circularDependency: ' ', // we need to keep it empty, because the message is common to all fields
    },
    optionalFromAccount: {
      circularDependency: ' ', // we need to keep it empty, because the message is common to all fields
    },
    toAccount: {
      isRequired: 'To account is required',
      circularDependency: ' ', // we need to keep it empty, because the message is common to all fields
    },
    onAccount: {
      isRequired: 'On account is required',
      circularDependency: ' ', // we need to keep it empty, because the message is common to all fields
    },
    sweepType: {
      isRequired: 'Sweep type is required',
      invalidSweepType: 'This sweep type is invalid',
    },
    amount: {
      isRequired: 'Amount is required',
      minValue: 'The amount should be greater than 0',
    },
  },
  newSweep: 'New Sweep',
  editSweep: 'Edit Sweep',
  tooltips: {
    sweepType: 'Sweep Type',
    account: 'Account',
    amount: 'Amount',
    toAccount: 'To Account',
    fromAccount2: 'From Account 2',
    fromAccount1: 'From Account 1',
    fromAccount: 'From Account',
  },
}
