module.exports = {
  add: 'Add file',
  maxSize: '{maxSize} max',
}
