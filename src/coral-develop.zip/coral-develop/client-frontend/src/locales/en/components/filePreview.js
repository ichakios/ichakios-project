module.exports = {
  undefined: 'No file',
  exceedLimit: 'Exceed the {maxSize} limit, will not be uploaded',
}
