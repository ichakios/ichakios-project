module.exports = {
  error: {
    required: 'This value is required',
  },
}
