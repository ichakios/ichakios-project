module.exports = {
  noResult: 'No Accounts found',
  noOptions: 'No Accounts available',
  placeholder: 'Select Account',
  currentBalance: 'Current Balance',
  availableBalance: 'Available Balance',
}
