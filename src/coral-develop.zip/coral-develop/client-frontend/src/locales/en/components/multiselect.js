module.exports = {
  placeholder: 'Select option',
  tagPlaceholder: 'Press enter to create a tag',
  selectLabel: 'Press enter to select',
  selectGroupLabel: 'Press enter to select group',
  selectedLabel: 'Selected',
  deselectLabel: 'Press enter to remove',
  deselectGroupLabel: 'Press enter to deselect group',
}
