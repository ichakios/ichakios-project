module.exports = {
  noData: 'No data',
}
