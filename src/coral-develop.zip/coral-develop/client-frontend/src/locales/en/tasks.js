module.exports = {
  emptyList: 'No Tasks',
  startDatePlaceholder: 'Start Date',
  endDatePlaceholder: 'End Date',
  thisMonth: 'Current month',
  twoMonthsAgo: 'Last two months',
  tasksCountError: 'Failed to get pending tasks count',
  tabs: {
    payments: 'Transfers',
    deposits: 'Deposits',
    facilities: 'Loans',
    sweeps: 'Sweeps',
    'standing-instructions': 'Standing Instructions',
  },
}
