const buildEmptyMessage = label => {
  return `${label} can not be empty`
}

module.exports = {
  firstName: 'First name',
  lastName: 'Last name',
  firstNameEmpty: buildEmptyMessage('First name'),
  lastNameEmpty: buildEmptyMessage('Last name'),
  emailEmpty: buildEmptyMessage('Email'),
  mobileNumberEmpty: buildEmptyMessage('Mobile number'),
  email: 'Email',
  emailValidator: {
    incorrect: 'Please input correct email address',
  },
  password: 'Password',
  confirmPassword: 'Confirm password',
  mobileNumber: 'Mobile number',
  internationalFormat: 'International format +971',
  roles: 'Roles',
  noRoles: 'No roles',
  cancel: 'Cancel',
  addUser: 'Add user',
  userCreated: 'User created successfully',
  userUpdated: 'User updated successfully',
  rolesAdditionError: 'There was an error when setting the roles of {userEmail}. Try again by editing this user.',
  errorCreatingUser: 'There was an error creating the user',
  save: 'Update user',
  previewUser: 'Preview user',
  loadingRoles: 'Loading roles...',
  selectRoles: 'Select roles',
  rolesListingError: 'There was an error when fetching roles.',
  form: {
    errors: {
      firstName: {
        required: 'The firstname is required',
      },
      lastName: {
        required: 'The lastname is required',
      },
      email: {
        required: 'The email is required',
        email: 'Please provide a valid email',
        alreadyUsed: 'This email is already used, choose another one',
      },
      password: {
        required: 'The password is required',
        minLength: 'The password should have 8 characters at least',
      },
      confirmPassword: {
        sameAsPassword: 'Passwords must be identical',
      },
      mobileNumber: {
        required: 'Mobile number is required',
        validPhoneNumber: 'Invalid international mobile number',
      },
    },
  },
  tooltips: {
    firstName: 'User First name',
    lastName: 'User Last name',
    email: 'User Email',
    mobileNumber: 'User Mobile number',
    roles: 'User roles',
    password: 'User password',
    confirmPassword: 'Confirm user password',
  },
}
