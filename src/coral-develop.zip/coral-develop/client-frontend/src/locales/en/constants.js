module.exports = {
  currency: {
    AED: 'AED',
  },
}

