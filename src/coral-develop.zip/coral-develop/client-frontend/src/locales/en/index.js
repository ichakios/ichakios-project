const account = require('./account')
const accountSelect = require('./components/accountSelect')
const authorityMatrix = require('./authorityMatrix')
const beneficiary = require('./beneficiary')
const beneficiaryDrawer = require('./beneficiaryDrawer')
const constants = require('./constants')
const dashboard = require('./dashboard')
const deposits = require('./deposits')
const filePreview = require('./components/filePreview')
const loginPage = require('./login')
const multiselect = require('./components/multiselect')
const myTransfers = require('./myTransfers')
const newUser = require('./newUser')
const sweeps = require('./sweeps')
const pendingDeposits = require('./pendingDeposits')
const pendingFacilities = require('./pendingFacilities')
const pendingPayments = require('./pendingPayments')
const pendingSweeps = require('./pendingSweeps')
const popcomment = require('./components/popcomment')
const popinput = require('./components/popinput')
const routes = require('./routes')
const table = require('./components/table')
const tasks = require('./tasks')
const userManagement = require('./userManagement')
const uploader = require('./components/uploader')
const standingInstructions = require('./standingInstructions')
const facilitiesRequests = require('./facilitiesRequests')
const transfer = require('./transfer')
const guarantees = require('./guarantees')
const sweepRequests = require('./sweepRequests')
const headerNavbar = require('./headerNavbar')
const standingInstructionsRequests = require('./standingInstructionsRequests')
const approvalHistory = require('./approvalHistory')
const pendingStandingInstructions = require('./pendingStandingInstructions')

module.exports = {
  cancel: 'cancel',
  login: 'login',
  languages: 'Languages',
  lang: {
    en: 'English',
    'ar-ae': 'Arabic',
  },
  and: 'and',
  at: 'at',
  faq: 'FAQs',
  startDate: 'Start date',
  endDate: 'End date',
  search: 'Search...',
  last30days: 'Last 30 days',
  thisMonth: 'Current month',
  lastMonth: 'Previous month',
  lastThreeMonths: 'Last three months',
  to: 'to',
  nothingToShow: 'Nothing to show',
  navbar: {
    account: 'Account',
    logout: 'Logout',
    welcome: 'Welcome ',
    welcomeBack: 'Welcome back ',
    lastLogged: 'Last logged the',
    today: 'Today',
    seeAllTasks: 'See all tasks',
  },
  components: {
    accountSelect,
    filePreview,
    multiselect,
    popcomment,
    popinput,
    table,
    uploader,
  },
  error: {
    server: 'An error occurred on the server. Please try again later or contact an administrator if the error persists.',
  },
  account,
  deposits,
  authorityMatrix,
  beneficiary,
  constants,
  dashboard,
  loginPage,
  newUser,
  routes,
  beneficiaryDrawer,
  userManagement,
  myTransfers,
  sweeps,
  pendingPayments,
  pendingDeposits,
  pendingFacilities,
  pendingSweeps,
  tasks,
  standingInstructions,
  facilitiesRequests,
  transfer,
  guarantees,
  sweepRequests,
  headerNavbar,
  standingInstructionsRequests,
  approvalHistory,
  pendingStandingInstructions,
}
