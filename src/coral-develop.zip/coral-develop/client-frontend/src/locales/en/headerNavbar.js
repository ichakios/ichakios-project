module.exports = {
  loggedInto: 'Logged into',
}
