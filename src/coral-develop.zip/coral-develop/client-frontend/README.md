# Client frontend

This app uses the [vue-element-admin](https://panjiachen.github.io/vue-element-admin) template.

---

## Dev

```bash
npm run dev       # launch the app in dev mode
npm run build     # package the app to be served in production mode

npm run storybook # Launch storybook
```

---

## Dev Documentation

[Access Frontend Dev Documentation](../documentation/frontend)

---

## Debug Production Build

```bash
npm run build:serve
```