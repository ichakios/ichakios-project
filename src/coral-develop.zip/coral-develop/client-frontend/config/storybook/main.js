module.exports = {
  stories: ['../../src/**/*.stories.(js|jsx|ts|tsx|mdx)'],
  addons: [
    '@storybook/addon-actions',
    {
      name: '@storybook/addon-docs',
      options: {
        babelOptions: {
          presets: [
            [
              '@vue/app',
              {
                jsx: false
              }
            ]
          ]
        }
      }
    },
    '@storybook/addon-links'
  ]
}
