import Vue from 'vue'
import Router from 'vue-router'
import { addParameters, addDecorator } from '@storybook/vue'
import VueI18n from 'vue-i18n'
import vuelidate from 'vuelidate'
import StoryRouter from 'storybook-vue-router'
import i18n from '../../src/i18n'
import '../../src/config/dayjs'
import '../../src/config/element-ui'
import '../../src/config/i18n-iso-countries'
import '../../src/config/vue-currency-input'
import '../../src/styles/docs.scss'

document.getElementsByTagName('html')[0].dir = 'ltr'
Vue.use(Router)
Vue.use(VueI18n)
Vue.use(vuelidate)

addParameters({
  options: {
    showRoots: true,
  },
})

addDecorator(StoryRouter())
addDecorator(() => ({
  template: '<story/>',
  i18n,
}))
