module.exports = {
  plugins: {
    autoprefixer: {},
    'postcss-rtl': require('postcss-rtl')
  }
}
