package com.zand.service.dto;

import java.util.Objects;

/**
 * account transactions list dto.
 */
public class AccountTransactionListDto extends HasNicknameDto {
// CHECKSTYLE:OFF

  private String trxReferenceNo;

  private String wDate;

  private String valueDate;

  private String chequeID;

  private String description;

  private String trxType;

  private String amount;

  private String foreignAmount;

  private String balance;

  private String channelRefID;

  private String narrationID;

  public String getTrxReferenceNo() {
    return trxReferenceNo;
  }

  public void setTrxReferenceNo(String trxReferenceNo) {
    this.trxReferenceNo = trxReferenceNo;
  }

  public String getwDate() {
    return wDate;
  }

  public void setwDate(String wDate) {
    this.wDate = wDate;
  }

  public String getValueDate() {
    return valueDate;
  }

  public void setValueDate(String valueDate) {
    this.valueDate = valueDate;
  }

  public String getChequeID() {
    return chequeID;
  }

  public void setChequeID(String chequeID) {
    this.chequeID = chequeID;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getTrxType() {
    return trxType;
  }

  public void setTrxType(String trxType) {
    this.trxType = trxType;
  }

  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  public String getForeignAmount() {
    return foreignAmount;
  }

  public void setForeignAmount(String foreignAmount) {
    this.foreignAmount = foreignAmount;
  }

  public String getBalance() {
    return balance;
  }

  public void setBalance(String balance) {
    this.balance = balance;
  }

  public String getChannelRefID() {
    return channelRefID;
  }

  public void setChannelRefID(String channelRefID) {
    this.channelRefID = channelRefID;
  }

  public String getNarrationID() {
    return narrationID;
  }

  public void setNarrationID(String narrationID) {
    this.narrationID = narrationID;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    AccountTransactionListDto that = (AccountTransactionListDto) o;
    return Objects.equals(trxReferenceNo, that.trxReferenceNo) &&
            Objects.equals(wDate, that.wDate) &&
            Objects.equals(valueDate, that.valueDate) &&
            Objects.equals(chequeID, that.chequeID) &&
            Objects.equals(description, that.description) &&
            Objects.equals(trxType, that.trxType) &&
            Objects.equals(amount, that.amount) &&
            Objects.equals(foreignAmount, that.foreignAmount) &&
            Objects.equals(balance, that.balance) &&
            Objects.equals(channelRefID, that.channelRefID) &&
            Objects.equals(narrationID, that.narrationID);
  }

  @Override
  public int hashCode() {
    return Objects.hash(trxReferenceNo, wDate, valueDate, chequeID, description,
            trxType, amount, foreignAmount, balance, channelRefID, narrationID);
  }

  @Override
  public String toString() {
    return "AccountTransactionListDto{" +
            "trxReferenceNo='" + trxReferenceNo + '\'' +
            ", wDate='" + wDate + '\'' +
            ", valueDate='" + valueDate + '\'' +
            ", chequeID='" + chequeID + '\'' +
            ", description='" + description + '\'' +
            ", trxType='" + trxType + '\'' +
            ", amount='" + amount + '\'' +
            ", foreignAmount='" + foreignAmount + '\'' +
            ", balance='" + balance + '\'' +
            ", channelRefID='" + channelRefID + '\'' +
            ", narrationID='" + narrationID + '\'' +
            '}';
  }
  // CHECKSTYLE:ON
}
