package com.zand.service.dto;

import java.util.List;

/**
 * statement by date range dto.
 */
public class TransactionsDateRangeDto {

  /**
   * pdf file name.
   */
  private String pdfFileName;

  /**
   * pdf string.
   */
  private String pdfBase64String;

  // CHECKSTYLE:OFF
  private BankDetailsDto bankDetails;

  private AccountListDto accountDetails;

  private String openingBalance;

  private String closingBalance;

  private String noOfTodaysCrTrx;

  private String noOfTodaysDrTrx;

  private String todaysDebitAmount;

  private String todaysCreditAmount;

  private List<AccountTransactionListDto> statementRecords;

  public String getPdfFileName() {
    return pdfFileName;
  }

  public void setPdfFileName(String pdfFileName) {
    this.pdfFileName = pdfFileName;
  }

  public String getPdfBase64String() {
    return pdfBase64String;
  }

  public void setPdfBase64String(String pdfBase64String) {
    this.pdfBase64String = pdfBase64String;
  }

  public BankDetailsDto getBankDetails() {
    return bankDetails;
  }

  public void setBankDetails(BankDetailsDto bankDetails) {
    this.bankDetails = bankDetails;
  }

  public AccountListDto getAccountDetails() {
    return accountDetails;
  }

  public void setAccountDetails(AccountListDto accountDetails) {
    this.accountDetails = accountDetails;
  }

  public String getOpeningBalance() {
    return openingBalance;
  }

  public void setOpeningBalance(String openingBalance) {
    this.openingBalance = openingBalance;
  }

  public String getClosingBalance() {
    return closingBalance;
  }

  public void setClosingBalance(String closingBalance) {
    this.closingBalance = closingBalance;
  }

  public String getNoOfTodaysCrTrx() {
    return noOfTodaysCrTrx;
  }

  public void setNoOfTodaysCrTrx(String noOfTodaysCrTrx) {
    this.noOfTodaysCrTrx = noOfTodaysCrTrx;
  }

  public String getNoOfTodaysDrTrx() {
    return noOfTodaysDrTrx;
  }

  public void setNoOfTodaysDrTrx(String noOfTodaysDrTrx) {
    this.noOfTodaysDrTrx = noOfTodaysDrTrx;
  }

  public String getTodaysDebitAmount() {
    return todaysDebitAmount;
  }

  public void setTodaysDebitAmount(String todaysDebitAmount) {
    this.todaysDebitAmount = todaysDebitAmount;
  }

  public String getTodaysCreditAmount() {
    return todaysCreditAmount;
  }

  public void setTodaysCreditAmount(String todaysCreditAmount) {
    this.todaysCreditAmount = todaysCreditAmount;
  }

  public List<AccountTransactionListDto> getStatementRecords() {
    return statementRecords;
  }

  public void setStatementRecords(List<AccountTransactionListDto> statementRecords) {
    this.statementRecords = statementRecords;
  }

  // CHECKSTYLE:ON
}

