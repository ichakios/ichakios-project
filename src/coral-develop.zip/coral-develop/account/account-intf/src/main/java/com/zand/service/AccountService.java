package com.zand.service;

import com.zand.service.dto.AccountSummaryDto;
import java.util.UUID;

/**
 * The interface to handle accounts.
 */
public interface AccountService {

  /**
   * Method to save account metadata.
   *
   * @param account account with its metadata (e.g nickname).
   * @param customerKey the customerKey the account belong's to.
   */
  void saveAccountMetadata(AccountSummaryDto account, UUID customerKey);

  /**
   * Method to delete an account nickname.
   *
   * @param accountId account id with its nickname.
   * @param customerKey the customerKey the account belong's to.
   */
  void deleteAccountNickname(String accountId, UUID customerKey);
}


