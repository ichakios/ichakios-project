package com.zand.service.validate;

/**
 * sign on request header to validate bic.
 */
public class SignOnRequestForValidateIban {

  /**
   * sign on request header.
   */
  private SignOnRq signOnRq;

  /**
   * param-iban number.
   */
  private String param;

  /**
   * type.
   */
  private String type;

  /**
   * country code.
   */
  private String countryCode;

  /**
   * getter.
   *
   * @return current sign on header request.
   */

  public SignOnRq getSignOnRq() {
    return signOnRq;
  }

  /**
   * setter.
   *
   * @param signOnRq sign on request to set.
   */
  public void setSignOnRq(SignOnRq signOnRq) {
    this.signOnRq = signOnRq;
  }

  /**
   * getter.
   *
   * @return current param iban.
   */
  public String getParam() {
    return param;
  }

  /**
   * setter.
   *
   * @param param iban to set.
   */
  public void setParam(String param) {
    this.param = param;
  }

  /**
   * getter.
   *
   * @return current type.
   */
  public String getType() {
    return type;
  }

  /**
   * setter.
   *
   * @param type type to set .
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * getter.
   *
   * @return current country Code.
   */
  public String getCountryCode() {
    return countryCode;
  }

  /**
   * setter.
   *
   * @param countryCode country Code to set.
   */
  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }
}
