package com.zand.service.validate;

/**
 * sign on request.
 */
public class SignOnRq {

  /**
   * log id  for request.
   */
  private String logId;

  /**
   * date and time for request.
   */
  private String dateTime;

  /**
   * channel id for request.
   */
  private String channelId;

  /**
   * branch id  for request.
   */
  private String ourBranchId;

  /**
   * getter.
   *
   * @return current log id.
   */
  public String getLogId() {
    return logId;
  }

  /**
   * setter.
   *
   * @param logId status code to set.
   */
  public void setLogId(String logId) {
    this.logId = logId;
  }

  /**
   * getter.
   *
   * @return current date and time.
   */
  public String getDateTime() {
    return dateTime;
  }

  /**
   * setter.
   *
   * @param dateTime status code to set.
   */
  public void setDateTime(String dateTime) {
    this.dateTime = dateTime;
  }

  /**
   * getter.
   *
   * @return current channel id.
   */
  public String getChannelId() {
    return channelId;
  }

  /**
   * setter.
   *
   * @param channelId status code to set.
   */
  public void setChannelId(String channelId) {
    this.channelId = channelId;
  }

  /**
   * getter.
   *
   * @return current branch id.
   */
  public String getOurBranchId() {
    return ourBranchId;
  }

  /**
   * setter.
   *
   * @param ourBranchId status code to set.
   */
  public void setOurBranchId(String ourBranchId) {
    this.ourBranchId = ourBranchId;
  }

}
