package com.zand.service.dto;

import com.zand.service.dto.AccountListDto;
import com.zand.service.dto.AccountTransactionListDto;
import com.zand.service.dto.HasNicknameDto;
import java.util.List;

/**
 * account details dto.
 */
public class AccountDetailsDto {
// CHECKSTYLE:OFF

  private AccountListDto accountDetails;

  private List<AccountTransactionListDto> statementRecords = null;

  public List<AccountTransactionListDto> getStatementRecords() {
    return statementRecords;
  }

  public void setStatementRecords(List<AccountTransactionListDto> statementRecords) {
    this.statementRecords = statementRecords;
  }

  public AccountListDto getAccountDetails() {
    return accountDetails;
  }

  public void setAccountDetails(AccountListDto accountDetails) {
    this.accountDetails = accountDetails;
  }
  // CHECKSTYLE:ON
}
