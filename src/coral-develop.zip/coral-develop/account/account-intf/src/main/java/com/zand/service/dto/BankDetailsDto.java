package com.zand.service.dto;

/**
 * bank details dto.
 */
public class BankDetailsDto {

  // CHECKSTYLE:OFF
  private String ourBankID;

  private String ourBankName;

  private String ourBranchID;

  private String ourBranchName;

  private String ourBranchAddress;

  private String ourBranchCity;

  private String country;

  private String phone1;

  public String getOurBankID() {
    return ourBankID;
  }

  public void setOurBankID(String ourBankID) {
    this.ourBankID = ourBankID;
  }

  public String getOurBankName() {
    return ourBankName;
  }

  public void setOurBankName(String ourBankName) {
    this.ourBankName = ourBankName;
  }

  public String getOurBranchID() {
    return ourBranchID;
  }

  public void setOurBranchID(String ourBranchID) {
    this.ourBranchID = ourBranchID;
  }

  public String getOurBranchName() {
    return ourBranchName;
  }

  public void setOurBranchName(String ourBranchName) {
    this.ourBranchName = ourBranchName;
  }

  public String getOurBranchAddress() {
    return ourBranchAddress;
  }

  public void setOurBranchAddress(String ourBranchAddress) {
    this.ourBranchAddress = ourBranchAddress;
  }

  public String getOurBranchCity() {
    return ourBranchCity;
  }

  public void setOurBranchCity(String ourBranchCity) {
    this.ourBranchCity = ourBranchCity;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getPhone1() {
    return phone1;
  }

  public void setPhone1(String phone1) {
    this.phone1 = phone1;
  }

  // CHECKSTYLE:ON

}
