package com.zand.communicator;

import com.zand.service.dto.AccountDetailsDto;
import com.zand.service.dto.AccountInquiryDto;
import com.zand.service.dto.AccountSummaryDto;
import com.zand.service.dto.BalanceInquiryDto;
import com.zand.service.dto.CorporateDetailsDto;
import com.zand.service.dto.TransactionListCorporateDto;
import com.zand.service.dto.TransactionsDateRangeDto;

import java.util.List;
import java.util.UUID;

/**
 * Communicator interface that defines all the external communications to be
 * done with the Core / Middleware / External Systems for Accounts.
 */
public interface AccountCommunicator {

  /**
   * This will get account balance of an account with the account nickname.
   *
   * @param accountId   the account number.
   * @param customerKey the customer identifier, cna be null
   * @return the {@link BalanceInquiryDto } response from API.
   */
  BalanceInquiryDto getBalanceWithNickname(String accountId, UUID customerKey);

  /**
   * This will get account balance of an account.
   *
   * @param accountId the account number.
   * @return the {@link BalanceInquiryDto } response from API.
   */
  BalanceInquiryDto getBalance(String accountId);

  /**
   * This will get details of all accounts.
   *
   * @param accountId the account number.
   * @param iban      iban.
   * @param mobileNo  mobile number.
   * @return the {@link AccountInquiryDto } response from API.
   */
  List<AccountInquiryDto> getAllAccounts(String accountId, String iban, String mobileNo, UUID customerKey);

  /**
   * This will get All accounts with balance.
   *
   * @param clientId the client id.
   * @return the {@link AccountSummaryDto } response from API
   */
  List<AccountSummaryDto> getAccountSummary(String clientId, UUID customerKey);

  /**
   * This will get an account with transactions.
   *
   * @param accountID   the account number.
   * @param noOfLastTrx number of transactions.
   * @param customerKey the customer key.
   * @return the {@link AccountDetailsDto } response from API
   */
  AccountDetailsDto getAccountDetailsWithTransactions(String accountID, int noOfLastTrx, UUID customerKey);

  /**
   * This will get transaction list.
   *
   * @param accountID the account number.
   * @param startDate start date of transactions and format :yyyy-mm-dd.
   * @param endDate   end date of transaction and format :yyyy-mm-dd.
   * @return the {@link TransactionListCorporateDto } response from API
   */
  List<TransactionListCorporateDto> getTransactionListCorporate(
          String accountID, String startDate, String endDate);

  /**
   * This will get corporate account detail.
   *
   * @param accountId   the account number.
   * @param iban        iban .
   * @param customerKey the customer identifier.
   * @return the {@link CorporateDetailsDto } response from API
   */
  CorporateDetailsDto getCorporateAccountDetail(String accountId, String iban, UUID customerKey);

  /**
   * This will get transaction list for a date range.
   *
   * @param accountID   account number.
   * @param fromDate    from date and format :yyyy-mm-dd (converted to offsetDateTime with
   *                    time of midnight at the start of the day, '00:00 )
   * @param toDate      to date and format :yyyy-mm-dd (converted to offsetDateTime with
   *                    the time just before midnight at the end of the day :'23:59:59.999999999')
   * @param customerKey the customer identifier.
   * @return the {@link TransactionsDateRangeDto } response from API
   */
  TransactionsDateRangeDto getTransactionsByDateRange(
          String accountID, String fromDate, String toDate, UUID customerKey);
}
