package com.zand.service.dto;

import java.util.Objects;

/**
 * corporate details dto.
 */
public class CorporateDetailsDto extends HasNicknameDto {
// CHECKSTYLE:OFF

  private String clientID;
  private String productID;
  private String name;
  private String address;
  private String countryID;
  private String stateID;
  private String cityID;
  private String statementFrequency;
  private String holdMail;
  private String zakatExemption;
  private String contactPersonName;
  private String designation;
  private String phone1;
  private String phone2;
  private String mobileNo;
  private String fax;
  private String emailID;
  private String introducerAccountNo;
  private String introducedBy;
  private String introducerAddress;
  private String introducerCityID;
  private String introducerStateID;
  private String introducerCountryID;
  private String modeOfOperation;
  private String reminder;
  private String notes;
  private String natureID;
  private String relationshipCode;
  private String allowCreditTransaction;
  private String allowDebitTransaction;
  private String notServiceCharges;
  private String notStopPaymentCharges;
  private String notChequeBookCharges;
  private String turnOver;
  private String noOfDrTrx;
  private String noOfCrTrx;
  private float drThresholdLimit;
  private float crThresholdLimit;
  private String productCash;
  private String productClearing;
  private String productCollection;
  private String productRemittance;
  private String productCross;
  private String productOthers;
  private String productOthersDesc;
  private String iban;
  private String openDate;
  private String activationDate;
  private String status;


  // Getter Methods

  public String getClientID() {
    return clientID;
  }

  public String getProductID() {
    return productID;
  }

  public String getName() {
    return name;
  }

  public String getAddress() {
    return address;
  }

  public String getCountryID() {
    return countryID;
  }

  public String getStateID() {
    return stateID;
  }

  public String getCityID() {
    return cityID;
  }

  public String getStatementFrequency() {
    return statementFrequency;
  }

  public String getHoldMail() {
    return holdMail;
  }

  public String getZakatExemption() {
    return zakatExemption;
  }

  public String getContactPersonName() {
    return contactPersonName;
  }

  public String getDesignation() {
    return designation;
  }

  public String getPhone1() {
    return phone1;
  }

  public String getPhone2() {
    return phone2;
  }

  public String getMobileNo() {
    return mobileNo;
  }

  public String getFax() {
    return fax;
  }

  public String getEmailID() {
    return emailID;
  }

  public String getIntroducerAccountNo() {
    return introducerAccountNo;
  }

  public String getIntroducedBy() {
    return introducedBy;
  }

  public String getIntroducerAddress() {
    return introducerAddress;
  }

  public String getIntroducerCityID() {
    return introducerCityID;
  }

  public String getIntroducerStateID() {
    return introducerStateID;
  }

  public String getIntroducerCountryID() {
    return introducerCountryID;
  }

  public String getModeOfOperation() {
    return modeOfOperation;
  }

  public String getReminder() {
    return reminder;
  }

  public String getNotes() {
    return notes;
  }

  public String getNatureID() {
    return natureID;
  }

  public String getRelationshipCode() {
    return relationshipCode;
  }

  public String getAllowCreditTransaction() {
    return allowCreditTransaction;
  }

  public String getAllowDebitTransaction() {
    return allowDebitTransaction;
  }

  public String getNotServiceCharges() {
    return notServiceCharges;
  }

  public String getNotStopPaymentCharges() {
    return notStopPaymentCharges;
  }

  public String getNotChequeBookCharges() {
    return notChequeBookCharges;
  }

  public String getTurnOver() {
    return turnOver;
  }

  public String getNoOfDrTrx() {
    return noOfDrTrx;
  }

  public String getNoOfCrTrx() {
    return noOfCrTrx;
  }

  public float getDrThresholdLimit() {
    return drThresholdLimit;
  }

  public float getCrThresholdLimit() {
    return crThresholdLimit;
  }

  public String getProductCash() {
    return productCash;
  }

  public String getProductClearing() {
    return productClearing;
  }

  public String getProductCollection() {
    return productCollection;
  }

  public String getProductRemittance() {
    return productRemittance;
  }

  public String getProductCross() {
    return productCross;
  }

  public String getProductOthers() {
    return productOthers;
  }

  public String getProductOthersDesc() {
    return productOthersDesc;
  }

  public String getIban() {
    return iban;
  }

  public String getOpenDate() {
    return openDate;
  }

  public String getActivationDate() {
    return activationDate;
  }

  public String getStatus() {
    return status;
  }

  // Setter Methods

  public void setClientID(String clientID) {
    this.clientID = clientID;
  }

  public void setProductID(String productID) {
    this.productID = productID;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public void setCountryID(String countryID) {
    this.countryID = countryID;
  }

  public void setStateID(String stateID) {
    this.stateID = stateID;
  }

  public void setCityID(String cityID) {
    this.cityID = cityID;
  }

  public void setStatementFrequency(String statementFrequency) {
    this.statementFrequency = statementFrequency;
  }

  public void setHoldMail(String holdMail) {
    this.holdMail = holdMail;
  }

  public void setZakatExemption(String zakatExemption) {
    this.zakatExemption = zakatExemption;
  }

  public void setContactPersonName(String contactPersonName) {
    this.contactPersonName = contactPersonName;
  }

  public void setDesignation(String designation) {
    this.designation = designation;
  }

  public void setPhone1(String phone1) {
    this.phone1 = phone1;
  }

  public void setPhone2(String phone2) {
    this.phone2 = phone2;
  }

  public void setMobileNo(String mobileNo) {
    this.mobileNo = mobileNo;
  }

  public void setFax(String fax) {
    this.fax = fax;
  }

  public void setEmailID(String emailID) {
    this.emailID = emailID;
  }

  public void setIntroducerAccountNo(String introducerAccountNo) {
    this.introducerAccountNo = introducerAccountNo;
  }

  public void setIntroducedBy(String introducedBy) {
    this.introducedBy = introducedBy;
  }

  public void setIntroducerAddress(String introducerAddress) {
    this.introducerAddress = introducerAddress;
  }

  public void setIntroducerCityID(String introducerCityID) {
    this.introducerCityID = introducerCityID;
  }

  public void setIntroducerStateID(String introducerStateID) {
    this.introducerStateID = introducerStateID;
  }

  public void setIntroducerCountryID(String introducerCountryID) {
    this.introducerCountryID = introducerCountryID;
  }

  public void setModeOfOperation(String modeOfOperation) {
    this.modeOfOperation = modeOfOperation;
  }

  public void setReminder(String reminder) {
    this.reminder = reminder;
  }

  public void setNotes(String notes) {
    this.notes = notes;
  }

  public void setNatureID(String natureID) {
    this.natureID = natureID;
  }

  public void setRelationshipCode(String relationshipCode) {
    this.relationshipCode = relationshipCode;
  }

  public void setAllowCreditTransaction(String allowCreditTransaction) {
    this.allowCreditTransaction = allowCreditTransaction;
  }

  public void setAllowDebitTransaction(String allowDebitTransaction) {
    this.allowDebitTransaction = allowDebitTransaction;
  }

  public void setNotServiceCharges(String notServiceCharges) {
    this.notServiceCharges = notServiceCharges;
  }

  public void setNotStopPaymentCharges(String notStopPaymentCharges) {
    this.notStopPaymentCharges = notStopPaymentCharges;
  }

  public void setNotChequeBookCharges(String notChequeBookCharges) {
    this.notChequeBookCharges = notChequeBookCharges;
  }

  public void setTurnOver(String turnOver) {
    this.turnOver = turnOver;
  }

  public void setNoOfDrTrx(String noOfDrTrx) {
    this.noOfDrTrx = noOfDrTrx;
  }

  public void setNoOfCrTrx(String noOfCrTrx) {
    this.noOfCrTrx = noOfCrTrx;
  }

  public void setDrThresholdLimit(float drThresholdLimit) {
    this.drThresholdLimit = drThresholdLimit;
  }

  public void setCrThresholdLimit(float crThresholdLimit) {
    this.crThresholdLimit = crThresholdLimit;
  }

  public void setProductCash(String productCash) {
    this.productCash = productCash;
  }

  public void setProductClearing(String productClearing) {
    this.productClearing = productClearing;
  }

  public void setProductCollection(String productCollection) {
    this.productCollection = productCollection;
  }

  public void setProductRemittance(String productRemittance) {
    this.productRemittance = productRemittance;
  }

  public void setProductCross(String productCross) {
    this.productCross = productCross;
  }

  public void setProductOthers(String productOthers) {
    this.productOthers = productOthers;
  }

  public void setProductOthersDesc(String productOthersDesc) {
    this.productOthersDesc = productOthersDesc;
  }

  public void setIban(String iban) {
    this.iban = iban;
  }

  public void setOpenDate(String openDate) {
    this.openDate = openDate;
  }

  public void setActivationDate(String activationDate) {
    this.activationDate = activationDate;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    CorporateDetailsDto that = (CorporateDetailsDto) o;
    return Float.compare(that.drThresholdLimit, drThresholdLimit) == 0 &&
          Float.compare(that.crThresholdLimit, crThresholdLimit) == 0 &&
          Objects.equals(clientID, that.clientID) &&
          Objects.equals(productID, that.productID) &&
          Objects.equals(name, that.name) &&
          Objects.equals(address, that.address) &&
          Objects.equals(countryID, that.countryID) &&
          Objects.equals(stateID, that.stateID) &&
          Objects.equals(cityID, that.cityID) &&
          Objects.equals(statementFrequency, that.statementFrequency) &&
          Objects.equals(holdMail, that.holdMail) &&
          Objects.equals(zakatExemption, that.zakatExemption) &&
          Objects.equals(contactPersonName, that.contactPersonName) &&
          Objects.equals(designation, that.designation) &&
          Objects.equals(phone1, that.phone1) &&
          Objects.equals(phone2, that.phone2) &&
          Objects.equals(mobileNo, that.mobileNo) &&
          Objects.equals(fax, that.fax) &&
          Objects.equals(emailID, that.emailID) &&
          Objects.equals(introducerAccountNo, that.introducerAccountNo) &&
          Objects.equals(introducedBy, that.introducedBy) &&
          Objects.equals(introducerAddress, that.introducerAddress) &&
          Objects.equals(introducerCityID, that.introducerCityID) &&
          Objects.equals(introducerStateID, that.introducerStateID) &&
          Objects.equals(introducerCountryID, that.introducerCountryID) &&
          Objects.equals(modeOfOperation, that.modeOfOperation) &&
          Objects.equals(reminder, that.reminder) &&
          Objects.equals(notes, that.notes) &&
          Objects.equals(natureID, that.natureID) &&
          Objects.equals(relationshipCode, that.relationshipCode) &&
          Objects.equals(allowCreditTransaction, that.allowCreditTransaction) &&
          Objects.equals(allowDebitTransaction, that.allowDebitTransaction) &&
          Objects.equals(notServiceCharges, that.notServiceCharges) &&
          Objects.equals(notStopPaymentCharges, that.notStopPaymentCharges) &&
          Objects.equals(notChequeBookCharges, that.notChequeBookCharges) &&
          Objects.equals(turnOver, that.turnOver) &&
          Objects.equals(noOfDrTrx, that.noOfDrTrx) &&
          Objects.equals(noOfCrTrx, that.noOfCrTrx) &&
          Objects.equals(productCash, that.productCash) &&
          Objects.equals(productClearing, that.productClearing) &&
          Objects.equals(productCollection, that.productCollection) &&
          Objects.equals(productRemittance, that.productRemittance) &&
          Objects.equals(productCross, that.productCross) &&
          Objects.equals(productOthers, that.productOthers) &&
          Objects.equals(productOthersDesc, that.productOthersDesc) &&
          Objects.equals(iban, that.iban) &&
          Objects.equals(openDate, that.openDate) &&
          Objects.equals(activationDate, that.activationDate) &&
          Objects.equals(status, that.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
            clientID, productID, name, address, countryID, stateID, cityID, statementFrequency,
            holdMail, zakatExemption, contactPersonName, designation, phone1, phone2, mobileNo,
            fax, emailID, introducerAccountNo, introducedBy, introducerAddress, introducerCityID,
            introducerStateID, introducerCountryID, modeOfOperation, reminder, notes, natureID,
            relationshipCode, allowCreditTransaction, allowDebitTransaction, notServiceCharges,
            notStopPaymentCharges, notChequeBookCharges, turnOver, noOfDrTrx, noOfCrTrx, drThresholdLimit,
            crThresholdLimit, productCash, productClearing, productCollection, productRemittance, productCross,
            productOthers, productOthersDesc, iban, openDate, activationDate, status);
  }

  @Override
  public String toString() {
    return "com.zand.account.feign.CorporateDetailsDTO{" +
            "clientID='" + clientID + '\'' +
            ", productID='" + productID + '\'' +
            ", name='" + name + '\'' +
            ", address='" + address + '\'' +
            ", countryID='" + countryID + '\'' +
            ", stateID='" + stateID + '\'' +
            ", cityID='" + cityID + '\'' +
            ", statementFrequency='" + statementFrequency + '\'' +
            ", holdMail='" + holdMail + '\'' +
            ", zakatExemption='" + zakatExemption + '\'' +
            ", contactPersonName='" + contactPersonName + '\'' +
            ", designation='" + designation + '\'' +
            ", phone1='" + phone1 + '\'' +
            ", phone2='" + phone2 + '\'' +
            ", mobileNo='" + mobileNo + '\'' +
            ", fax='" + fax + '\'' +
            ", emailID='" + emailID + '\'' +
            ", introducerAccountNo='" + introducerAccountNo + '\'' +
            ", introducedBy='" + introducedBy + '\'' +
            ", introducerAddress='" + introducerAddress + '\'' +
            ", introducerCityID='" + introducerCityID + '\'' +
            ", introducerStateID='" + introducerStateID + '\'' +
            ", introducerCountryID='" + introducerCountryID + '\'' +
            ", modeOfOperation='" + modeOfOperation + '\'' +
            ", reminder='" + reminder + '\'' +
            ", notes='" + notes + '\'' +
            ", natureID='" + natureID + '\'' +
            ", relationshipCode='" + relationshipCode + '\'' +
            ", allowCreditTransaction='" + allowCreditTransaction + '\'' +
            ", allowDebitTransaction='" + allowDebitTransaction + '\'' +
            ", notServiceCharges='" + notServiceCharges + '\'' +
            ", notStopPaymentCharges='" + notStopPaymentCharges + '\'' +
            ", notChequeBookCharges='" + notChequeBookCharges + '\'' +
            ", turnOver='" + turnOver + '\'' +
            ", noOfDrTrx='" + noOfDrTrx + '\'' +
            ", noOfCrTrx='" + noOfCrTrx + '\'' +
            ", drThresholdLimit=" + drThresholdLimit +
            ", crThresholdLimit=" + crThresholdLimit +
            ", productCash='" + productCash + '\'' +
            ", productClearing='" + productClearing + '\'' +
            ", productCollection='" + productCollection + '\'' +
            ", productRemittance='" + productRemittance + '\'' +
            ", productCross='" + productCross + '\'' +
            ", productOthers='" + productOthers + '\'' +
            ", productOthersDesc='" + productOthersDesc + '\'' +
            ", iban='" + iban + '\'' +
            ", openDate='" + openDate + '\'' +
            ", activationDate='" + activationDate + '\'' +
            ", status='" + status + '\'' +
            '}';
  }
  // CHECKSTYLE:ON
}

