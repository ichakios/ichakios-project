package com.zand.service.dto;

import java.util.Objects;

/**
 * account inquiry dto.
 */
public class AccountInquiryDto extends HasNicknameDto {
// CHECKSTYLE:OFF

  private String clientID;

  private String accountID;

  private String productID;

  private String name;

  private String iban;

  private String natureID;

  private String accountType;

  private String mobileNo;

  private String status;

  private String currencyID;

  private String openDate;

  public String getclientID() {
    return clientID;
  }

  public void setclientID(String clientID) {
    this.clientID = clientID;
  }

  public String getAccountID() {
    return accountID;
  }

  public void setAccountID(String accountID) {
    this.accountID = accountID;
  }

  public String getProductID() {
    return productID;
  }

  public void setProductID(String productID) {
    this.productID = productID;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getIban() {
    return iban;
  }

  public void setIban(String iban) {
    this.iban = iban;
  }

  public String getNatureID() {
    return natureID;
  }

  public void setNatureID(String natureID) {
    this.natureID = natureID;
  }

  public String getAccountType() {
    return accountType;
  }

  public void setAccountType(String accountType) {
    this.accountType = accountType;
  }

  public String getMobileNo() {
    return mobileNo;
  }

  public void setMobileNo(String mobileNo) {
    this.mobileNo = mobileNo;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getCurrencyID() {
    return currencyID;
  }

  public void setCurrencyID(String currencyID) {
    this.currencyID = currencyID;
  }

  public String getOpenDate() {
    return openDate;
  }

  public void setOpenDate(String openDate) {
    this.openDate = openDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    AccountInquiryDto that = (AccountInquiryDto) o;
    return Objects.equals(clientID, that.clientID) &&
            Objects.equals(accountID, that.accountID) &&
            Objects.equals(productID, that.productID) &&
            Objects.equals(name, that.name) &&
            Objects.equals(iban, that.iban) &&
            Objects.equals(natureID, that.natureID) &&
            Objects.equals(accountType, that.accountType) &&
            Objects.equals(mobileNo, that.mobileNo) &&
            Objects.equals(status, that.status) &&
            Objects.equals(currencyID, that.currencyID) &&
            Objects.equals(openDate, that.openDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(clientID, accountID, productID, name, iban,
            natureID, accountType, mobileNo, status, currencyID, openDate);
  }

  @Override
  public String toString() {
    return "com.zand.account.feign.AccountInquiryDto{" +
            "clientId='" + clientID + '\'' +
            ", accountId='" + accountID + '\'' +
            ", productID='" + productID + '\'' +
            ", name='" + name + '\'' +
            ", iban='" + iban + '\'' +
            ", natureID='" + natureID + '\'' +
            ", accountType='" + accountType + '\'' +
            ", mobileNo='" + mobileNo + '\'' +
            ", status='" + status + '\'' +
            ", currencyID='" + currencyID + '\'' +
            ", openDate='" + openDate + '\'' +
            '}';
  }
  // CHECKSTYLE:ON
}
