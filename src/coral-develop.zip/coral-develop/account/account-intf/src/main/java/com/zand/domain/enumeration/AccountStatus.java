package com.zand.domain.enumeration;

/**
 * Different Status od Account used.
 */
public enum AccountStatus {

  /**
   * account is active.
   */
  ACTIVE("Active"),

  /**
   * account is not active.
   */
  INACTIVE("InActive"),

  /**
   * account is deceased.
   */
  DECEASED("Deceased");

  /**
   * status of account.
   */
  private String status;

  /**
   * Constructor.
   */
  AccountStatus(String status) {
    this.status = status;
  }

  /**
   * getter.
   *
   * @return account status.
   */
  public String getStatus() {
    return status;
  }
}
