package com.zand.service.dto;

import java.util.Objects;

/**
 * transaction list for corporate dto.
 */
public class TransactionListCorporateDto {
// CHECKSTYLE:OFF

  private String workingDate;
  private String valueDate;
  private String trxType;
  private String productID;
  private String currencyID;
  private String chequeID;
  private String chequeDate;
  private float amount;
  private float foreignAmount;
  private float exchangeRate;
  private String descriptioID;
  private String description;

  // Getter Methods

  public String getWorkingDate() {
    return workingDate;
  }

  public String getValueDate() {
    return valueDate;
  }

  public String getTrxType() {
    return trxType;
  }

  public String getProductID() {
    return productID;
  }

  public String getCurrencyID() {
    return currencyID;
  }

  public String getChequeID() {
    return chequeID;
  }

  public String getChequeDate() {
    return chequeDate;
  }

  public float getAmount() {
    return amount;
  }

  public float getForeignAmount() {
    return foreignAmount;
  }

  public float getExchangeRate() {
    return exchangeRate;
  }

  public String getDescriptioID() {
    return descriptioID;
  }

  public String getDescription() {
    return description;
  }

  // Setter Methods

  public void setWorkingDate(String workingDate) {
    this.workingDate = workingDate;
  }

  public void setValueDate(String valueDate) {
    this.valueDate = valueDate;
  }

  public void setTrxType(String trxType) {
    this.trxType = trxType;
  }

  public void setProductID(String productID) {
    this.productID = productID;
  }

  public void setCurrencyID(String currencyID) {
    this.currencyID = currencyID;
  }

  public void setChequeID(String chequeID) {
    this.chequeID = chequeID;
  }

  public void setChequeDate(String chequeDate) {
    this.chequeDate = chequeDate;
  }

  public void setAmount(float amount) {
    this.amount = amount;
  }

  public void setForeignAmount(float foreignAmount) {
    this.foreignAmount = foreignAmount;
  }

  public void setExchangeRate(float exchangeRate) {
    this.exchangeRate = exchangeRate;
  }

  public void setDescriptioID(String descriptioID) {
    this.descriptioID = descriptioID;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    TransactionListCorporateDto that = (TransactionListCorporateDto) o;
    return Float.compare(that.amount, amount) == 0 &&
            Float.compare(that.foreignAmount, foreignAmount) == 0 &&
            Float.compare(that.exchangeRate, exchangeRate) == 0 &&
            Objects.equals(workingDate, that.workingDate) &&
            Objects.equals(valueDate, that.valueDate) &&
            Objects.equals(trxType, that.trxType) &&
            Objects.equals(productID, that.productID) &&
            Objects.equals(currencyID, that.currencyID) &&
            Objects.equals(chequeID, that.chequeID) &&
            Objects.equals(chequeDate, that.chequeDate) &&
            Objects.equals(descriptioID, that.descriptioID) &&
            Objects.equals(description, that.description);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
            workingDate, valueDate, trxType, productID, currencyID, chequeID, chequeDate, amount,
            foreignAmount, exchangeRate, descriptioID, description);
  }

  @Override
  public String toString() {
    return "com.zand.account.feign.TransactionListCorporateDTO{" +
            "workingDate='" + workingDate + '\'' +
            ", valueDate='" + valueDate + '\'' +
            ", trxType='" + trxType + '\'' +
            ", productID='" + productID + '\'' +
            ", currencyID='" + currencyID + '\'' +
            ", chequeID='" + chequeID + '\'' +
            ", chequeDate='" + chequeDate + '\'' +
            ", amount=" + amount +
            ", foreignAmount=" + foreignAmount +
            ", exchangeRate=" + exchangeRate +
            ", descriptioID='" + descriptioID + '\'' +
            ", description='" + description + '\'' +
            '}';
  }
  // CHECKSTYLE:ON
}

