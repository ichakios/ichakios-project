package com.zand.service.validate;

import com.zand.service.dto.StatementDto;

/**
 * statement response.
 */
public class StatementResponse {

  /**
   * log id  for request.
   */
  private String logId;

  /**
   * date and time for request.
   */
  private String requestDateTime;

  /**
   * status request.
   */
  private Status status;

  /**
   * content.
   */
  private StatementDto content = null;

  /**
   * getter.
   *
   * @return current requestDateTime.
   */
  public String getRequestDateTime() {
    return requestDateTime;
  }

  /**
   * setter.
   *
   * @param requestDateTime requestDateTime  to set.
   */
  public void setRequestDateTime(String requestDateTime) {
    this.requestDateTime = requestDateTime;
  }

  /**
   * getter.
   *
   * @return current logId.
   */
  public String getLogId() {
    return logId;
  }

  /**
   * setter.
   *
   * @param logId logId  to set.
   */
  public void setLogId(String logId) {
    this.logId = logId;
  }

  /**
   * getter.
   *
   * @return current status.
   */
  public Status getStatus() {
    return status;
  }

  /**
   * setter.
   *
   * @param status status  to set.
   */
  public void setStatus(Status status) {
    this.status = status;
  }

  /**
   * getter.
   *
   * @return current content.
   */
  public StatementDto getContent() {
    return content;
  }

  /**
   * setter.
   *
   * @param content content  to set.
   */
  public void setContent(StatementDto content) {
    this.content = content;
  }
}

