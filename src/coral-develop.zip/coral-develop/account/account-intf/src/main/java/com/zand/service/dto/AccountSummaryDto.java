package com.zand.service.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * account summary dto.
 */
public class AccountSummaryDto extends HasNicknameDto implements Serializable {
// CHECKSTYLE:OFF

  private Long id;

  private BigDecimal totalBalance;

  private BigDecimal availableBalance;

  private BigDecimal drawableBalance;

  private String accountId;

  private String productID;

  private String name;

  private String currencyID;

  private String status;

  private String clientID;

  private String iban;

  private String openDate;

  private String productType;

  private String productDesc;

  private String groupCode;

  private String econoActCode;

  private String countryCode;

  private String accountType;

  private String debitFrozen;

  private String creditFrozen;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public BigDecimal getTotalBalance() {
    return totalBalance;
  }

  public void setTotalBalance(BigDecimal totalBalance) {
    this.totalBalance = totalBalance;
  }

  public BigDecimal getAvailableBalance() {
    return availableBalance;
  }

  public void setAvailableBalance(BigDecimal availableBalance) {
    this.availableBalance = availableBalance;
  }

  public BigDecimal getDrawableBalance() {
    return drawableBalance;
  }

  public void setDrawableBalance(BigDecimal drawableBalance) {
    this.drawableBalance = drawableBalance;
  }

  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public String getProductID() {
    return productID;
  }

  public void setProductID(String productID) {
    this.productID = productID;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCurrencyID() {
    return currencyID;
  }

  public void setCurrencyID(String currencyID) {
    this.currencyID = currencyID;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getClientID() {
    return clientID;
  }

  public void setClientID(String clientID) {
    this.clientID = clientID;
  }

  public String getIban() {
    return iban;
  }

  public void setIban(String iban) {
    this.iban = iban;
  }

  public String getOpenDate() {
    return openDate;
  }

  public void setOpenDate(String openDate) {
    this.openDate = openDate;
  }

  public String getProductType() {
    return productType;
  }

  public void setProductType(String productType) {
    this.productType = productType;
  }

  public String getProductDesc() {
    return productDesc;
  }

  public void setProductDesc(String productDesc) {
    this.productDesc = productDesc;
  }

  public String getGroupCode() {
    return groupCode;
  }

  public void setGroupCode(String groupCode) {
    this.groupCode = groupCode;
  }

  public String getEconoActCode() {
    return econoActCode;
  }

  public void setEconoActCode(String econoActCode) {
    this.econoActCode = econoActCode;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getAccountType() {
    return accountType;
  }

  public void setAccountType(String accountType) {
    this.accountType = accountType;
  }

  public String getDebitFrozen() {
    return debitFrozen;
  }

  public void setDebitFrozen(String debitFrozen) {
    this.debitFrozen = debitFrozen;
  }

  public String getCreditFrozen() {
    return creditFrozen;
  }

  public void setCreditFrozen(String creditFrozen) {
    this.creditFrozen = creditFrozen;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }

    AccountSummaryDto accountSummaryDTO = (AccountSummaryDto) o;
    if (accountSummaryDTO.getId() == null || getId() == null) {
      return false;
    }
    return Objects.equals(getId(), accountSummaryDTO.getId());
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(getId());
  }

  @Override
  public String toString() {
    return "AccountSummaryDTO{" +
            "id=" + id +
            ", totalBalance=" + totalBalance +
            ", availableBalance=" + availableBalance +
            ", drawableBalance=" + drawableBalance +
            ", accountId='" + accountId + '\'' +
            ", productID='" + productID + '\'' +
            ", name='" + name + '\'' +
            ", currencyID='" + currencyID + '\'' +
            ", status='" + status + '\'' +
            ", clientID='" + clientID + '\'' +
            ", iban='" + iban + '\'' +
            ", openDate='" + openDate + '\'' +
            ", productType='" + productType + '\'' +
            ", productDesc='" + productDesc + '\'' +
            ", groupCode='" + groupCode + '\'' +
            ", econoActCode='" + econoActCode + '\'' +
            ", countryCode='" + countryCode + '\'' +
            ", accountType='" + accountType + '\'' +
            ", debitFrozen='" + debitFrozen + '\'' +
            ", creditFrozen='" + creditFrozen + '\'' +
            '}';
  }
  // CHECKSTYLE:ON
}
