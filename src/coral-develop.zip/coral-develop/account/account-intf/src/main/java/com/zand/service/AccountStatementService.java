package com.zand.service;

import com.zand.service.dto.StatementDto;
import java.util.UUID;

/**
 * The interface to interact with the account statement feature.
 */
public interface AccountStatementService {

  /**
   * This will get the monthly statement for account.
   *
   * @param accountID account number.
   * @param fromDate  from date and format :yyyy-MM-dd.
   * @param customerKey the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         monthly statements in body.
   */
  StatementDto getMonthlyStatements(String accountID, String fromDate, UUID customerKey);

  /**
   * This will get the statement for account for a date range.
   *
   * @param accountID account number.
   * @param fromDate  from date and format :yyyy-MM-dd.
   * @param toDate    to date and format :yyyy-MM-dd.
   * @param customerKey the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         statement for account for a date range.
   */
  StatementDto getStatementsByDateRange(
          String accountID, String fromDate, String toDate, UUID customerKey);

  /**
   * This will get the debit advice.
   *
   * @param workingDate working date and format :yyyy-MM-dd'T'HH:mm:ss'Z'.
   * @param trxRefNo    transaction reference number.
   * @param customerKey the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         debit advice.
   */
  StatementDto getDebitAdvice(
          String workingDate, Double trxRefNo, UUID customerKey);

  /**
   * This will get the Credit advice.
   *
   * @param workingDate working date and format :yyyy-MM-dd'T'HH:mm:ss'Z'.
   * @param trxRefNo    transaction reference number.
   * @param customerKey the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         credit advice.
   */
  StatementDto getCreditAdvice(
          String workingDate, Double trxRefNo, UUID customerKey);

  /**
   * This will get the Vat advice.
   *
   * @param workingDate working date and format :yyyy-MM-dd'T'HH:mm:ss'Z'.
   * @param trxRefNo    transaction reference number.
   * @param customerKey the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         vat advice.
   */
  StatementDto getVatAdvice(
          String workingDate, Double trxRefNo, UUID customerKey);


  /**
   * This will get the monthly vat advice.
   *
   * @param accountID account number.
   * @param fromDate  from date and format :yyyy-MM-dd.
   * @param customerKey the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         monthly vat advice.
   */
  StatementDto getMonthlyVatAdvice(
          String accountID, String fromDate, UUID customerKey);
}


