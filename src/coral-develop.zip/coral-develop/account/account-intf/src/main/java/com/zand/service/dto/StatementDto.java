package com.zand.service.dto;

/**
 * monthly statement dto.
 */
public class StatementDto extends HasNicknameDto {

  /**
   * pdf file name.
   */
  private String pdfFileName;

  /**
   * pdf string.
   */
  private String pdfBase64String;

  // CHECKSTYLE:OFF
  public String getPdfFileName() {
    return pdfFileName;
  }

  public void setPdfFileName(String pdfFileName) {
    this.pdfFileName = pdfFileName;
  }

  public String getPdfBase64String() {
    return pdfBase64String;
  }

  public void setPdfBase64String(String pdfBase64String) {
    this.pdfBase64String = pdfBase64String;
  }
  // CHECKSTYLE:ON
}


