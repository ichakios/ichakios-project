package com.zand.web.rest;

import com.zand.service.dto.AccountDetailsDto;
import com.zand.service.dto.AccountInquiryDto;
import com.zand.service.dto.AccountSummaryDto;
import com.zand.service.dto.BalanceInquiryDto;
import com.zand.service.dto.CorporateDetailsDto;
import com.zand.service.dto.TransactionListCorporateDto;
import com.zand.service.dto.TransactionsDateRangeDto;
import java.util.List;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * REST controller for managing the current account.
 */
@RequestMapping("/api/v1")
public interface AccountSummaryResource {

  /**
   * {@code GET  /accounts} : Get All accounts with balance.
   *
   * @param id the client id.
   * @return the account summary.
   */
  @GetMapping("/accounts")
  List<AccountSummaryDto> getAccountSummary(@RequestParam String id, @RequestParam UUID customer);

  /**
   * This endpoint allows to update account metadata that are stored on our side.
   * @param account The account we'll save metadata of
   * @return the account (unchanged)
   */
  @PutMapping("/accounts")
  ResponseEntity<Void> saveAccountMetadata(
          @RequestBody AccountSummaryDto account, @RequestParam UUID customer);

  /**
   * This endpoint allows to delete account nickname that is stored on our side.
   * @param accountId The account id we'll delete the nickname of
   */
  @DeleteMapping("/accounts/{id}/nickname")
  ResponseEntity<Void> deleteAccountNickname(
          @PathVariable("id") String accountId, @RequestParam UUID customer);

  /**
   * {@code GET  /accounts/transactions} :  Get an account with transactions.
   *
   * @param accountID   the account number.
   * @param noOfLastTrx number of transactions.
   * @param customer the customer key.
   * @return the accounts with transactions
   */
  @GetMapping("/accounts/transactions")
  AccountDetailsDto getAccountDetailsWithTransactions(
      @RequestParam String accountID, @RequestParam int noOfLastTrx, @RequestParam UUID customer);

  /**
   * {@code GET  /accounts/balance} :  Get account balance of an account.
   *
   * @param accountId the account number.
   * @param customer the customer key.
   * @return the balance of account
   */
  @GetMapping("/accounts/balance")
  BalanceInquiryDto getBalance(@RequestParam String accountId, @RequestParam UUID customer);

  /**
   * {@code GET  /accounts/transaction-list"} :  Get transaction list for date range.
   *
   * @param accountID the account number.
   * @param startDate start date of transactions and format :yyyy-mm-dd.
   * @param endDate   end date of transaction and format :yyyy-mm-dd.
   * @return the list of transaction for corporate.
   */
  @GetMapping("/accounts/transaction-list")
  List<TransactionListCorporateDto> getTransactionListCorporate(
      @RequestParam String accountID, @RequestParam String startDate,
      @RequestParam String endDate);

  /**
   * {@code GET  accounts/details} : Get corporate account detail.
   *
   * @param accountId the account number.
   * @param iban      iban .
   * @param customer the customer key.
   * @return the corporate account details.
   */
  @GetMapping("/accounts/details")
  CorporateDetailsDto getCorporateAccountDetail(
      @RequestParam String accountId, @RequestParam String iban, @RequestParam UUID customer);

  /**
   * {@code GET  /accounts/account-list} : Get details of all accounts.
   *
   * @param accountId the account number.
   * @param iban      iban.
   * @param mobileNo  mobile number.
   * @return the details of all accounts.
   */
  @GetMapping("/accounts/account-list")
  List<AccountInquiryDto> getAllAccounts(
      @RequestParam String accountId, @RequestParam String iban, @RequestParam String mobileNo,
      @RequestParam UUID customer);

  /**
   * {@code POST /accounts/transactions/date-range} : get transactions for a date range.
   *
   * @param accountID  account number.
   * @param fromDate   from date and format :yyyy-mm-dd
   * @param toDate     to date and format :yyyy-mm-dd
   * @param customer     the customer identifier
   * @return the transaction list.
   */
  @GetMapping("/accounts/transactions/date-range")
  TransactionsDateRangeDto getTransactionsByDateRange(
      String accountID, String fromDate, String toDate, @RequestParam UUID customer);
}
