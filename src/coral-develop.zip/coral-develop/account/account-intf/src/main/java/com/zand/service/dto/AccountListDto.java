package com.zand.service.dto;

import java.util.Objects;

// CHECKSTYLE:OFF
/**
 * account list dto.
 */
public class AccountListDto extends HasNicknameDto {

  private String accountID;

  private String accountName;

  private String clientID;

  private String productName;

  private String currencyID;

  private String currencyName;

  private String address;

  public String getAccountID() {
    return accountID;
  }

  public void setAccountID(String accountID) {
    this.accountID = accountID;
  }

  public String getAccountName() {
    return accountName;
  }

  public void setAccountName(String accountName) {
    this.accountName = accountName;
  }

  public String getClientID() {
    return clientID;
  }

  public void setClientID(String clientID) {
    this.clientID = clientID;
  }

  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public String getCurrencyID() {
    return currencyID;
  }

  public void setCurrencyID(String currencyID) {
    this.currencyID = currencyID;
  }

  public String getCurrencyName() {
    return currencyName;
  }

  public void setCurrencyName(String currencyName) {
    this.currencyName = currencyName;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    AccountListDto that = (AccountListDto) o;
    return Objects.equals(accountID, that.accountID) &&
            Objects.equals(accountName, that.accountName) &&
            Objects.equals(clientID, that.clientID) &&
            Objects.equals(productName, that.productName) &&
            Objects.equals(currencyID, that.currencyID) &&
            Objects.equals(currencyName, that.currencyName) &&
            Objects.equals(address, that.address);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accountID, accountName, clientID, productName, currencyID, currencyName, address);
  }
}
