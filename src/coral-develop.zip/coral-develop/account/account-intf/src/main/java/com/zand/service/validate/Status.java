package com.zand.service.validate;

/**
 * Status for response.
 */
public class Status {

  /**
   * Status code for response.
   */
  private String code;

  /**
   * Status severity for response.
   */
  private String severity;

  /**
   * Status message for response.
   */
  private String statusMessage;

  /**
   * getter.
   *
   * @return current status Code.
   */
  public String getCode() {
    return code;
  }

  /**
   * setter.
   *
   * @param code status code to set.
   */
  public void setCode(String code) {
    this.code = code;
  }

  /**
   * getter.
   *
   * @return current severity.
   */
  public String getSeverity() {
    return severity;
  }

  /**
   * setter.
   *
   * @param severity severity to set.
   */
  public void setSeverity(String severity) {
    this.severity = severity;
  }

  /**
   * getter.
   *
   * @return current status message.
   */
  public String getStatusMessage() {
    return statusMessage;
  }

  /**
   * setter.
   *
   * @param statusMessage status Message to set.
   */
  public void setStatusMessage(String statusMessage) {
    this.statusMessage = statusMessage;
  }

}
