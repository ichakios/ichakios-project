package com.zand.web.rest;

import com.zand.service.dto.StatementDto;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * REST controller for managing the current account.
 */
@RequestMapping("api/v1/accounts/statements")
public interface AccountStatementResource {

  /**
   * This REST endpoint will get the monthly statement for account.
   *
   * <p>{@code POST  /accounts/statements/monthly} : get the monthly statement for account.
   *
   * @param accountID account number.
   * @param fromDate  from date and format :yyyy-MM-dd.
   * @param customer  the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         monthly statements in body.
   */
  @PostMapping("/monthly")
  ResponseEntity<StatementDto> getMonthlyStatements(
          @RequestParam String accountID, @RequestParam String fromDate, @RequestParam UUID customer);

  /**
   * This REST endpoint will get the statement for account for a date range.
   *
   * <p>{@code POST  /accounts/statements} : get the statement for account for a date range.
   *
   * @param accountID account number.
   * @param fromDate  from date and format :yyyy-MM-dd.
   * @param toDate    to date and format :yyyy-MM-dd.
   * @param customer  the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         statement for account for a date range.
   */
  @PostMapping("/date-range")
  ResponseEntity<StatementDto> getStatementsByDateRange(
          @RequestParam String accountID, @RequestParam String fromDate, @RequestParam String toDate,
          @RequestParam UUID customer);

  /**
   * This REST endpoint will get the debit advice.
   *
   * <p>{@code POST  /accounts/statements/debit-advice"} : will get the debit advice.
   *
   * @param workingDate working date and format :yyyy-MM-dd'T'HH:mm:ss'Z'.
   * @param trxRefNo    transaction reference number.
   * @param customer  the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         debit advice.
   */
  @PostMapping("/debit-advice")
  ResponseEntity<StatementDto> getDebitAdvice(
          @RequestParam String workingDate, @RequestParam Double trxRefNo, @RequestParam UUID customer);


  /**
   * This REST endpoint will get the Credit advice.
   *
   * <p>{@code POST  /accounts/statements/credit-advice} : will get the Credit advice.
   *
   * @param workingDate working date and format :yyyy-MM-dd'T'HH:mm:ss'Z'.
   * @param trxRefNo    transaction reference number.
   * @param customer  the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         credit advice.
   */
  @PostMapping("/credit-advice")
  ResponseEntity<StatementDto> getCreditAdvice(
          @RequestParam String workingDate, @RequestParam Double trxRefNo, @RequestParam UUID customer);

  /**
   * This REST endpoint will get the vat advice.
   *
   * <p>{@code POST  /accounts/statements/vat-advice} : will get the Vat advice.
   *
   * @param workingDate working date and format :yyyy-MM-dd'T'HH:mm:ss'Z'.
   * @param trxRefNo    transaction reference number.
   * @param customer  the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         vat advice.
   */
  @PostMapping("/vat-advice")
  ResponseEntity<StatementDto> getVatAdvice(
          @RequestParam String workingDate, @RequestParam Double trxRefNo, @RequestParam UUID customer);

  /**
   * This REST endpoint will get the monthly vat advice.
   *
   * <p>{@code POST  /accounts/statements/vat-advice/monthly} : will get the monthly vat advice.
   *
   * @param accountID account number.
   * @param fromDate  from date and format :yyyy-MM-dd.
   * @param customer  the customer identifier.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the
   *         monthly vat advice.
   */
  @PostMapping("/vat-advice/monthly")
  ResponseEntity<StatementDto> getMonthlyVatAdvice(
          @RequestParam String accountID, @RequestParam String fromDate, @RequestParam UUID customer);

}
