package com.zand.request;

import com.zand.service.validate.SignOnRq;

import java.util.Objects;

/**
 * sign on request for corporate account details.
 */
public class SignOnRqForCorporateAccountDetails {

  /**
   * sign on request.
   */
  private SignOnRq signOnRq;

  /**
   * account id.
   */
  private String accountId;

  /**
   * iban.
   */
  private String iban;

  /**
   * getter.
   *
   * @return current signOnRq.
   */
  public SignOnRq getSignOnRq() {
    return signOnRq;
  }

  /**
   * setter.
   *
   * @param signOnRq signOnRq  to set.
   */
  public void setSignOnRq(SignOnRq signOnRq) {
    this.signOnRq = signOnRq;
  }

  /**
   * getter.
   *
   * @return current accountId.
   */
  public String getAccountId() {
    return accountId;
  }

  /**
   * setter.
   *
   * @param accountId accountId  to set.
   */
  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  /**
   * getter.
   *
   * @return current iban.
   */
  public String getiban() {
    return iban;
  }

  /**
   * setter.
   *
   * @param iban iban to set.
   */
  public void setiban(String iban) {
    this.iban = iban;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SignOnRqForCorporateAccountDetails that = (SignOnRqForCorporateAccountDetails) o;
    return Objects.equals(signOnRq, that.signOnRq)
            && Objects.equals(accountId, that.accountId)
            && Objects.equals(iban, that.iban);
  }

  @Override
  public int hashCode() {
    return Objects.hash(signOnRq, accountId, iban);
  }

  @Override
  public String toString() {
    return "com.zand.account.feign.SignOnRqForCorporateAccountDetails{"
            + "signOnRq=" + signOnRq
            + ", accountId='" + accountId + '\''
            + ", iban='" + iban + '\''
            +
            '}';
  }
}
