package com.zand.request;

import com.zand.service.validate.SignOnRq;

/**
 * sign on request for transaction list for corporate.
 */
public class SignOnRqForTransactionListCorporate {

  /**
   * sign on request.
   */
  private SignOnRq signOnRq;

  /**
   * start date.
   */
  private String startDate;

  /**
   * end date.
   */
  private String endDate;

  /**
   * account id.
   */
  private String accountID;

  /**
   * getter.
   *
   * @return current signOnRq.
   */
  public SignOnRq getSignOnRq() {
    return signOnRq;
  }

  /**
   * setter.
   *
   * @param signOnRq signOnRq  to set.
   */
  public void setSignOnRq(SignOnRq signOnRq) {
    this.signOnRq = signOnRq;
  }

  /**
   * getter.
   *
   * @return current startDate.
   */
  public String getStartDate() {
    return startDate;
  }

  /**
   * setter.
   *
   * @param startDate start date  to set.
   */
  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  /**
   * getter.
   *
   * @return current endDate.
   */
  public String getEndDate() {
    return endDate;
  }

  /**
   * setter.
   *
   * @param endDate end date to set.
   */
  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  /**
   * getter.
   *
   * @return current accountID.
   */
  public String getAccountID() {
    return accountID;
  }

  /**
   * setter.
   *
   * @param accountID account id to set.
   */
  public void setAccountID(String accountID) {
    this.accountID = accountID;
  }
}
