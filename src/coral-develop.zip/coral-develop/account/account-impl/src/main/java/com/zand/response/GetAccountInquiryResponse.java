package com.zand.response;

import com.zand.service.dto.AccountInquiryDto;
import com.zand.service.validate.Status;

import java.util.List;

/**
 * response for account inquiry.
 */
public class GetAccountInquiryResponse {
  /**
   * log id  for request.
   */
  private String logId;

  /**
   * date and time for request.
   */
  private String requestDateTime;

  /**
   * status request.
   */
  private Status status;

  /**
   * content.
   */
  private List<AccountInquiryDto> content = null;

  /**
   * getter.
   *
   * @return current requestDateTime.
   */
  public String getRequestDateTime() {
    return requestDateTime;
  }

  /**
   * setter.
   *
   * @param requestDateTime requestDateTime  to set.
   */
  public void setRequestDateTime(String requestDateTime) {
    this.requestDateTime = requestDateTime;
  }

  /**
   * getter.
   *
   * @return current logId.
   */
  public String getLogId() {
    return logId;
  }

  /**
   * setter.
   *
   * @param logId logId  to set.
   */
  public void setLogId(String logId) {
    this.logId = logId;
  }

  /**
   * getter.
   *
   * @return current status.
   */
  public Status getStatus() {
    return status;
  }

  /**
   * setter.
   *
   * @param status status  to set.
   */
  public void setStatus(Status status) {
    this.status = status;
  }

  /**
   * getter.
   *
   * @return current content.
   */
  public List<AccountInquiryDto> getContent() {
    return content;
  }

  /**
   * setter.
   *
   * @param content content  to set.
   */
  public void setContent(List<AccountInquiryDto> content) {
    this.content = content;
  }
}
