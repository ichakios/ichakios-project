package com.zand.client;

import com.zand.request.SignOnRequestStatement;
import com.zand.service.validate.StatementResponse;
import feign.Headers;
import feign.RequestLine;

/**
 * Interface for account statement client for connecting to WAQFE via feign.
 */
public interface AccountStatementClient {

  /**
   * To get monthly statement.
   */
  @RequestLine("POST /api/DigibancStatement/MonthlyStatement")
  @Headers("Content-Type: application/json")
  StatementResponse getMonthlyStatements(SignOnRequestStatement signOnRequestStatement);

  /**
   * To get statement for a date range.
   */
  @RequestLine("POST /api/DigibancStatement/CustStatDateWise")
  @Headers("Content-Type: application/json")
  StatementResponse geStatementByDateRange(SignOnRequestStatement signOnRequestStatement);

  /**
   * To get statement for a debit advice.
   */
  @RequestLine("POST /api/DigibancStatement/DebitAdvice")
  @Headers("Content-Type: application/json")
  StatementResponse getDebitAdvice(SignOnRequestStatement signOnRequestStatement);

  /**
   * To get statement for a credit advice.
   */
  @RequestLine("POST /api/DigibancStatement/CreditAdvice")
  @Headers("Content-Type: application/json")
  StatementResponse getCreditAdvice(SignOnRequestStatement signOnRequestStatement);

  /**
   * To get statement for a vat advice.
   */
  @RequestLine("POST /api/DigibancStatement/VatAdvice")
  @Headers("Content-Type: application/json")
  StatementResponse getVatAdvice(SignOnRequestStatement signOnRequestStatement);

  /**
   * To get statement for monthly vat advice.
   */
  @RequestLine("POST /api/DigibancStatement/MonthlyVATAdvice")
  @Headers("Content-Type: application/json")
  StatementResponse getMonthlyVatAdvice(SignOnRequestStatement signOnRequestStatement);

}
