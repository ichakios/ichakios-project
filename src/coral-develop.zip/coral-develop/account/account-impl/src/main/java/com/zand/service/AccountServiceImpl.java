package com.zand.service;

import com.zand.domain.enumeration.EntityType;
import com.zand.service.dto.AccountSummaryDto;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * A service that will handle account operations.
 */
@Service
public class AccountServiceImpl implements AccountService {

  /**
   * Logger to log.
   */
  private static final Logger log = LoggerFactory.getLogger(AccountServiceImpl.class);

  /**
   * NickName Service.
   */
  private final NicknameService nicknameService;

  /**
   * Constructor.
   *
   * @param nicknameService to save nickname metadata.
   */
  public AccountServiceImpl(NicknameService nicknameService) {
    this.nicknameService = nicknameService;
  }

  @Override
  public void saveAccountMetadata(AccountSummaryDto account, UUID customerKey) {
    log.debug("Entered in saveAccountMetadata with {} {}", account, customerKey);
    nicknameService.save(account, customerKey);
  }

  @Override
  public void deleteAccountNickname(String accountId, UUID customerKey) {
    nicknameService.deleteNicknameByEntityId(accountId, EntityType.ACCOUNT, customerKey);
  }
}
