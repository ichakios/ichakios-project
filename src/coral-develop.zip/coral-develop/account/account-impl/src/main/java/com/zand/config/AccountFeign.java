package com.zand.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zand.client.AccountClient;
import com.zand.serialization.JacksonUtil;
import org.springframework.stereotype.Component;

/**
 * configuration class for Feign client.
 */
@Component
public class AccountFeign {

  /**
   * get the custom object mapper.
   */
  private final ObjectMapper mapper = JacksonUtil.getObjectMapper();

  /**
   * feign configuration.
   */
  public AccountClient getFeignClient() {
    return ZandClientBuilder.get().target(AccountClient.class, MiddlewareConstants.URL);
  }
}
