package com.zand.request;

import com.zand.service.validate.SignOnRq;

/**
 * sign on request with client id.
 */
public class SignOnRqWithClientId {

  /**
   * sign on request.
   */
  private SignOnRq signOnRq;

  /**
   * client id.
   */
  private String clientID;

  /**
   * getter.
   *
   * @return current signOnRq.
   */
  public SignOnRq getSignOnRq() {
    return signOnRq;
  }

  /**
   * setter.
   *
   * @param signOnRq signOnRq  to set.
   */
  public void setSignOnRq(SignOnRq signOnRq) {
    this.signOnRq = signOnRq;
  }

  /**
   * getter.
   *
   * @return current clientID.
   */
  public String getClientID() {
    return clientID;
  }

  /**
   * setter.
   *
   * @param clientID client id  to set.
   */
  public void setClientID(String clientID) {
    this.clientID = clientID;
  }

}
