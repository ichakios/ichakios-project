package com.zand.request;

import com.zand.service.validate.SignOnRq;

/**
 * sign on request for monthly statement.
 */
public class SignOnRequestStatement {

  /**
   * sign on request.
   */
  private SignOnRq signOnRq;

  /**
   * data for request.
   */
  private Data data;

  /**
   * getter.
   *
   * @return current data.
   */
  public Data getData() {
    return data;
  }

  /**
   * setter.
   *
   * @param data data to set.
   */
  public void setData(Data data) {
    this.data = data;
  }

  /**
   * getter.
   *
   * @return current signOnRq.
   */
  public SignOnRq getSignOnRq() {
    return signOnRq;
  }

  /**
   * setter.
   *
   * @param signOnRq signOnRq to set.
   */
  public void setSignOnRq(SignOnRq signOnRq) {
    this.signOnRq = signOnRq;
  }

}
