package com.zand.request;

import com.zand.service.validate.SignOnRq;

/**
 * sign on request for balance for account.
 */
public class SignOnRqForBalance {

  /**
   * sign on request.
   */
  private SignOnRq signOnRq;

  /**
   * account id.
   */
  private String accountId;

  /**
   * getter.
   *
   * @return current signOnRq.
   */
  public SignOnRq getSignOnRq() {
    return signOnRq;
  }

  /**
   * setter.
   *
   * @param signOnRq signOnRq  to set.
   */
  public void setSignOnRq(SignOnRq signOnRq) {
    this.signOnRq = signOnRq;
  }

  /**
   * getter.
   *
   * @return current accountId.
   */
  public String getAccountId() {
    return accountId;
  }

  /**
   * setter.
   *
   * @param accountId signOnRq  to set.
   */
  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }
}
