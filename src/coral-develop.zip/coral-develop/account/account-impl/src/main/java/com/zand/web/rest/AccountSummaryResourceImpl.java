package com.zand.web.rest;

import com.zand.Feature;
import com.zand.Permission;
import com.zand.communicator.AccountCommunicator;
import com.zand.request.CommonRequest;
import com.zand.request.SignOnRqForBalance;
import com.zand.service.AccountService;
import com.zand.service.dto.AccountDetailsDto;
import com.zand.service.dto.AccountInquiryDto;
import com.zand.service.dto.AccountSummaryDto;
import com.zand.service.dto.BalanceInquiryDto;
import com.zand.service.dto.CorporateDetailsDto;
import com.zand.service.dto.TransactionListCorporateDto;
import com.zand.service.dto.TransactionsDateRangeDto;
import com.zand.spring.HasAccess;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

/**
 * REST controller for managing the current account.
 */
@Transactional
@RestController
public class AccountSummaryResourceImpl implements AccountSummaryResource {

  /**
   * account communicator.
   */
  private final AccountCommunicator communicator;

  /**
   * account service.
   */
  private final AccountService accountService;

  /**
   * constructor.
   *
   * @param communicator to connect to middleware.
   */
  AccountSummaryResourceImpl(AccountCommunicator communicator, AccountService accountService) {
    this.communicator = communicator;
    this.accountService = accountService;
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public List<AccountSummaryDto> getAccountSummary(
          @RequestParam String id, @RequestParam UUID customer) {
    return communicator.getAccountSummary(id, customer);
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.WRITE)
  public ResponseEntity<Void> saveAccountMetadata(
          @RequestBody AccountSummaryDto account, @RequestParam UUID customer) {
    accountService.saveAccountMetadata(account, customer);
    return ResponseEntity.ok().build();
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.WRITE)
  public ResponseEntity<Void> deleteAccountNickname(
          @PathVariable("id") String accountId, @RequestParam UUID customer) {
    accountService.deleteAccountNickname(accountId, customer);
    return ResponseEntity.ok().build();
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public AccountDetailsDto getAccountDetailsWithTransactions(
          @RequestParam String accountID, @RequestParam int noOfLastTrx, @RequestParam UUID customer) {
    return communicator.getAccountDetailsWithTransactions(accountID, noOfLastTrx, customer);
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public BalanceInquiryDto getBalance(
          @RequestParam String accountId, @RequestParam UUID customer) {
    SignOnRqForBalance signOnRqForBalance = new SignOnRqForBalance();
    signOnRqForBalance.setSignOnRq(CommonRequest.getCommonSignOnRq());
    signOnRqForBalance.setAccountId(accountId);
    return communicator.getBalanceWithNickname(accountId, customer);
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public List<TransactionListCorporateDto> getTransactionListCorporate(
          @RequestParam String accountID, @RequestParam String startDate,
          @RequestParam String endDate) {
    return communicator.getTransactionListCorporate(accountID, startDate, endDate);
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public CorporateDetailsDto getCorporateAccountDetail(
          @RequestParam String accountId, @RequestParam String iban, @RequestParam UUID customer) {
    return communicator.getCorporateAccountDetail(accountId, iban, customer);
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public List<AccountInquiryDto> getAllAccounts(
          @RequestParam String accountId, @RequestParam String iban, @RequestParam String mobileNo,
          @RequestParam UUID customer) {
    return communicator.getAllAccounts(accountId, iban, mobileNo, customer);
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public TransactionsDateRangeDto getTransactionsByDateRange(
          String accountID, String fromDate, String toDate, UUID customer) {
    return communicator.getTransactionsByDateRange(
            accountID, fromDate, toDate, customer);
  }
}
