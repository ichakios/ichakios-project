package com.zand.service.statement;

import com.zand.client.AccountStatementClient;
import com.zand.config.MiddlewareConstants;
import com.zand.config.ZandClientBuilder;
import org.springframework.stereotype.Component;

/**
 * to get the feign client for statement.
 */
@Component
public class StatementFeign {

  /**
   * to get the feign client for statement.
   *
   * @return client for statement.
   */
  public AccountStatementClient getClient() {
    return ZandClientBuilder.get().target(AccountStatementClient.class, MiddlewareConstants.URL);
  }
}
