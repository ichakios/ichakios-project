package com.zand.communicator;

import com.zand.config.AccountFeign;
import com.zand.config.MiddlewareConstants;
import com.zand.request.CommonRequest;
import com.zand.request.Data;
import com.zand.request.SignOnRequestForAccount;
import com.zand.request.SignOnRequestTransactionDateRange;
import com.zand.request.SignOnRequestWithAccountIdAndTrxNo;
import com.zand.request.SignOnRqForBalance;
import com.zand.request.SignOnRqForCorporateAccountDetails;
import com.zand.request.SignOnRqForTransactionListCorporate;
import com.zand.request.SignOnRqWithClientId;
import com.zand.response.GetAccountInquiryResponse;
import com.zand.response.GetBalanceInquiryResponse;
import com.zand.response.GetCifAccountsBalanceInqResponse;
import com.zand.response.GetCorporateAccountDetailResponse;
import com.zand.response.GetTransactionListCorporateResponse;
import com.zand.response.GetTrxListLastNTrxResponse;
import com.zand.response.TransactionsDateRangeResponse;
import com.zand.service.NicknameService;
import com.zand.service.dto.AccountDetailsDto;
import com.zand.service.dto.AccountInquiryDto;
import com.zand.service.dto.AccountListDto;
import com.zand.service.dto.AccountSummaryDto;
import com.zand.service.dto.AccountTransactionListDto;
import com.zand.service.dto.BalanceInquiryDto;
import com.zand.service.dto.CorporateDetailsDto;
import com.zand.service.dto.TransactionListCorporateDto;
import com.zand.service.dto.TransactionsDateRangeDto;
import com.zand.service.validate.SignOnRq;
import com.zand.service.validate.Status;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;

import static com.zand.request.CommonRequest.getCommonSignOnRq;


/**
 * Implementation of the {@link AccountCommunicator} that connects the accounts
 * with the middleware.
 */
@Component
public class AccountCommunicatorImpl implements AccountCommunicator {

  /**
   * Logger to log.
   */
  private static final Logger log = LoggerFactory.getLogger(AccountCommunicatorImpl.class);

  /**
   * feign configuration.
   */
  private final AccountFeign accountFeign;

  /**
   * nickname service.
   */
  private final NicknameService nicknameService;

  /**
   * invalid error message.
   */
  private static final String INVALID_ERROR_MESSAGE = "Invalid response";

  /**
   * constructor.
   *
   * @param accountFeign    feign to connect to middleware.
   * @param nicknameService nickname service that will be used to add nicknames to accounts.
   */
  public AccountCommunicatorImpl(AccountFeign accountFeign, NicknameService nicknameService) {
    this.accountFeign = accountFeign;
    this.nicknameService = nicknameService;
  }

  /**
   * This will check whether response from middleware is valid.
   *
   * @param status            response status.
   * @param requestIdentifier any string that can help to identify the request, like accountId, clientId, etc...
   * @return response is valid or not.
   */
  public static boolean validateResponse(Status status, String requestIdentifier) {
    if (status == null || status.getCode() == null) {
      throw new RuntimeException("Error in response with request identifier = " + requestIdentifier);
    }

    if (MiddlewareConstants.SUCCESS_CODE.equals(status.getCode())) {
      return true;
    }
    throw new RuntimeException(status.getStatusMessage());
  }

  /**
   * This will get account balance of an account with the account nickname.
   *
   * @param accountId   the account number.
   * @param customerKey the customer identifier, cna be null
   * @return the {@link BalanceInquiryDto } response from API.
   */
  @Override
  public BalanceInquiryDto getBalanceWithNickname(String accountId, UUID customerKey) {
    return nicknameService.populateDataWithNickname(getBalance(accountId), customerKey);
  }

  /**
   * This will get account balance of an account.
   *
   * @param accountId the account number.
   * @return the {@link BalanceInquiryDto } response from API.
   */
  @Override
  public BalanceInquiryDto getBalance(String accountId) {
    log.debug("request to get balance for account : {}", accountId);
    SignOnRqForBalance request = new SignOnRqForBalance();
    request.setSignOnRq(CommonRequest.getCommonSignOnRq());
    request.setAccountId(accountId);
    GetBalanceInquiryResponse response = accountFeign.getFeignClient().balanceInquiry(request);
    if (response == null || response.getContent() == null) {
      throw new IllegalArgumentException("This account seems to be an invalid account: " + accountId);
    }
    validateResponse(response.getStatus(), accountId);

    return response.getContent();
  }

  /**
   * This will get details of all accounts.
   *
   * @param accountId the account number.
   * @param iban      iban.
   * @param mobileNo  mobile number.
   * @return the {@link AccountInquiryDto } response from API.
   */
  @Override
  public List<AccountInquiryDto> getAllAccounts(String accountId, String iban, String mobileNo, UUID customerKey) {
    SignOnRequestForAccount request = new SignOnRequestForAccount();
    request.setSignOnRq(CommonRequest.getCommonSignOnRq());
    request.setAccountId(accountId);
    request.setMobileNo(mobileNo);
    request.setiban(iban);
    GetAccountInquiryResponse response = accountFeign
            .getFeignClient().accountInquiry(request);
    if (response == null || response.getContent() == null) {
      throw new IllegalArgumentException("Invalid iban/account number");
    }
    validateResponse(response.getStatus(), accountId);
    return nicknameService.populateDataListWithNickname(response.getContent(), customerKey);
  }

  /**
   * This will get All accounts with balance.
   *
   * @param clientId the client id.
   * @return the {@link AccountSummaryDto } response from API
   */
  @Override
  public List<AccountSummaryDto> getAccountSummary(String clientId, UUID customerKey) {
    SignOnRqWithClientId request = new SignOnRqWithClientId();
    request.setSignOnRq(CommonRequest.getCommonSignOnRq());
    request.setClientID(clientId);
    GetCifAccountsBalanceInqResponse response = accountFeign.getFeignClient().getCifAccountsBalanceInq(request);
    if (response == null || response.getContent() == null) {
      throw new IllegalArgumentException(INVALID_ERROR_MESSAGE);
    }
    validateResponse(response.getStatus(), clientId);

    return nicknameService.populateDataListWithNickname(response.getContent(), customerKey);
  }

  /**
   * This will get an account with transactions.
   *
   * @param accountID   the account number.
   * @param noOfLastTrx number of transactions.
   * @param customerKey the customer key.
   * @return the {@link AccountDetailsDto } response from API
   */
  @Override
  public AccountDetailsDto getAccountDetailsWithTransactions(String accountID, int noOfLastTrx, UUID customerKey) {
    Data data = new Data();
    data.setAccountID(accountID);
    data.setNoOfLastTrx(noOfLastTrx);
    SignOnRequestWithAccountIdAndTrxNo request = new SignOnRequestWithAccountIdAndTrxNo();
    request.setSignOnRq(CommonRequest.getCommonSignOnRq());
    request.setData(data);
    GetTrxListLastNTrxResponse response = accountFeign.getFeignClient().trxListLastNTrx(request);

    if (response == null || response.getContent() == null) {
      throw new IllegalArgumentException(INVALID_ERROR_MESSAGE);
    }
    validateResponse(response.getStatus(), accountID);

    AccountDetailsDto responseContent = response.getContent();
    AccountListDto accountWithNickname = nicknameService.populateDataWithNickname(
            responseContent.getAccountDetails(), customerKey);
    responseContent.setAccountDetails(accountWithNickname);

    List<AccountTransactionListDto> transactionListWithNickname = nicknameService.populateDataListWithNickname(
            responseContent.getStatementRecords(), customerKey);
    responseContent.setStatementRecords(transactionListWithNickname);

    return responseContent;
  }

  /**
   * This will get transaction list.
   *
   * @param accountID the account number.
   * @param startDate start date of transactions and format :yyyy-mm-dd.
   * @param endDate   end date of transaction and format :yyyy-mm-dd.
   * @return the {@link TransactionListCorporateDto } response from API
   */
  @Override
  public List<TransactionListCorporateDto> getTransactionListCorporate(
          String accountID, String startDate, String endDate) {
    SignOnRqForTransactionListCorporate request = new SignOnRqForTransactionListCorporate();
    request.setSignOnRq(CommonRequest.getCommonSignOnRq());
    request.setStartDate(startDate);
    request.setEndDate(endDate);
    request.setAccountID(accountID);
    GetTransactionListCorporateResponse response = accountFeign.getFeignClient().getTransactionListCorporate(request);
    if (response == null || response.getContent() == null) {
      throw new IllegalArgumentException(INVALID_ERROR_MESSAGE);
    }
    validateResponse(response.getStatus(), accountID);

    return response.getContent();
  }

  /**
   * This will get corporate account detail.
   *
   * @param accountId   the account number.
   * @param iban        iban .
   * @param customerKey the customer identifier.
   * @return the {@link CorporateDetailsDto } response from API
   */
  @Override
  public CorporateDetailsDto getCorporateAccountDetail(String accountId, String iban, UUID customerKey) {
    SignOnRqForCorporateAccountDetails request = new SignOnRqForCorporateAccountDetails();
    request.setSignOnRq(CommonRequest.getCommonSignOnRq());
    request.setAccountId(accountId);
    request.setiban(iban);
    GetCorporateAccountDetailResponse response = accountFeign.getFeignClient().getCorporateAccountDetail(request);
    if (response == null || response.getContent() == null) {
      throw new IllegalArgumentException(INVALID_ERROR_MESSAGE);
    }
    validateResponse(response.getStatus(), accountId);

    return nicknameService.populateDataWithNickname(response.getContent(), customerKey);
  }

  /**
   * This will get transaction list for a date range.
   *
   * @param accountID   account number.
   * @param fromDate    from date and format :yyyy-mm-dd (converted to offsetDateTime with
   *                    time of midnight at the start of the day, '00:00 )
   * @param toDate      to date and format :yyyy-mm-dd (converted to offsetDateTime with
   *                    the time just before midnight at the end of the day :'23:59:59.999999999')
   * @param customerKey the customer identifier.
   * @return the {@link TransactionsDateRangeDto } response from API
   */
  @Override
  public TransactionsDateRangeDto getTransactionsByDateRange(
          String accountID, String fromDate, String toDate, UUID customerKey) {
    SignOnRequestTransactionDateRange request = new SignOnRequestTransactionDateRange();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setAccountID(accountID);
    OffsetDateTime fromOffsetDateTime = OffsetDateTime.of(
            LocalDate.parse(fromDate).atTime(LocalTime.MIN), ZoneOffset.ofHours(+4));
    data.setFromDate(fromOffsetDateTime.toString());
    OffsetDateTime toOffsetDateTime = OffsetDateTime.of(
            LocalDate.parse(toDate).atTime(LocalTime.MAX), ZoneOffset.ofHours(+4));
    data.setToDate(toOffsetDateTime.toString());
    data.setOutputType(MiddlewareConstants.JSON_OUTPUT_TYPE);
    request.setData(data);
    TransactionsDateRangeResponse response = accountFeign.getFeignClient().getTransactionsByDateRange(request);
    if (response == null || response.getContent() == null) {
      throw new IllegalArgumentException(INVALID_ERROR_MESSAGE);
    }
    validateResponse(response.getStatus(), accountID);

    TransactionsDateRangeDto responseDto;
    responseDto = response.getContent();

    List<AccountTransactionListDto> transactionListWithNickname = nicknameService.populateDataListWithNickname(
            responseDto.getStatementRecords(), customerKey);
    responseDto.setStatementRecords(transactionListWithNickname);

    AccountListDto accountWithNickname = nicknameService.populateDataWithNickname(
            responseDto.getAccountDetails(), customerKey);
    responseDto.setAccountDetails(accountWithNickname);

    return responseDto;
  }
}


