package com.zand.request;

import com.zand.service.validate.SignOnRq;

/**
 * sign on request for account.
 */
public class SignOnRequestForAccount {

  /**
   * sign on request.
   */
  private SignOnRq signOnRq;

  /**
   * accountId.
   */
  private String accountId;

  /**
   * mobile number.
   */
  private String mobileNo;

  /**
   * iban.
   */
  private String iban;

  /**
   * getter.
   *
   * @return current signOnRq.
   */
  public SignOnRq getSignOnRq() {
    return signOnRq;
  }

  /**
   * setter.
   *
   * @param signOnRq signOnRq to set.
   */
  public void setSignOnRq(SignOnRq signOnRq) {
    this.signOnRq = signOnRq;
  }

  /**
   * getter.
   *
   * @return current accountId.
   */
  public String getAccountId() {
    return accountId;
  }

  /**
   * setter.
   *
   * @param accountId accountId to set.
   */
  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  /**
   * getter.
   *
   * @return current mobileNo.
   */
  public String getMobileNo() {
    return mobileNo;
  }

  /**
   * setter.
   *
   * @param mobileNo mobileNo to set.
   */
  public void setMobileNo(String mobileNo) {
    this.mobileNo = mobileNo;
  }

  /**
   * getter.
   *
   * @return current iban.
   */
  public String getiban() {
    return iban;
  }

  /**
   * setter.
   *
   * @param iban iban to set.
   */
  public void setiban(String iban) {
    this.iban = iban;
  }
}
