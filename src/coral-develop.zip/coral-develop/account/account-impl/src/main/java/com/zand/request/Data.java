package com.zand.request;

/**
 * data.
 */
public class Data {

  /**
   * accountId.
   */
  private String accountID;

  /**
   * noOfLastTrx.
   */
  private int noOfLastTrx;

  /**
   * from date.
   */
  private String fromDate;

  /**
   * from date.
   */
  private String toDate;

  /**
   * output type.
   */
  private String outputType;

  /**
   * working date.
   */
  private String workingDate;

  /**
   * transaction ref number.
   */
  private Double trxRefNo;

  /**
   * getter.
   *
   * @return current accountID.
   */
  public String getAccountID() {
    return accountID;
  }

  /**
   * setter.
   *
   * @param accountID accountID to set.
   */
  public void setAccountID(String accountID) {
    this.accountID = accountID;
  }

  /**
   * getter.
   *
   * @return current noOfLastTrx.
   */
  public int getNoOfLastTrx() {
    return noOfLastTrx;
  }

  /**
   * setter.
   *
   * @param noOfLastTrx noOfLastTrx to set.
   */
  public void setNoOfLastTrx(int noOfLastTrx) {
    this.noOfLastTrx = noOfLastTrx;
  }

  /**
   * getter.
   *
   * @return current fromDate.
   */
  public String getFromDate() {
    return fromDate;
  }

  /**
   * setter.
   *
   * @param fromDate from date.
   */
  public void setFromDate(String fromDate) {
    this.fromDate = fromDate;
  }

  /**
   * getter.
   *
   * @return current outputType.
   */
  public String getOutputType() {
    return outputType;
  }

  /**
   * setter.
   *
   * @param outputType output type.
   */
  public void setOutputType(String outputType) {
    this.outputType = outputType;
  }

  /**
   * getter.
   *
   * @return current to date.
   */
  public String getToDate() {
    return toDate;
  }

  /**
   * setter.
   *
   * @param toDate to date.
   */
  public void setToDate(String toDate) {
    this.toDate = toDate;
  }

  /**
   * getter.
   *
   * @return current working date.
   */
  public String getWorkingDate() {
    return workingDate;
  }

  /**
   * setter.
   *
   * @param workingDate working date.
   */
  public void setWorkingDate(String workingDate) {
    this.workingDate = workingDate;
  }

  /**
   * getter.
   *
   * @return current transaction ref number.
   */
  public Double getTrxRefNo() {
    return trxRefNo;
  }

  /**
   * setter.
   *
   * @param trxRefNo transaction ref number.
   */
  public void setTrxRefNo(Double trxRefNo) {
    this.trxRefNo = trxRefNo;
  }
}

