package com.zand.request;

import com.zand.service.validate.SignOnRq;
import com.zand.config.MiddlewareConstants;

import java.time.LocalDate;
import java.util.UUID;

/**
 * common request.
 */
public class CommonRequest {
  /**
   * getter.
   *
   * @return current signOnRq.
   */
  public static SignOnRq getCommonSignOnRq() {
    SignOnRq signOnRq = new SignOnRq();
    signOnRq.setLogId(UUID.randomUUID().toString());
    signOnRq.setChannelId(MiddlewareConstants.CORPORATE_CHANNEL_ID);
    signOnRq.setDateTime(LocalDate.now().toString());
    signOnRq.setOurBranchId(MiddlewareConstants.BRANCH_ID);
    return signOnRq;
  }

  /**
   * getter.
   *
   * @return current data.
   */
  public Data getData() {
    Data data = new Data();
    data.setAccountID("0150100008267101");
    data.setNoOfLastTrx(3);
    return data;
  }
}
