package com.zand.web.rest;

import com.zand.Feature;
import com.zand.Permission;
import com.zand.service.AccountStatementService;
import com.zand.service.dto.StatementDto;
import com.zand.spring.HasAccess;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * REST controller for account statements.
 */
@RestController
public class AccountStatementResourceImpl implements AccountStatementResource {

  /**
   * account statement service.
   */
  private final AccountStatementService accountStatementService;

  /**
   * constructor.
   */
  public AccountStatementResourceImpl(AccountStatementService accountStatementService) {
    this.accountStatementService = accountStatementService;
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public ResponseEntity<StatementDto> getMonthlyStatements(
          String accountID, String fromDate, UUID customer) {
    return ResponseEntity.ok(accountStatementService.getMonthlyStatements(accountID, fromDate, customer));
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public ResponseEntity<StatementDto> getStatementsByDateRange(
          String accountID, String fromDate, String toDate, UUID customer) {
    return ResponseEntity.ok(accountStatementService
            .getStatementsByDateRange(accountID, fromDate, toDate, customer));
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public ResponseEntity<StatementDto> getDebitAdvice(String workingDate, Double trxRefNo, UUID customer) {
    return ResponseEntity.ok(accountStatementService.getDebitAdvice(workingDate, trxRefNo, customer));
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public ResponseEntity<StatementDto> getCreditAdvice(String workingDate, Double trxRefNo, UUID customer) {
    return ResponseEntity.ok(accountStatementService.getCreditAdvice(workingDate, trxRefNo, customer));
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public ResponseEntity<StatementDto> getVatAdvice(String workingDate, Double trxRefNo, UUID customer) {
    return ResponseEntity.ok(accountStatementService.getVatAdvice(workingDate, trxRefNo, customer));
  }

  @Override
  @HasAccess(feature = Feature.ACCOUNT, permission = Permission.READ)
  public ResponseEntity<StatementDto> getMonthlyVatAdvice(String accountID, String fromDate, UUID customer) {
    return ResponseEntity.ok(accountStatementService.getMonthlyVatAdvice(accountID, fromDate, customer));
  }
}
