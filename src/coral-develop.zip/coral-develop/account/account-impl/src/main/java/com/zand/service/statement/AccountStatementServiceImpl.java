package com.zand.service.statement;

import com.zand.BankMaster;
import com.zand.client.AccountStatementClient;
import com.zand.config.MiddlewareConstants;
import com.zand.request.Data;
import com.zand.request.SignOnRequestStatement;
import com.zand.service.AccountStatementService;
import com.zand.service.NicknameService;
import com.zand.service.dto.StatementDto;
import com.zand.service.utils.DateUtils;
import com.zand.service.validate.SignOnRq;
import com.zand.service.validate.StatementResponse;
import feign.FeignException;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.UUID;
import static com.zand.request.CommonRequest.getCommonSignOnRq;

/**
 * Service implementation class for account statement.
 */
@Service
public class AccountStatementServiceImpl implements AccountStatementService {

  /**
   * statement feign.
   */
  private StatementFeign statementFeign;

  /**
   * Nickname service to get nickname for statement.
   */
  private NicknameService nicknameService;

  /**
   * Bank Master service.
   */
  private BankMaster bankMaster;

  /**
   * Construtor.
   *
   * @param nicknameService the service to get nickname for this entity
   */
  public AccountStatementServiceImpl(NicknameService nicknameService, StatementFeign statementFeign,
                                     BankMaster bankMaster) {

    this.nicknameService = nicknameService;
    this.statementFeign = statementFeign;
    this.bankMaster = bankMaster;
  }

  /**
   * This will get the monthly statement for account.
   *
   * @param accountID   account number.
   * @param fromDate    from date and format :yyyy-MM-dd (converted to offsetDateTime with
   *                    time of midnight at the start of the day, '00:00 )
   *                    outputType should be letter O for pdf.
   * @param customerKey the customer UUID.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the monthly statements in body.
   */
  @Override
  public StatementDto getMonthlyStatements(String accountID, String fromDate, UUID customerKey) {
    final AccountStatementClient accountStatementClient = statementFeign.getClient();
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);

    Data data = new Data();
    data.setAccountID(accountID);

    data.setFromDate(DateUtils.stringDateToOffsetedStringDate(fromDate, ZoneId.of(bankMaster.getDefaultTimezone())));
    OffsetDateTime toOffsetDateTime = OffsetDateTime.of(
            LocalDate.parse(fromDate).atTime(LocalTime.MAX), ZoneOffset.ofHours(+4));
    data.setFromDate(toOffsetDateTime.toString());
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    request.setData(data);

    StatementResponse response = accountStatementClient.getMonthlyStatements(request);
    checkResponseStatus(response);
    return nicknameService.populateDataWithNickname(
            response.getContent(),
            customerKey,
            accountID
    );
  }

  /**
   * This will get the statement for account for a date range.
   *
   * @param accountID account number.
   * @param fromDate  from date and format :yyyy-MM-dd (converted to offsetDateTime with
   *                  time of midnight at the start of the day, '00:00 )
   * @param toDate    to date and format :yyyy-MM-dd (converted to offsetDateTime with
   *                  the time just before midnight at the end of the day :'23:59:59.999999999')
   *                  outputType should be letter O for pdf.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the statement for a date range in body.
   */
  @Override
  public StatementDto getStatementsByDateRange(
          String accountID, String fromDate, String toDate, UUID customerKey) {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    final AccountStatementClient accountStatementClient = statementFeign.getClient();
    Data data = new Data();
    data.setAccountID(accountID);
    data.setFromDate(DateUtils.stringDateToOffsetedStringDate(fromDate, ZoneId.of(bankMaster.getDefaultTimezone())));
    OffsetDateTime toOffsetDateTime = OffsetDateTime.of(
            LocalDate.parse(toDate).atTime(LocalTime.MAX), ZoneOffset.ofHours(+4));
    data.setToDate(toOffsetDateTime.toString());
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    request.setData(data);

    StatementResponse response = accountStatementClient.geStatementByDateRange(request);
    checkResponseStatus(response);

    return nicknameService.populateDataWithNickname(
            response.getContent(),
            customerKey,
            accountID
    );
  }

  /**
   * This will get the debit advice.
   *
   * @param workingDate working date and format :yyyy-MM-dd'T'HH:mm:ss'Z'.
   * @param trxRefNo    transaction reference number.
   *                    outputType should be letter O for pdf.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the debit advice.
   */
  @Override
  public StatementDto getDebitAdvice(String workingDate, Double trxRefNo, UUID customerKey) {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setWorkingDate(workingDate);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    data.setTrxRefNo(trxRefNo);
    request.setData(data);
    final AccountStatementClient accountStatementClient = statementFeign.getClient();

    StatementResponse response = accountStatementClient.getDebitAdvice(request);
    checkResponseStatus(response);
    return nicknameService.populateDataWithNickname(
            response.getContent(),
            customerKey,
            trxRefNo.toString()
    );

  }

  /**
   * This will get the credit advice.
   *
   * @param workingDate working date and format :yyyy-MM-dd'T'HH:mm:ss'Z'.
   * @param trxRefNo    transaction reference number.
   *                    outputType should be letter O for pdf.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the credit advice.
   */
  @Override
  public StatementDto getCreditAdvice(String workingDate, Double trxRefNo, UUID customerKey) {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setWorkingDate(workingDate);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    data.setTrxRefNo(trxRefNo);
    request.setData(data);
    final AccountStatementClient accountStatementClient = statementFeign.getClient();

    StatementResponse response = accountStatementClient.getCreditAdvice(request);
    checkResponseStatus(response);
    return nicknameService.populateDataWithNickname(
            response.getContent(),
            customerKey,
            trxRefNo.toString()
    );

  }

  /**
   * This will get the vat advice.
   *
   * @param workingDate working date and format :yyyy-MM-dd'T'HH:mm:ss'Z'.
   * @param trxRefNo    transaction reference number.
   *                    outputType should be letter O for pdf.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the vat advice.
   */
  @Override
  public StatementDto getVatAdvice(String workingDate, Double trxRefNo, UUID customerKey) {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setWorkingDate(workingDate);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    data.setTrxRefNo(trxRefNo);
    request.setData(data);
    final AccountStatementClient accountStatementClient = statementFeign.getClient();

    StatementResponse response = accountStatementClient.getVatAdvice(request);
    checkResponseStatus(response);
    return nicknameService.populateDataWithNickname(
            response.getContent(),
            customerKey,
            trxRefNo.toString()
    );
  }

  /**
   * This will get the monthly vat advice.
   *
   * @param accountID account number.
   * @param fromDate  from date and format :yyyy-MM-dd (converted to offsetDateTime with
   *                  time of midnight at the start of the day, '00:00 )
   *                  outputType should be letter O for pdf.
   * @return the {@link StatementDto} with status {@code 200 (OK)} and the monthly vat advice.
   */
  @Override
  public StatementDto getMonthlyVatAdvice(String accountID, String fromDate, UUID customerKey) {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setAccountID(accountID);
    data.setFromDate(DateUtils.stringDateToOffsetedStringDate(fromDate, ZoneId.of(bankMaster.getDefaultTimezone())));
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    request.setData(data);
    final AccountStatementClient accountStatementClient = statementFeign.getClient();

    StatementResponse response = accountStatementClient.getMonthlyVatAdvice(request);
    checkResponseStatus(response);
    return nicknameService.populateDataWithNickname(
            response.getContent(),
            customerKey,
            accountID
    );
  }

  /**
   * This will validate the response.
   *
   * @param response response.
   */
  void checkResponseStatus(StatementResponse response) {
    if (response == null || response.getStatus() == null || response.getStatus().getCode() == null) {
      throw new IllegalArgumentException("Invalid response");
    }

    if (!MiddlewareConstants.SUCCESS_CODE.equals(response.getStatus().getCode())) {
      throw new RuntimeException(response.getStatus().getStatusMessage());
    }
  }
}
