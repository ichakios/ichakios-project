package com.zand.client;

import com.zand.request.SignOnRequestForAccount;
import com.zand.request.SignOnRequestTransactionDateRange;
import com.zand.request.SignOnRequestWithAccountIdAndTrxNo;
import com.zand.request.SignOnRqForBalance;
import com.zand.request.SignOnRqForCorporateAccountDetails;
import com.zand.request.SignOnRqForTransactionListCorporate;
import com.zand.request.SignOnRqWithClientId;
import com.zand.response.GetAccountInquiryResponse;
import com.zand.response.GetBalanceInquiryResponse;
import com.zand.response.GetCifAccountsBalanceInqResponse;
import com.zand.response.GetCorporateAccountDetailResponse;
import com.zand.response.GetTransactionListCorporateResponse;
import com.zand.response.GetTrxListLastNTrxResponse;
import com.zand.response.TransactionsDateRangeResponse;
import feign.Headers;
import feign.RequestLine;

/**
 * Interface for account client for connecting to WAQFE via feign.
 */
public interface AccountClient {

  /**
   * To get all the accounts with balance.
   */
  @RequestLine("POST /api/BankSmart/GetCIFAccountsBalanceInq")
  @Headers("Content-Type: application/json")
  GetCifAccountsBalanceInqResponse getCifAccountsBalanceInq(
          SignOnRqWithClientId signOnRqWithClientId);

  /**
   * To get all the accounts.
   */
  @RequestLine("POST /api/BankSmart/AccountInquiry")
  @Headers("Content-Type: application/json")
  GetAccountInquiryResponse accountInquiry(SignOnRequestForAccount signOnRequestForAccount);

  /**
   * Get balance for an account.
   */
  @RequestLine("POST /api/BankSmart/BalanceInquiry")
  @Headers("Content-Type: application/json")
  GetBalanceInquiryResponse balanceInquiry(SignOnRqForBalance signOnRqForBalance);

  /**
   * Get Account details with Transaction list.
   */
  @RequestLine("POST /api/DigibancStatement/TrxListLastNTrx")
  @Headers("Content-Type: application/json")
  GetTrxListLastNTrxResponse trxListLastNTrx(
          SignOnRequestWithAccountIdAndTrxNo signOnRequestWithAccountIdAndTrxNo);

  /**
   * Get transaction list for corporate(without balance).
   */
  @RequestLine("POST /api/BankSmart/GetTransactionListCorporate")
  @Headers("Content-Type: application/json")
  GetTransactionListCorporateResponse getTransactionListCorporate(
          SignOnRqForTransactionListCorporate signOnRqForTransactionListCorporate);

  /**
   * Get Details for a corporate account.
   */
  @RequestLine("POST /api/BankSmart/GetCorporateAccountDetail")
  @Headers("Content-Type: application/json")
  GetCorporateAccountDetailResponse getCorporateAccountDetail(
          SignOnRqForCorporateAccountDetails signOnRqForCorporateAccountDetails);

  /**
   * To get transaction list for a date range.
   */
  @RequestLine("POST /api/DigibancStatement/CustStatDateWise")
  @Headers("Content-Type: application/json")
  TransactionsDateRangeResponse getTransactionsByDateRange(SignOnRequestTransactionDateRange request);
}


