package com.zand.client;

import com.zand.config.MiddlewareConstants;
import com.zand.config.ZandClientBuilder;
import com.zand.request.CommonRequest;
import com.zand.request.Data;
import com.zand.request.SignOnRequestForAccount;
import com.zand.request.SignOnRequestTransactionDateRange;
import com.zand.request.SignOnRequestWithAccountIdAndTrxNo;
import com.zand.request.SignOnRqForBalance;
import com.zand.request.SignOnRqForCorporateAccountDetails;
import com.zand.request.SignOnRqForTransactionListCorporate;
import com.zand.request.SignOnRqWithClientId;
import com.zand.response.GetAccountInquiryResponse;
import com.zand.response.GetBalanceInquiryResponse;
import com.zand.response.GetCifAccountsBalanceInqResponse;
import com.zand.response.GetCorporateAccountDetailResponse;
import com.zand.response.GetTransactionListCorporateResponse;
import com.zand.response.GetTrxListLastNTrxResponse;
import com.zand.response.TransactionsDateRangeResponse;
import com.zand.service.validate.SignOnRq;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static com.zand.request.CommonRequest.getCommonSignOnRq;

@Tag(MiddlewareConstants.TAG)
class AccountClientTest {

  private AccountClient client;

  CommonRequest commonRequest = new CommonRequest();

  @BeforeEach
  void setup() {
    client = ZandClientBuilder.get().target(AccountClient.class, MiddlewareConstants.URL);
  }

  /**
   * To test all the accounts with balance
   */
  @Test
  void getAllAccountsWithBalanceSuccessfully() {
    SignOnRqWithClientId signOnRqWithClientId = new SignOnRqWithClientId();
    signOnRqWithClientId.setSignOnRq(CommonRequest.getCommonSignOnRq());
    signOnRqWithClientId.setClientID("000082671");
    GetCifAccountsBalanceInqResponse response = client.getCifAccountsBalanceInq(signOnRqWithClientId);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  /**
   * Test Account details with Transaction list
   */
  @Test
  void getAllAccountsWithTransactionDetails() {
    SignOnRequestWithAccountIdAndTrxNo signOnRequestWithAccountIdAndTrxNo = new SignOnRequestWithAccountIdAndTrxNo();
    signOnRequestWithAccountIdAndTrxNo.setSignOnRq(CommonRequest.getCommonSignOnRq());
    signOnRequestWithAccountIdAndTrxNo.setData(commonRequest.getData());
    GetTrxListLastNTrxResponse response = client.trxListLastNTrx(signOnRequestWithAccountIdAndTrxNo);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  /**
   * Test AccountInquiry(all accounts without balance)
   */
  @Test
  void getAllAccounts() {
    SignOnRequestForAccount signOnRequestForAccount = new SignOnRequestForAccount();
    signOnRequestForAccount.setSignOnRq(CommonRequest.getCommonSignOnRq());
    signOnRequestForAccount.setAccountId("0150100008267101");
    signOnRequestForAccount.setMobileNo("123456789");
    signOnRequestForAccount.setiban("AE590900150100008267101");
    GetAccountInquiryResponse response = client.accountInquiry(signOnRequestForAccount);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  /**
   * Test balance
   */
  @Test
  void getBalanceSuccessfully() {
    SignOnRqForBalance signOnRqForBalance = new SignOnRqForBalance();
    signOnRqForBalance.setSignOnRq(CommonRequest.getCommonSignOnRq());
    signOnRqForBalance.setAccountId("0150100008267101");
    GetBalanceInquiryResponse response = client.balanceInquiry(signOnRqForBalance);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  /**
   * Test corporate account detail
   */
  @Test
  void GetCorporateAccountDetail() {
    SignOnRqForCorporateAccountDetails signOnRqForCorporateAccountDetails = new SignOnRqForCorporateAccountDetails();
    signOnRqForCorporateAccountDetails.setSignOnRq(CommonRequest.getCommonSignOnRq());
    signOnRqForCorporateAccountDetails.setAccountId("0150100008267101");
    signOnRqForCorporateAccountDetails.setiban("AE590900150100008267101");
    GetCorporateAccountDetailResponse response = client.getCorporateAccountDetail(signOnRqForCorporateAccountDetails);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  /**
   * Test corporate transaction detail
   */
  @Test
  void GetTransactionListCorporate() {
    SignOnRqForTransactionListCorporate signOnRqForTransactionListCorporate = new SignOnRqForTransactionListCorporate();
    signOnRqForTransactionListCorporate.setSignOnRq(CommonRequest.getCommonSignOnRq());
    signOnRqForTransactionListCorporate.setStartDate("2019-01-21T11:25:08.178Z");
    signOnRqForTransactionListCorporate.setEndDate("2020-01-21T11:25:08.178Z");
    signOnRqForTransactionListCorporate.setAccountID("0150100001438402");
    GetTransactionListCorporateResponse response =
            client.getTransactionListCorporate(signOnRqForTransactionListCorporate);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  @Test
  void testForTransactionForDateRange() {
    SignOnRequestTransactionDateRange request = new SignOnRequestTransactionDateRange();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setAccountID("0150100008267101");
    OffsetDateTime fromOffsetDateTime = OffsetDateTime.of(
            LocalDate.parse("2019-03-18").atTime(LocalTime.MIN), ZoneOffset.ofHours(+4));
    data.setFromDate(fromOffsetDateTime.toString());
    OffsetDateTime toOffsetDateTime = OffsetDateTime.of(
            LocalDate.parse("2020-03-18").atTime(LocalTime.MAX), ZoneOffset.ofHours(+4));
    data.setToDate(toOffsetDateTime.toString());
    data.setOutputType("J");
    request.setData(data);
    TransactionsDateRangeResponse response = client.getTransactionsByDateRange(request);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }
}
