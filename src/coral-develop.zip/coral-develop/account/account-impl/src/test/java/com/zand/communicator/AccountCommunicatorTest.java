package com.zand.communicator;

import com.zand.client.AccountClient;
import com.zand.config.AccountFeign;
import com.zand.config.MiddlewareConstants;
import com.zand.request.Data;
import com.zand.request.SignOnRequestForAccount;
import com.zand.request.SignOnRequestTransactionDateRange;
import com.zand.request.SignOnRequestWithAccountIdAndTrxNo;
import com.zand.request.SignOnRqForBalance;
import com.zand.request.SignOnRqForCorporateAccountDetails;
import com.zand.request.SignOnRqForTransactionListCorporate;
import com.zand.request.SignOnRqWithClientId;
import com.zand.response.GetAccountInquiryResponse;
import com.zand.response.GetBalanceInquiryResponse;
import com.zand.response.GetCifAccountsBalanceInqResponse;
import com.zand.response.GetCorporateAccountDetailResponse;
import com.zand.response.GetTransactionListCorporateResponse;
import com.zand.response.GetTrxListLastNTrxResponse;
import com.zand.response.TransactionsDateRangeResponse;
import com.zand.service.NicknameService;
import com.zand.service.dto.AccountDetailsDto;
import com.zand.service.dto.AccountInquiryDto;
import com.zand.service.dto.AccountListDto;
import com.zand.service.dto.AccountSummaryDto;
import com.zand.service.dto.AccountTransactionListDto;
import com.zand.service.dto.BalanceInquiryDto;
import com.zand.service.dto.CorporateDetailsDto;
import com.zand.service.dto.TransactionListCorporateDto;
import com.zand.service.dto.TransactionsDateRangeDto;
import com.zand.service.validate.Status;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

class AccountCommunicatorTest {

  AccountCommunicator accountCommunicator;

  @Mock
  NicknameService nicknameService;

  @Mock
  AccountFeign accountFeign;

  @Mock
  AccountClient feignClient;

  UUID customerKey = UUID.randomUUID();
  String accountId = "1";
  String clientId = "1";


  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);
    accountCommunicator = new AccountCommunicatorImpl(accountFeign, nicknameService);
    given(accountFeign.getFeignClient()).willReturn(feignClient);
  }

  @Test
  void shouldGetBalance() {
    // given
    GetBalanceInquiryResponse response = new GetBalanceInquiryResponse();
    Status responseStatus = new Status();
    responseStatus.setCode(MiddlewareConstants.SUCCESS_CODE);
    response.setStatus(responseStatus);

    BalanceInquiryDto balanceInquiryDtoToReturn = new BalanceInquiryDto();
    balanceInquiryDtoToReturn.setAccountId(accountId);
    response.setContent(balanceInquiryDtoToReturn);

    given(feignClient.balanceInquiry(any(SignOnRqForBalance.class))).willReturn(response);

    // when
    BalanceInquiryDto balanceInquiryDto = accountCommunicator.getBalance(accountId);

    // then
    ArgumentCaptor<SignOnRqForBalance> request = ArgumentCaptor.forClass(SignOnRqForBalance.class);
    verify(feignClient).balanceInquiry(request.capture());
    assertEquals(accountId, request.getValue().getAccountId());
    assertEquals(response.getContent(), balanceInquiryDto);
  }

  @Test
  void shouldntGetBalanceAndThrowWithBadStatusCode() {
    // given
    given(feignClient.balanceInquiry(any(SignOnRqForBalance.class))).willReturn(null);

    // when
    // then
    assertThrows(IllegalArgumentException.class, () -> {
      accountCommunicator.getBalance(accountId);
    }, "This account seems to be an invalid account: " + accountId);
  }

  @Test
  void shouldGetBalanceWithNickname() {
    // given
    GetBalanceInquiryResponse response = new GetBalanceInquiryResponse();
    Status responseStatus = new Status();
    responseStatus.setCode(MiddlewareConstants.SUCCESS_CODE);
    response.setStatus(responseStatus);

    BalanceInquiryDto balanceInquiryDtoToReturn = new BalanceInquiryDto();
    balanceInquiryDtoToReturn.setAccountId(accountId);
    response.setContent(balanceInquiryDtoToReturn);

    given(feignClient.balanceInquiry(any(SignOnRqForBalance.class))).willReturn(response);
    given(nicknameService.populateDataWithNickname(balanceInquiryDtoToReturn, customerKey)).willReturn(balanceInquiryDtoToReturn);

    // when
    BalanceInquiryDto balanceInquiryDto = accountCommunicator.getBalanceWithNickname(accountId, customerKey);

    // then
    ArgumentCaptor<SignOnRqForBalance> request = ArgumentCaptor.forClass(SignOnRqForBalance.class);
    verify(feignClient).balanceInquiry(request.capture());
    assertEquals(accountId, request.getValue().getAccountId());
    assertEquals(response.getContent(), balanceInquiryDto);
  }

  @Test
  void shouldGetAllAccounts() {
    // given
    String iban = "iban";
    String mobileNo = "mobileNo";

    GetAccountInquiryResponse response = new GetAccountInquiryResponse();
    Status responseStatus = new Status();
    responseStatus.setCode(MiddlewareConstants.SUCCESS_CODE);
    response.setStatus(responseStatus);

    List<AccountInquiryDto> accountsToReturn = new ArrayList<>();
    AccountInquiryDto accountInquiryDto = new AccountInquiryDto();
    accountInquiryDto.setAccountID(accountId);
    accountsToReturn.add(accountInquiryDto);
    response.setContent(accountsToReturn);

    given(feignClient.accountInquiry(any(SignOnRequestForAccount.class))).willReturn(response);
    given(nicknameService.populateDataListWithNickname(accountsToReturn, customerKey)).willReturn(accountsToReturn);

    // when
    List<AccountInquiryDto> accounts = accountCommunicator.getAllAccounts(accountId, iban, mobileNo, customerKey);

    // then
    ArgumentCaptor<SignOnRequestForAccount> request = ArgumentCaptor.forClass(SignOnRequestForAccount.class);
    verify(feignClient).accountInquiry(request.capture());
    assertEquals(accountId, request.getValue().getAccountId());
    assertEquals(accountsToReturn, accounts);

    verify(nicknameService, times(1)).populateDataListWithNickname(accountsToReturn, customerKey);
  }

  @Test
  void shouldntGetAllAccountsAndThrowWithBadStatusCode() {
    // given
    String iban = "iban";
    String mobileNo = "mobileNo";
    given(feignClient.accountInquiry(any(SignOnRequestForAccount.class))).willReturn(null);

    // when
    // then
    assertThrows(IllegalArgumentException.class, () -> {
      accountCommunicator.getAllAccounts(accountId, iban, mobileNo, customerKey);
    }, "Invalid iban/account number");
  }

  @Test
  void shouldGetAccountSummary() {
    // given
    GetCifAccountsBalanceInqResponse response = new GetCifAccountsBalanceInqResponse();
    Status responseStatus = new Status();
    responseStatus.setCode(MiddlewareConstants.SUCCESS_CODE);
    response.setStatus(responseStatus);

    List<AccountSummaryDto> accountsToReturn = new ArrayList<>();
    AccountSummaryDto accountSummaryDto = new AccountSummaryDto();
    accountSummaryDto.setAccountId(accountId);
    accountsToReturn.add(accountSummaryDto);
    response.setContent(accountsToReturn);

    given(feignClient.getCifAccountsBalanceInq(any(SignOnRqWithClientId.class))).willReturn(response);
    given(nicknameService.populateDataListWithNickname(accountsToReturn, customerKey)).willReturn(accountsToReturn);

    // when
    List<AccountSummaryDto> accounts = accountCommunicator.getAccountSummary(clientId, customerKey);

    // then
    ArgumentCaptor<SignOnRqWithClientId> request = ArgumentCaptor.forClass(SignOnRqWithClientId.class);
    verify(feignClient).getCifAccountsBalanceInq(request.capture());
    assertEquals(clientId, request.getValue().getClientID());
    assertEquals(accountsToReturn, accounts);

    verify(nicknameService, times(1)).populateDataListWithNickname(accountsToReturn, customerKey);
  }

  @Test
  void shouldntGetAccountSummaryAndThrowWithBadStatusCode() {
    // given
    given(feignClient.balanceInquiry(any(SignOnRqForBalance.class))).willReturn(null);

    // when
    // then
    assertThrows(IllegalArgumentException.class, () -> {
      accountCommunicator.getAccountSummary(clientId, customerKey);
    }, "Invalid response");
  }

  @Test
  void shouldGetAccountDetailsWithTransactions() {
    // given
    int noOfLastTrx = 5;
    GetTrxListLastNTrxResponse response = new GetTrxListLastNTrxResponse();
    Status responseStatus = new Status();
    responseStatus.setCode(MiddlewareConstants.SUCCESS_CODE);
    response.setStatus(responseStatus);

    AccountListDto accountListDto = new AccountListDto();
    accountListDto.setAccountID(accountId);

    List<AccountTransactionListDto> accountTransactionListDtoList = new ArrayList<>();
    AccountTransactionListDto accountTransactionListDto = new AccountTransactionListDto();
    accountTransactionListDto.setAmount("10");
    accountTransactionListDtoList.add(accountTransactionListDto);

    AccountDetailsDto accountDetailsDtoToReturn = new AccountDetailsDto();
    accountDetailsDtoToReturn.setAccountDetails(accountListDto);
    accountDetailsDtoToReturn.setStatementRecords(accountTransactionListDtoList);
    response.setContent(accountDetailsDtoToReturn);

    given(feignClient.trxListLastNTrx(any(SignOnRequestWithAccountIdAndTrxNo.class))).willReturn(response);
    given(nicknameService.populateDataWithNickname(accountListDto, customerKey)).willReturn(accountListDto);
    given(nicknameService.populateDataListWithNickname(accountTransactionListDtoList, customerKey))
            .willReturn(accountTransactionListDtoList);

    // when
    AccountDetailsDto accountDetailsDto = accountCommunicator
            .getAccountDetailsWithTransactions(accountId, noOfLastTrx, customerKey);

    // then
    Data requestDataToCheck = new Data();
    requestDataToCheck.setAccountID(accountId);
    requestDataToCheck.setNoOfLastTrx(noOfLastTrx);

    ArgumentCaptor<SignOnRequestWithAccountIdAndTrxNo> request = ArgumentCaptor.forClass(SignOnRequestWithAccountIdAndTrxNo.class);
    verify(feignClient).trxListLastNTrx(request.capture());
    assertEquals(requestDataToCheck.getAccountID(), request.getValue().getData().getAccountID());
    assertEquals(requestDataToCheck.getNoOfLastTrx(), request.getValue().getData().getNoOfLastTrx());
    assertEquals(accountDetailsDtoToReturn, accountDetailsDto);

    verify(nicknameService, times(1)).populateDataWithNickname(accountListDto, customerKey);
    verify(nicknameService, times(1)).populateDataListWithNickname(accountTransactionListDtoList, customerKey);
  }

  @Test
  void shouldntGetAccountDetailsWithTransactions() {
    // given
    int noOfLastTrx = 5;
    given(feignClient.trxListLastNTrx(any(SignOnRequestWithAccountIdAndTrxNo.class))).willReturn(null);

    // when
    // then
    assertThrows(IllegalArgumentException.class, () -> {
      accountCommunicator.getAccountDetailsWithTransactions(accountId, noOfLastTrx, customerKey);
    }, "Invalid response");
  }

  @Test
  void shouldGetTransactionListCorporate() {
    // given
    String startDate = "2020-01-01";
    String endDate = "2020-02-01";
    GetTransactionListCorporateResponse response = new GetTransactionListCorporateResponse();
    Status responseStatus = new Status();
    responseStatus.setCode(MiddlewareConstants.SUCCESS_CODE);
    response.setStatus(responseStatus);

    List<TransactionListCorporateDto> transactionsToReturn = new ArrayList<>();
    TransactionListCorporateDto transaction = new TransactionListCorporateDto();
    transaction.setAmount(10f);
    transactionsToReturn.add(transaction);
    response.setContent(transactionsToReturn);

    given(feignClient.getTransactionListCorporate(any(SignOnRqForTransactionListCorporate.class))).willReturn(response);

    // when
    List<TransactionListCorporateDto> transactions = accountCommunicator.getTransactionListCorporate(accountId, startDate, endDate);

    // then
    ArgumentCaptor<SignOnRqForTransactionListCorporate> request = ArgumentCaptor.forClass(SignOnRqForTransactionListCorporate.class);
    verify(feignClient).getTransactionListCorporate(request.capture());
    assertEquals(accountId, request.getValue().getAccountID());
    assertEquals(startDate, request.getValue().getStartDate());
    assertEquals(endDate, request.getValue().getEndDate());
    assertEquals(transactionsToReturn, transactions);
  }

  @Test
  void shouldntGetTransactionListCorporate() {
    // given
    String startDate = "2020-01-01";
    String endDate = "2020-02-01";
    given(feignClient.getTransactionListCorporate(any(SignOnRqForTransactionListCorporate.class))).willReturn(null);

    // when
    // then
    assertThrows(IllegalArgumentException.class, () -> {
      accountCommunicator.getTransactionListCorporate(accountId, startDate, endDate);
    }, "Invalid response");
  }

  @Test
  void shouldGetCorporateAccountDetail() {
    // given
    String iban = "a";
    GetCorporateAccountDetailResponse response = new GetCorporateAccountDetailResponse();
    Status responseStatus = new Status();
    responseStatus.setCode(MiddlewareConstants.SUCCESS_CODE);
    response.setStatus(responseStatus);

    CorporateDetailsDto corporateToReturn = new CorporateDetailsDto();
    corporateToReturn.setClientID(clientId);
    response.setContent(corporateToReturn);

    given(feignClient.getCorporateAccountDetail(any(SignOnRqForCorporateAccountDetails.class))).willReturn(response);
    given(nicknameService.populateDataWithNickname(corporateToReturn, customerKey)).willReturn(corporateToReturn);

    // when
    CorporateDetailsDto corporate = accountCommunicator.getCorporateAccountDetail(accountId, iban, customerKey);

    // then
    ArgumentCaptor<SignOnRqForCorporateAccountDetails> request = ArgumentCaptor.forClass(SignOnRqForCorporateAccountDetails.class);
    verify(feignClient).getCorporateAccountDetail(request.capture());
    assertEquals(accountId, request.getValue().getAccountId());
    assertEquals(iban, request.getValue().getiban());
    assertEquals(corporateToReturn, corporate);

    verify(nicknameService, times(1)).populateDataWithNickname(corporateToReturn, customerKey);
  }

  @Test
  void shouldntGetCorporateAccountDetail() {
    // given
    String iban = "a";
    given(feignClient.getTransactionListCorporate(any(SignOnRqForTransactionListCorporate.class))).willReturn(null);

    // when
    // then
    assertThrows(IllegalArgumentException.class, () -> {
      accountCommunicator.getCorporateAccountDetail(accountId, iban, customerKey);
    }, "Invalid response");
  }

  @Test
  void shouldGetTransactionsByDateRange() {
    // given
    String startDate = "2020-01-01";
    String endDate = "2020-02-01";
    TransactionsDateRangeResponse response = new TransactionsDateRangeResponse();
    Status responseStatus = new Status();
    responseStatus.setCode(MiddlewareConstants.SUCCESS_CODE);
    response.setStatus(responseStatus);

    TransactionsDateRangeDto transactionsByDateRangeToReturn = new TransactionsDateRangeDto();

    // account list
    AccountListDto accountListDto = new AccountListDto();
    accountListDto.setAccountID(accountId);

    // statement records
    List<AccountTransactionListDto> statementRecords = new ArrayList<>();
    AccountTransactionListDto accountTransactionListDto = new AccountTransactionListDto();
    accountTransactionListDto.setAmount("10");
    statementRecords.add(accountTransactionListDto);

    transactionsByDateRangeToReturn.setStatementRecords(statementRecords);
    transactionsByDateRangeToReturn.setAccountDetails(accountListDto);
    response.setContent(transactionsByDateRangeToReturn);

    given(feignClient.getTransactionsByDateRange(any(SignOnRequestTransactionDateRange.class))).willReturn(response);
    given(nicknameService.populateDataWithNickname(accountListDto, customerKey)).willReturn(accountListDto);
    given(nicknameService.populateDataListWithNickname(statementRecords, customerKey))
            .willReturn(statementRecords);

    // when
    TransactionsDateRangeDto transactionsByDateRange = accountCommunicator
            .getTransactionsByDateRange(accountId, startDate, endDate, customerKey);

    // then
    Data requestDataToCheck = new Data();
    requestDataToCheck.setAccountID(accountId);
    requestDataToCheck.setOutputType(MiddlewareConstants.JSON_OUTPUT_TYPE);

    ArgumentCaptor<SignOnRequestTransactionDateRange> request = ArgumentCaptor.forClass(SignOnRequestTransactionDateRange.class);
    verify(feignClient).getTransactionsByDateRange(request.capture());
    assertEquals(requestDataToCheck.getAccountID(), request.getValue().getData().getAccountID());
    assertEquals(requestDataToCheck.getOutputType(), request.getValue().getData().getOutputType());
    assertEquals(accountListDto, transactionsByDateRange.getAccountDetails());
    assertEquals(statementRecords, transactionsByDateRange.getStatementRecords());

    verify(nicknameService, times(1)).populateDataWithNickname(accountListDto, customerKey);
    verify(nicknameService, times(1)).populateDataListWithNickname(statementRecords, customerKey);
  }

  @Test
  void shouldntGetTransactionsByDateRange() {
    // given
    String startDate = "2020-01-01";
    String endDate = "2020-02-01";
    given(feignClient.getTransactionsByDateRange(any(SignOnRequestTransactionDateRange.class))).willReturn(null);

    // when
    // then
    assertThrows(IllegalArgumentException.class, () -> {
      accountCommunicator.getTransactionsByDateRange(accountId, startDate, endDate, customerKey);
    }, "Invalid response");
  }

  @Test
  void shouldValidateResponse() {
    // given
    Status responseStatus = new Status();
    responseStatus.setCode(MiddlewareConstants.SUCCESS_CODE);

    // when
    boolean isValidated = AccountCommunicatorImpl.validateResponse(responseStatus, accountId);

    // then
    assertTrue(isValidated);
  }

  @Test
  void shouldntValidateResponse_withNullResponseCode() {
    // given
    Status responseStatus = new Status(); // no status code
    responseStatus.setStatusMessage("An error occurred");

    // when
    // then
    assertThrows(RuntimeException.class, () -> {
      AccountCommunicatorImpl.validateResponse(responseStatus, accountId);
    }, responseStatus.getStatusMessage());
  }

  @Test
  void shouldntValidateResponse_withNullStatus() {
    // given

    // when
    // then
    assertThrows(RuntimeException.class, () -> {
      AccountCommunicatorImpl.validateResponse(null, accountId);
    });
  }
}
