package com.zand.service;

import com.zand.service.dto.AccountSummaryDto;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

class AccountServiceTest {

  @Mock
  NicknameService nicknameService;

  AccountServiceImpl accountService;


  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);
    accountService = new AccountServiceImpl(nicknameService);
  }

  @Test
  void shouldSaveAccountMetadata() {
    UUID customerKey = UUID.randomUUID();
    AccountSummaryDto account = new AccountSummaryDto();
    account.setNickname("nicknameTest");

    accountService.saveAccountMetadata(account, customerKey);

    verify(nicknameService, times(1)).save(account, customerKey);
  }
}
