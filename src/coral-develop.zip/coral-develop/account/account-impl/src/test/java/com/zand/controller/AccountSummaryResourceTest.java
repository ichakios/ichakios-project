package com.zand.controller;

import com.zand.AccountApplicationTest;
import com.zand.Feature;
import com.zand.FeaturePermission;
import com.zand.Permission;
import com.zand.UserAccessManagementService;
import com.zand.communicator.AccountCommunicator;
import com.zand.config.TestWebSecurityConfig;
import com.zand.ex.InconsistentDbContentException;
import com.zand.ex.InvalidIdentifierException;
import com.zand.service.AccountService;
import com.zand.web.UserAccessManagementFilter;
import com.zand.web.rest.AccountSummaryResourceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.security.Principal;
import java.util.UUID;
import java.util.function.BiPredicate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

@SpringBootTest(classes = AccountApplicationTest.class, webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ContextConfiguration(classes = {
        AccountSummaryResourceImpl.class,
        TestWebSecurityConfig.class,
})
class AccountSummaryResourceTest {

  public static final String USER = "user";
  protected BiPredicate<String, String> accessController = (f, p) -> false; // Changed in each test
  @MockBean
  UserAccessManagementService userAccessManagementService;
  MockMvc mockMvc;
  UUID customerKey;
  String accountId = "1";
  @MockBean
  private AccountService accountService;
  @MockBean
  private AccountCommunicator accountCommunicator;
  @Mock
  private Principal principal;
  @Autowired
  private WebApplicationContext wac;

  @BeforeEach
  void setUp() throws InconsistentDbContentException, InvalidIdentifierException {
    this.mockMvc = MockMvcBuilders
            .webAppContextSetup(this.wac)
            .apply(SecurityMockMvcConfigurers
                    .springSecurity()) //will perform all of the initial setup to integrate Spring Security with Spring MVC Test
            .addFilters(new UserAccessManagementFilter())
            .build();

    customerKey = UUID.randomUUID();
    // given


    Mockito.doAnswer(invocation -> {
      FeaturePermission argument = invocation.getArgument(2, FeaturePermission.class);
      return this.accessController.test(argument.feature, argument.permission);
    })
            .when(this.userAccessManagementService)
            .hasAccess(Mockito.anyLong(), Mockito.anyLong(), any(FeaturePermission.class));
  }

  @Test
  void shouldGetAccountSummary() throws Exception {
    String clientId = "1";
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("id", clientId)
                    .with(httpBasic(USER, USER))
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.OK.value(), response.getStatus());
    verify(accountCommunicator, times(1)).getAccountSummary(clientId, customerKey);
  }

  @Test
  void shouldSaveAccountMetadata() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.WRITE.getPermissionCode());

    MockHttpServletResponse response = this.mockMvc
            .perform(put("/api/v1/accounts")
                    .queryParam("customer", customerKey.toString())
                    .with(httpBasic(USER, USER))
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.OK.value(), response.getStatus());
    verify(accountService, times(1)).saveAccountMetadata(any(), any());
  }

  @Test
  void shouldntSaveAccountMetadata() throws Exception {
    accessController = (f, p) -> false;

    MockHttpServletResponse response = this.mockMvc.perform(
            put("/api/v1/accounts")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{}"))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldDeleteAccountNickname() throws Exception {
    String accountId = "1";
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.WRITE.getPermissionCode());

    MockHttpServletResponse response = mockMvc
            .perform(delete("/api/v1/accounts/1/nickname")
                    .queryParam("customer", customerKey.toString())
                    .with(httpBasic(USER, USER))
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.OK.value(), response.getStatus());
    verify(accountService, times(1)).deleteAccountNickname(accountId, customerKey);
  }

  @Test
  void shoudntDeleteAccountNickname() throws Exception {
    MockHttpServletResponse response = mockMvc
            .perform(delete("/api/v1/accounts/1/nickname")
                    .queryParam("customer", customerKey.toString())
                    .with(httpBasic(USER, USER))
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldGetAccountDetailsWithTransactions() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    int noOfLastTrx = 1;
    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/transactions")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("noOfLastTrx", Integer.toString(noOfLastTrx))
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.OK.value(), response.getStatus());
    verify(accountCommunicator, times(1))
            .getAccountDetailsWithTransactions(accountId, noOfLastTrx, customerKey);
  }

  @Test
  void shouldntGetAccountDetailsWithTransactions() throws Exception {
    int noOfLastTrx = 1;
    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/transactions")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("noOfLastTrx", Integer.toString(noOfLastTrx))
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldGetBalance() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/balance")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountId", accountId)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.OK.value(), response.getStatus());
    verify(accountCommunicator, times(1))
            .getBalanceWithNickname(accountId, customerKey);
  }

  @Test
  void shouldntGetBalance() throws Exception {
    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/balance")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountId", accountId)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldGetTransactionListCorporate() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    String startDate = "2020-01-01";
    String endDate = "2020-02-01";

    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/transaction-list")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("startDate", startDate)
                    .queryParam("endDate", endDate)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.OK.value(), response.getStatus());
    verify(accountCommunicator, times(1))
            .getTransactionListCorporate(accountId, startDate, endDate);
  }

  @Test
  void shouldntGetTransactionListCorporate() throws Exception {

    String startDate = "2020-01-01";
    String endDate = "2020-02-01";

    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/transaction-list")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("startDate", startDate)
                    .queryParam("endDate", endDate)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldGetCorporateAccountDetail() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    String iban = "aaa-bbb";

    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/details")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountId", accountId)
                    .queryParam("iban", iban)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.OK.value(), response.getStatus());
    verify(accountCommunicator, times(1))
            .getCorporateAccountDetail(accountId, iban, customerKey);
  }

  @Test
  void shouldntGetCorporateAccountDetail() throws Exception {

    String iban = "aaa-bbb";

    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/details")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountId", accountId)
                    .queryParam("iban", iban)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldGetAllAccounts() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    String iban = "aaa-bbb";
    String mobileNo = "mobileNo";

    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/account-list")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountId", accountId)
                    .queryParam("iban", iban)
                    .queryParam("mobileNo", mobileNo)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.OK.value(), response.getStatus());
    verify(accountCommunicator, times(1))
            .getAllAccounts(accountId, iban, mobileNo, customerKey);
  }

  @Test
  void shouldntGetAllAccounts() throws Exception {

    String iban = "aaa-bbb";
    String mobileNo = "mobileNo";

    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/account-list")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountId", accountId)
                    .queryParam("iban", iban)
                    .queryParam("mobileNo", mobileNo)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldGetTransactionsByDateRange() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    String fromDate = "2020-01-01";
    String toDate = "2020-02-01";

    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/transactions/date-range")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("fromDate", fromDate)
                    .queryParam("toDate", toDate)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.OK.value(), response.getStatus());
    verify(accountCommunicator, times(1))
            .getTransactionsByDateRange(accountId, fromDate, toDate, customerKey);
  }

  @Test
  void shouldntGetTransactionsByDateRange() throws Exception {

    String fromDate = "2020-01-01";
    String toDate = "2020-02-01";

    MockHttpServletResponse response = mockMvc
            .perform(get("/api/v1/accounts/transactions/date-range")
                    .with(httpBasic(USER, USER))
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("fromDate", fromDate)
                    .queryParam("toDate", toDate)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .principal(principal))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }
}
