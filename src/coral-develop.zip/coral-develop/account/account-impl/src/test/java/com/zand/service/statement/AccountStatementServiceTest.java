package com.zand.service.statement;

import com.zand.BankMaster;
import com.zand.client.AccountStatementClient;
import com.zand.config.MiddlewareConstants;
import com.zand.request.Data;
import com.zand.request.SignOnRequestStatement;
import com.zand.service.NicknameService;
import com.zand.service.dto.StatementDto;
import com.zand.service.validate.StatementResponse;
import com.zand.service.validate.Status;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

 class AccountStatementServiceTest {

  AccountStatementServiceImpl accountStatementService;

  @Mock
  NicknameService nicknameService;

  @Mock
  StatementFeign statementFeign;

  @Mock
  BankMaster bankMaster;

  @Mock
  AccountStatementClient feignClient;

  UUID customerKey = UUID.randomUUID();
  String accountId = "1";
  String clientId = "1";
  String startDate = "2020-01-01";
  String startDateOffseted = "2020-01-01T00:00+04:00";
  String startDateOffsetedforMonthly = "2020-01-01T23:59:59.999999999+04:00";
  String endDate = "2020-02-01";
  String endDateOffseted = "2020-02-01T23:59:59.999999999+04:00";
  Double trxRefNo = 2D;

  StatementResponse errorStatementResponse = new StatementResponse();
  StatementResponse successStatementResponse = new StatementResponse();


  private static final String ERROR_MESSAGE = "error";

  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);
    accountStatementService = new AccountStatementServiceImpl(nicknameService, statementFeign, bankMaster);
    given(statementFeign.getClient()).willReturn(feignClient);
    given(bankMaster.getDefaultTimezone()).willReturn("Asia/Dubai");

    Status status = new Status();
    status.setStatusMessage(ERROR_MESSAGE);
    status.setCode("wrong code");
    errorStatementResponse.setStatus(status);

    Status responseStatus = new Status();
    responseStatus.setCode(MiddlewareConstants.SUCCESS_CODE);
    successStatementResponse.setStatus(responseStatus);
  }

  @Test
  void shouldGetMonthlyStatements() {
    // given
    StatementDto statementDtoToReturn = new StatementDto();
    statementDtoToReturn.setPdfFileName("test");
    successStatementResponse.setContent(statementDtoToReturn);

    given(feignClient.getMonthlyStatements(any(SignOnRequestStatement.class))).willReturn(successStatementResponse);
    given(nicknameService.populateDataWithNickname(statementDtoToReturn, customerKey, accountId)).willReturn(statementDtoToReturn);

    // when
    StatementDto statementDto = accountStatementService.getMonthlyStatements(accountId, startDate, customerKey);

    // then
    Data data = new Data();
    data.setAccountID(accountId);
    data.setFromDate(startDateOffsetedforMonthly);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);

    ArgumentCaptor<SignOnRequestStatement> request = ArgumentCaptor.forClass(SignOnRequestStatement.class);
    verify(feignClient).getMonthlyStatements(request.capture());
    assertEquals(data.getAccountID(), request.getValue().getData().getAccountID());
    assertEquals(data.getOutputType(), request.getValue().getData().getOutputType());
    assertEquals(data.getFromDate(), request.getValue().getData().getFromDate());
    assertEquals(successStatementResponse.getContent(), statementDto);
  }

  @Test
  void shouldntGetMonthlyStatements() {
    // given
    given(feignClient.getMonthlyStatements(any(SignOnRequestStatement.class))).willReturn(errorStatementResponse);

    // when
    // then
    assertThrows(RuntimeException.class, () -> {
      accountStatementService.getMonthlyStatements(accountId, startDate, customerKey);
    }, ERROR_MESSAGE);
  }

  @Test
  void shouldGetStatementsByDateRange() {
    // given
    StatementDto statementDtoToReturn = new StatementDto();
    statementDtoToReturn.setPdfFileName("test");
    successStatementResponse.setContent(statementDtoToReturn);

    given(feignClient.geStatementByDateRange(any(SignOnRequestStatement.class))).willReturn(successStatementResponse);
    given(nicknameService.populateDataWithNickname(statementDtoToReturn, customerKey, accountId)).willReturn(statementDtoToReturn);

    // when
    StatementDto statementDto = accountStatementService.getStatementsByDateRange(accountId, startDate, endDate, customerKey);

    // then
    Data data = new Data();
    data.setAccountID(accountId);
    data.setFromDate(startDateOffseted);
    data.setToDate(endDateOffseted);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);

    ArgumentCaptor<SignOnRequestStatement> request = ArgumentCaptor.forClass(SignOnRequestStatement.class);
    verify(feignClient).geStatementByDateRange(request.capture());
    assertEquals(data.getAccountID(), request.getValue().getData().getAccountID());
    assertEquals(data.getOutputType(), request.getValue().getData().getOutputType());
    assertEquals(data.getFromDate(), request.getValue().getData().getFromDate());
    assertEquals(data.getToDate(), request.getValue().getData().getToDate());
    assertEquals(successStatementResponse.getContent(), statementDto);
  }

  @Test
  void shouldntGetStatementsByDateRange() {
    // given
    given(feignClient.geStatementByDateRange(any(SignOnRequestStatement.class))).willReturn(errorStatementResponse);

    // when
    // then
    assertThrows(RuntimeException.class, () -> {
      accountStatementService.getStatementsByDateRange(accountId, startDate, endDate, customerKey);
    }, ERROR_MESSAGE);
  }

  @Test
  void shouldGetDebitAdvice() {
    // given
    StatementDto statementDtoToReturn = new StatementDto();
    statementDtoToReturn.setPdfFileName("test");
    successStatementResponse.setContent(statementDtoToReturn);

    given(feignClient.getDebitAdvice(any(SignOnRequestStatement.class))).willReturn(successStatementResponse);
    given(nicknameService.populateDataWithNickname(statementDtoToReturn, customerKey, trxRefNo.toString())).willReturn(statementDtoToReturn);

    // when
    StatementDto statementDto = accountStatementService.getDebitAdvice(startDate, trxRefNo, customerKey);

    // then
    Data data = new Data();
    data.setWorkingDate(startDate);
    data.setTrxRefNo(trxRefNo);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);

    ArgumentCaptor<SignOnRequestStatement> request = ArgumentCaptor.forClass(SignOnRequestStatement.class);
    verify(feignClient).getDebitAdvice(request.capture());
    assertEquals(data.getWorkingDate(), request.getValue().getData().getWorkingDate());
    assertEquals(data.getOutputType(), request.getValue().getData().getOutputType());
    assertEquals(data.getTrxRefNo(), request.getValue().getData().getTrxRefNo());
    assertEquals(successStatementResponse.getContent(), statementDto);
  }

  @Test
  void shouldntGetDebitAdvice() {
    // given
    given(feignClient.getDebitAdvice(any(SignOnRequestStatement.class))).willReturn(errorStatementResponse);

    // when
    // then
    assertThrows(RuntimeException.class, () -> {
      accountStatementService.getDebitAdvice(startDate, trxRefNo, customerKey);
    }, ERROR_MESSAGE);
  }

  @Test
  void shouldGetCreditAdvice() {
    // given
    StatementDto statementDtoToReturn = new StatementDto();
    statementDtoToReturn.setPdfFileName("test");
    successStatementResponse.setContent(statementDtoToReturn);

    given(feignClient.getCreditAdvice(any(SignOnRequestStatement.class))).willReturn(successStatementResponse);
    given(nicknameService.populateDataWithNickname(statementDtoToReturn, customerKey, trxRefNo.toString())).willReturn(statementDtoToReturn);

    // when
    StatementDto statementDto = accountStatementService.getCreditAdvice(startDate, trxRefNo, customerKey);

    // then
    Data data = new Data();
    data.setWorkingDate(startDate);
    data.setTrxRefNo(trxRefNo);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);

    ArgumentCaptor<SignOnRequestStatement> request = ArgumentCaptor.forClass(SignOnRequestStatement.class);
    verify(feignClient).getCreditAdvice(request.capture());
    assertEquals(data.getWorkingDate(), request.getValue().getData().getWorkingDate());
    assertEquals(data.getOutputType(), request.getValue().getData().getOutputType());
    assertEquals(data.getTrxRefNo(), request.getValue().getData().getTrxRefNo());
    assertEquals(successStatementResponse.getContent(), statementDto);
  }

  @Test
  void shouldntGetCreditAdvice() {
    // given
    given(feignClient.getCreditAdvice(any(SignOnRequestStatement.class))).willReturn(errorStatementResponse);

    // when
    // then
    assertThrows(RuntimeException.class, () -> {
      accountStatementService.getCreditAdvice(startDate, trxRefNo, customerKey);
    }, ERROR_MESSAGE);
  }

  @Test
  void shouldGetVatAdvice() {
    // given
    StatementDto statementDtoToReturn = new StatementDto();
    statementDtoToReturn.setPdfFileName("test");
    successStatementResponse.setContent(statementDtoToReturn);

    given(feignClient.getVatAdvice(any(SignOnRequestStatement.class))).willReturn(successStatementResponse);
    given(nicknameService.populateDataWithNickname(statementDtoToReturn, customerKey, trxRefNo.toString())).willReturn(statementDtoToReturn);

    // when
    StatementDto statementDto = accountStatementService.getVatAdvice(startDate, trxRefNo, customerKey);

    // then
    Data data = new Data();
    data.setWorkingDate(startDate);
    data.setTrxRefNo(trxRefNo);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);

    ArgumentCaptor<SignOnRequestStatement> request = ArgumentCaptor.forClass(SignOnRequestStatement.class);
    verify(feignClient).getVatAdvice(request.capture());
    assertEquals(data.getWorkingDate(), request.getValue().getData().getWorkingDate());
    assertEquals(data.getOutputType(), request.getValue().getData().getOutputType());
    assertEquals(data.getTrxRefNo(), request.getValue().getData().getTrxRefNo());
    assertEquals(successStatementResponse.getContent(), statementDto);
  }

  @Test
  void shouldntGetVatAdvice() {
    // given
    given(feignClient.getVatAdvice(any(SignOnRequestStatement.class))).willReturn(errorStatementResponse);

    // when
    // then
    assertThrows(RuntimeException.class, () -> {
      accountStatementService.getVatAdvice(startDate, trxRefNo, customerKey);
    }, ERROR_MESSAGE);
  }

  @Test
  void shouldGetMonthlyVatAdvice() {
    // given
    StatementDto statementDtoToReturn = new StatementDto();
    statementDtoToReturn.setPdfFileName("test");
    successStatementResponse.setContent(statementDtoToReturn);

    given(feignClient.getMonthlyVatAdvice(any(SignOnRequestStatement.class))).willReturn(successStatementResponse);
    given(nicknameService.populateDataWithNickname(statementDtoToReturn, customerKey, accountId)).willReturn(statementDtoToReturn);

    // when
    StatementDto statementDto = accountStatementService.getMonthlyVatAdvice(accountId, startDate, customerKey);

    // then
    Data data = new Data();
    data.setAccountID(accountId);
    data.setFromDate(startDateOffseted);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);

    ArgumentCaptor<SignOnRequestStatement> request = ArgumentCaptor.forClass(SignOnRequestStatement.class);
    verify(feignClient).getMonthlyVatAdvice(request.capture());
    assertEquals(data.getAccountID(), request.getValue().getData().getAccountID());
    assertEquals(data.getOutputType(), request.getValue().getData().getOutputType());
    assertEquals(data.getFromDate(), request.getValue().getData().getFromDate());
    assertEquals(successStatementResponse.getContent(), statementDto);
  }

  @Test
  void shouldntGetMonthlyVatAdvice() {
    // given
    given(feignClient.getMonthlyVatAdvice(any(SignOnRequestStatement.class))).willReturn(errorStatementResponse);

    // when
    // then
    assertThrows(RuntimeException.class, () -> {
      accountStatementService.getMonthlyVatAdvice(accountId, startDate, customerKey);
    }, ERROR_MESSAGE);
  }

  @Test
  void shouldCheckResponseStatus() {
    // given
    // when
    // then
    assertDoesNotThrow(() -> {
      accountStatementService.checkResponseStatus(successStatementResponse);
    });
  }

  @Test
  void shouldntCheckResponseStatus_withEmptyResponse() {
    // given
    // when
    // then
    assertThrows(IllegalArgumentException.class, () -> {
      accountStatementService.checkResponseStatus(null);
    }, "Invalid response");
  }

  @Test
  void shouldntCheckResponseStatus_withBadResponseCode() {
    // given
    // when
    // then
    assertThrows(RuntimeException.class, () -> {
      accountStatementService.checkResponseStatus(errorStatementResponse);
    }, ERROR_MESSAGE);
  }
}
