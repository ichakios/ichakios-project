package com.zand.validation;

import com.zand.client.AccountStatementClient;
import com.zand.request.Data;
import com.zand.request.SignOnRequestStatement;
import com.zand.service.validate.SignOnRq;
import com.zand.service.validate.StatementResponse;
import com.zand.config.MiddlewareConstants;
import com.zand.config.ZandClientBuilder;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

import static com.zand.request.CommonRequest.getCommonSignOnRq;

@Tag(MiddlewareConstants.TAG)
public class TestForStatements {

  final AccountStatementClient client = ZandClientBuilder.get().target(AccountStatementClient.class, MiddlewareConstants.URL);

  @Test
  public void testForMonthlyStatement() {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    OffsetDateTime fromOffsetDateTime = OffsetDateTime.of(
            LocalDate.parse("2019-12-24").atTime(LocalTime.MIN), ZoneOffset.ofHours(+4));
    data.setFromDate(fromOffsetDateTime.toString());
    data.setAccountID("0130000000010901");
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    request.setData(data);
    StatementResponse response = client.getMonthlyStatements(request);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  @Test
  public void testForDateRangeStatement() {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setAccountID("0150100008267101");
    OffsetDateTime fromOffsetDateTime = OffsetDateTime.of(
            LocalDate.parse("2019-03-18").atTime(LocalTime.MIN), ZoneOffset.ofHours(+4));
    data.setFromDate(fromOffsetDateTime.toString());
    OffsetDateTime toOffsetDateTime = OffsetDateTime.of(
            LocalDate.parse("2020-03-18").atTime(LocalTime.MAX), ZoneOffset.ofHours(+4));
    data.setToDate(toOffsetDateTime.toString());
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    request.setData(data);
    StatementResponse response = client.geStatementByDateRange(request);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  @Test
  public void testForDebitAdvice() {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setWorkingDate("2020-01-23T13:52:33.106Z");
    data.setTrxRefNo(368822863D);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    request.setData(data);
    StatementResponse response = client.getDebitAdvice(request);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  @Test
  public void testForCreditAdvice() {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setWorkingDate("2020-02-03T10:22:21.839Z");
    data.setTrxRefNo(840000684D);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    request.setData(data);
    StatementResponse response = client.getCreditAdvice(request);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  @Test
  public void testForVatAdvice() {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setWorkingDate("2020-01-22T10:22:21.839Z");
    data.setTrxRefNo(115053018D);
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    request.setData(data);
    StatementResponse response = client.getVatAdvice(request);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }

  @Test
  public void testForMonthlyVatAdvice() {
    SignOnRequestStatement request = new SignOnRequestStatement();
    SignOnRq signOnRq = getCommonSignOnRq();
    request.setSignOnRq(signOnRq);
    Data data = new Data();
    data.setAccountID("0130000000000403");
    OffsetDateTime fromOffsetDateTime = OffsetDateTime.of(
            LocalDate.parse("2019-10-09").atTime(LocalTime.MIN), ZoneOffset.ofHours(+4));
    data.setFromDate(fromOffsetDateTime.toString());
    data.setOutputType(MiddlewareConstants.PDF_OUTPUT_TYPE);
    request.setData(data);
    StatementResponse response = client.getMonthlyVatAdvice(request);
    Assertions.assertEquals(MiddlewareConstants.SUCCESS_CODE, response.getStatus().getCode());
  }
}
