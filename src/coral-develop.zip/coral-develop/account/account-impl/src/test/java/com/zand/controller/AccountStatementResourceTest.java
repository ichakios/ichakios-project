package com.zand.controller;

import com.zand.AccountApplicationTest;
import com.zand.Feature;
import com.zand.FeaturePermission;
import com.zand.Permission;
import com.zand.UserAccessManagementService;
import com.zand.config.TestWebSecurityConfig;
import com.zand.service.AccountStatementService;
import com.zand.web.UserAccessManagementFilter;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.security.Principal;
import java.util.UUID;
import java.util.function.BiPredicate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@SpringBootTest(classes = AccountApplicationTest.class, webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ContextConfiguration(classes = {
        AccountStatementResourceTest.class,
        TestWebSecurityConfig.class,
})
class AccountStatementResourceTest {

  public static final String USER = "user";
  protected BiPredicate<String, String> accessController = (f, p) -> false; // Changed in each test
  @MockBean
  UserAccessManagementService userAccessManagementService;
  MockMvc mockMvc;

  UUID customerKey;
  String accountId = "1";
  String fromDate = "2020-01-01";
  String toDate = "2020-01-01";
  @MockBean
  private AccountStatementService accountStatementService;
  @Mock
  private Principal principal;
  @Autowired
  private WebApplicationContext wac;

  @BeforeEach
  void setUp() {
    this.mockMvc = MockMvcBuilders
            .webAppContextSetup(this.wac)
            .apply(SecurityMockMvcConfigurers
                    .springSecurity()) //will perform all of the initial setup to integrate Spring Security with Spring MVC Test
            .addFilters(new UserAccessManagementFilter())
            .build();

    customerKey = UUID.randomUUID();
    // given


    Mockito.doAnswer(invocation -> {
      FeaturePermission argument = invocation.getArgument(2, FeaturePermission.class);
      return this.accessController.test(argument.feature, argument.permission);
    })
            .when(this.userAccessManagementService)
            .hasAccess(Mockito.anyLong(), Mockito.anyLong(), any(FeaturePermission.class));
  }

  @Test
  void shouldGetMonthlyStatements() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/monthly")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("fromDate", fromDate)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    verify(accountStatementService, times(1))
            .getMonthlyStatements(accountId, fromDate, customerKey);
  }

  @Test
  void shouldntGetMonthlyStatements() throws Exception {

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/monthly")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("fromDate", fromDate)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldGetStatementsByDateRange() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/date-range")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("fromDate", fromDate)
                    .queryParam("toDate", toDate)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    verify(accountStatementService, times(1))
            .getStatementsByDateRange(accountId, fromDate, toDate, customerKey);
  }

  @Test
  void shouldntGetStatementsByDateRange() throws Exception {

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/date-range")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("fromDate", fromDate)
                    .queryParam("toDate", toDate)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());

  }

  @Test
  void shouldGetDebitAdvice() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    Double trxRefNo = 5D;
    String workingDate = "2020-03-01";

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/debit-advice")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("workingDate", workingDate)
                    .queryParam("trxRefNo", trxRefNo.toString())
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    verify(accountStatementService, times(1))
            .getDebitAdvice(workingDate, trxRefNo, customerKey);
  }

  @Test
  void shouldntGetDebitAdvice() throws Exception {

    Double trxRefNo = 5D;
    String workingDate = "2020-03-01";

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/debit-advice")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("workingDate", workingDate)
                    .queryParam("trxRefNo", trxRefNo.toString())
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldGetCreditAdvice() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    Double trxRefNo = 5D;
    String workingDate = "2020-03-01";

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/credit-advice")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("workingDate", workingDate)
                    .queryParam("trxRefNo", trxRefNo.toString())
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    verify(accountStatementService, times(1))
            .getCreditAdvice(workingDate, trxRefNo, customerKey);
  }

  @Test
  void shouldntGetCreditAdvice() throws Exception {
    Double trxRefNo = 5D;
    String workingDate = "2020-03-01";

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/credit-advice")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("workingDate", workingDate)
                    .queryParam("trxRefNo", trxRefNo.toString())
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldGetVatAdvice() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    Double trxRefNo = 5D;
    String workingDate = "2020-03-01";

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/vat-advice")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("workingDate", workingDate)
                    .queryParam("trxRefNo", trxRefNo.toString())
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    verify(accountStatementService, times(1))
            .getVatAdvice(workingDate, trxRefNo, customerKey);
  }

  @Test
  void shouldntGetVatAdvice() throws Exception {
    Double trxRefNo = 5D;
    String workingDate = "2020-03-01";

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/vat-advice")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("workingDate", workingDate)
                    .queryParam("trxRefNo", trxRefNo.toString())
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

  @Test
  void shouldGetMonthlyVatAdvice() throws Exception {
    this.accessController = (f, p) -> f.equals(Feature.ACCOUNT.getFeatureCode()) && p.equals(
            Permission.READ.getPermissionCode());
    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/vat-advice/monthly")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("fromDate", fromDate)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    verify(accountStatementService, times(1))
            .getMonthlyVatAdvice(accountId, fromDate, customerKey);
  }

  @Test
  void shouldntGetMonthlyVatAdvice() throws Exception {

    MockHttpServletResponse response = mockMvc
            .perform(post("/api/v1/accounts/statements/vat-advice/monthly")
                    .queryParam("customer", customerKey.toString())
                    .queryParam("accountID", accountId)
                    .queryParam("fromDate", fromDate)
                    .content("{}")
                    .contentType(MediaType.APPLICATION_JSON)
                    .with(httpBasic(USER, USER)))
            .andReturn()
            .getResponse();

    Assertions.assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
  }

}
