![coral ci](https://github.com/eradah-capital/coral/workflows/coral%20ci/badge.svg?branch=develop) [![coral-backend](https://sonarcloud.io/api/project_badges/measure?project=com.zand%3Acoral-root&metric=alert_status&token=48e8d9300a781a778a10c136c0efc60859c03c1d)](https://sonarcloud.io/dashboard?id=com.zand%3Acoral-root) [![coral-frontend](https://sonarcloud.io/api/project_badges/measure?project=coral-frontend&metric=alert_status&token=cf26fd7ca7741a1fedf2f11b5a6ba8fc25020a44)](https://sonarcloud.io/dashboard?id=coral-frontend) [![Security Rating](https://sonarcloud.io/api/project_badges/measure?project=com.zand%3Acoral-root&metric=security_rating&token=48e8d9300a781a778a10c136c0efc60859c03c1d)](https://sonarcloud.io/dashboard?id=com.zand%3Acoral-root) [![Security Rating](https://sonarcloud.io/api/project_badges/measure?project=coral-frontend&metric=security_rating&token=cf26fd7ca7741a1fedf2f11b5a6ba8fc25020a44)](https://sonarcloud.io/dashboard?id=coral-frontend)

# This is the official code base for the corporate portal.

## Structure

It is composed of several maven modules:
- **module-skeleton**: for scaffolding. If you need to create an additional module, use this one as a template. It is made of two submodules:
    - intf: should contain only interfaces to be used by other modules to interact with the components defined in `impl` module
    - impl: contains the actual implementations
- **aggregate**: to generate a single code coverage report from the other modules.
- **common**: contains all utility code that can be reused in every submodules.
- **payment**: contains the code related to the payment service. It uses [Camunda](https://camunda.com/) as workflow engine with a built-in generic BPMN model.
- **app-server**: this is the monolithic application generated with JHipster.It does not contains any front-end client (more info in [app/.yo-rc.json](app/.yo-rc.json)).
- **middleware-http-client**: Java client stub for WAQFE APIs.
- **user-access-management**: contains all the logic for user authentication and authorizations.
- **workflow-engine**: contains service to set up and trigger approval workflow processes.
- **client-frontend**: contains the actual frontend application. This is where frontend code should go.
- **swagger-ui**: to visualize and interact with the API’s resources. Simply open the file in your web browser.
- **nickname**: to be able to add nicknames to your entities. Nickname is an alias for the entity, and can be defined at customers's or user's scope.

## Prerequisites

In order to build the server, you will need:
- [Java JDK](https://www.oracle.com/java/) >= 11
- Latest stable [Apache Maven](http://maven.apache.org/)

To run the server or its tests you will need:
- [Docker](https://www.docker.com/) (required for running Keycloak).

To build the UI you will also need
- [nodejs](https://nodejs.org/en/download/) which includes [npm](https://www.npmjs.com/).


## Compilation

To compile the whole project without the UI (`client-frontend`):
```mvn clean install```

To compile with the UI (`client-frontend`), use maven profile `full`:
```mvn clean install -Pci```

## Development

- The `docker` service should be running (otherwise the following step will fail).
- Use `docker-compose --file app-server/src/main/docker/keycloak.yml up` to start Keycloak's server or edit and use `keycloak.sh` file.
- To launch the server with your IDE, run the class `PortalApp` from `app-server` with your IDE or go to `app-server/` and run `./mvnw`
- To launch the UI, go to `client-frontend/` and run `npm run dev` (you might need to run `npm install` beforehand).
- To launch the Swagger UI, simply open `swagger-ui/index.html` from to root of the project in your browser.

### Build frontend before API for production

Run `npm run build` at the project root

Each frontend build will be available in the `/app-server/src/main/resources/static` folder.
- `client-frontend` in `/app-server/src/main/resources/static/app`

## Swagger UI 

Swagger UI is only used for development purpose.
