package com.zand.config;

import com.zand.keycloak.Driver;
import com.zand.keycloak.Initializer;
import io.github.jhipster.config.JHipsterConstants;
import net.logstash.logback.encoder.org.apache.commons.lang3.exception.ExceptionUtils;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import javax.ws.rs.BadRequestException;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.ProcessingException;
import java.net.ConnectException;
import java.util.List;

import static com.zand.keycloak.SecurityConfig.KEYCLOAK_CLIENT_SECRET_QUALIFIER;
import static com.zand.keycloak.SecurityConfig.KEYCLOAK_URL_QUALIFIER;

@Configuration
public class KeycloakConfiguration {

  public static final String KEYCLOAK_SETUP_LOGIN_PROPERTY_NAME = "keycloak.setup.login";
  public static final String KEYCLOAK_SETUP_PASSWORD_PROPERTY_NAME = "keycloak.setup.password";

  @Autowired
  protected Environment environment;

  @Bean
  @Qualifier(KEYCLOAK_URL_QUALIFIER)
  public String keycloakUrl() {
    return this.environment.getRequiredProperty("keycloak.url");
  }

  @Bean
  @Qualifier(KEYCLOAK_CLIENT_SECRET_QUALIFIER)
  public String keycloakSecret() {
    return this.environment.getRequiredProperty("keycloak.client-secret");
  }

  protected boolean isDevEnvironment() {
    for (String profileName : this.environment.getActiveProfiles()) {
      if (profileName.equals(JHipsterConstants.SPRING_PROFILE_DEVELOPMENT)) {
        return true;
      }
    }
    return false;
  }

  protected void setupClient(Driver driver) {
    String adminLogin = this.environment.getProperty("keycloak.setup.login");
    String adminPassword = this.environment.getProperty("keycloak.setup.password");
    if (adminLogin == null) {
      throw new RuntimeException("Could not setup Keycloak UAM client, no admin login provided in application property '" + KEYCLOAK_SETUP_LOGIN_PROPERTY_NAME + "'.");
    }
    if (adminPassword == null) {
      throw new RuntimeException("Could not setup Keycloak UAM client, no admin password provided in application property '" + KEYCLOAK_SETUP_PASSWORD_PROPERTY_NAME + "'.");
    }
    Initializer.Initialization initialization = new Initializer.Initialization(
            driver.getKeycloakUrl(),
            adminLogin,
            adminPassword,
            driver.getClientSecret());
    try {
      Initializer.initializeKeycloakServer(initialization);
    } catch (ProcessingException e) {
      throw new RuntimeException("Could not setup Keycloak UAM client, are your admin credentials correct ?", e);
    }

    Keycloak keycloak = driver.createRestClient();
    List<UserRepresentation> search = keycloak.realm(Driver.MASTER_REALM).users().search(adminLogin);
    if (search.isEmpty()) {
      throw new RuntimeException("User not found " + adminLogin);
    } else if (search.size() > 1) {
      throw new RuntimeException(search.size() + " users found, expected only one with login " + adminLogin);
    }
    Driver.addRole(keycloak, adminLogin, search.get(0).getId(), Driver.MASTER_REALM, Driver.ZAND_ADMIN_ROLE);
  }

  @Bean
  public Driver establishKeycloakCommunication(
          @Qualifier(KEYCLOAK_URL_QUALIFIER) String url,
          @Qualifier(KEYCLOAK_CLIENT_SECRET_QUALIFIER) String clientSecret) {
    Driver driver = new Driver(url, clientSecret);
    try {
      driver.getAllCustomersRealms();
    } catch (Throwable e) {
      Throwable rootCause = ExceptionUtils.getRootCause(e);
      if (rootCause instanceof ConnectException) {
        if (isDevEnvironment()) {
          throw new RuntimeException("Could not connect to Keycloak server at '" + url + "'. Keycloak can be started with 'docker-compose -f app-server/src/main/docker/keycloak.yml up'", e);
        } else {
          throw new RuntimeException("Could not connect to Keycloak server at '" + url + "'.", e);
        }
      } else if (rootCause instanceof NotFoundException) {
        throw new RuntimeException("Could not communicate with Keycloak server at '" + url + "', the authentication REST API was not found. It is on http://host:port/auth on a standard installation.", e);
      } else if (rootCause instanceof BadRequestException) {
        if (isDevEnvironment()) {
          setupClient(driver);
        } else {
          throw new RuntimeException("Could not communicate with Keycloak server at '" + url + "', is the UAM client installed ?");
        }
      } else {
        throw new RuntimeException("Could not communicate with Keycloak server at '" + url + "'.", e);
      }
    }
    return driver;
  }
}
