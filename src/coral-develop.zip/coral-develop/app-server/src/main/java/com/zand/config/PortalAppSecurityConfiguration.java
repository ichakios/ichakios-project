package com.zand.config;

import com.zand.keycloak.SecurityConfig;
import com.zand.spring.FeaturePermissionMethodSecurityConfig;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.util.Arrays;
import java.util.List;

@Configuration
@Import({
        SecurityConfig.class,
        FeaturePermissionMethodSecurityConfig.class
})
public class PortalAppSecurityConfiguration {

    @Bean
    @Qualifier(SecurityConfig.SECURITY_ANT_PATTERNS_PERMIT_ALL_QUALIFIER)
    public List<String> additionalAntPatternsPermitAll() {
      return Arrays.asList(
              // Client frontend
              "/index.html",
              "/app/index.html",
              "/app/static/**/*.{js,html}",
              "/app/img/**"
      );
    }

    @Bean
    @Qualifier(SecurityConfig.SECURITY_ANT_PATTERNS_AUTHENTICATED_QUALIFIER)
    public List<String> additionalAntPatternsAuthenticated() {
      return Arrays.asList(
              "/api/**"
      );
    }
}
