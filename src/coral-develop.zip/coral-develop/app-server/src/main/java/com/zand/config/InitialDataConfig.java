package com.zand.config;

import com.zand.Feature;
import com.zand.FeaturePermission;
import com.zand.Grant;
import com.zand.Permission;
import com.zand.UserAccessManagementService;
import com.zand.UserCustomerInfo;
import com.zand.domain.ZandCustomer;
import com.zand.domain.enumeration.FacilityType;
import com.zand.domain.enumeration.PaymentType;
import com.zand.ex.ConflictException;
import com.zand.ex.InconsistentDbContentException;
import com.zand.ex.InvalidIdentifierException;
import com.zand.keycloak.KeycloakClient;
import com.zand.predicate.InRangeCondition;
import com.zand.rule.ApprovalWorkflowRule;
import com.zand.rule.AuthorityRule;
import com.zand.rule.Candidates;
import com.zand.service.AuthorityRuleService;
import com.zand.service.PaymentService;
import com.zand.service.dto.CustomerCreationDto;
import com.zand.service.dto.UserCreationDto;
import io.github.jhipster.config.JHipsterConstants;
import org.eclipse.collections.impl.list.immutable.ImmutableListFactoryImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Profile;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.zand.domain.User.fromCreationDto;

/**
 * Initial Data setup for Testing purpose.
 */
@Configuration
@Profile(JHipsterConstants.SPRING_PROFILE_DEVELOPMENT)
public class InitialDataConfig {

  private static final Logger LOGGER = LoggerFactory.getLogger(InitialDataConfig.class);

  public static final String DEFAULT_CUSTOMER_TYPE = "Default";

  public static final String CUSTOMER_CREATION_LOG = "Customers (name={},uuid={}) and users added to IDP and database.";

  public static final CustomerCreationDto EMAAR = new CustomerCreationDto("Emaar", "Emaar",
          null, DEFAULT_CUSTOMER_TYPE);
  public static final CustomerCreationDto NOON = new CustomerCreationDto("Noon", "Noon",
          null, DEFAULT_CUSTOMER_TYPE);
  public static final CustomerCreationDto ZAND = new CustomerCreationDto("Zand", "Zand",
          null, DEFAULT_CUSTOMER_TYPE);
  public static final UserCreationDto user1 = new UserCreationDto("user1", "user1@email.com",
          "user1", "John", "Doe", "+123456789");
  public static final UserCreationDto user2 = new UserCreationDto("user2", "user2@email.com",
          "user2", "Joe", "Bloggs", "+123456789");
  public static final UserCreationDto userRM1 = new UserCreationDto("rm1", "rm1@email.com",
          "rm1", "Jack", "Man", "+123456789");

  public static final String CEO = "CEO";
  public static final String CFO = "CFO";
  public static final String RELATIONSHIP_MANAGER = "RELATIONSHIP_MANAGER";
  public static final String groupA = "groupA";
  public static final String groupB = "groupB";
  public static final String groupC = "groupC";
  public static final String groupD = "groupD";

  @Autowired
  private UserAccessManagementService uam;

  @Autowired
  private AuthorityRuleService authorityRuleService;

  @Autowired
  private PaymentService paymentService;

  @Autowired
  private KeycloakClient keycloak;

  protected UUID ensureCustomerExists(CustomerCreationDto customer)
          throws InvalidIdentifierException, ConflictException {
    UUID customerKey = this.uam.getCustomerKeyOrNull(customer.getName());
    if (customerKey == null) {
      Long parentId = this.uam.getIdIfNonNull(customer.getParent());
      ZandCustomer created =
              this.uam.addCustomer(customer.getName(), customer.getDescription(), parentId, customer.getType());
      customerKey = created.getKey();
    }
    if (!this.keycloak.customerExists(customer.getName())) {
      this.keycloak.createCustomerRealm(customer.getName());
    }
    return customerKey;
  }

  protected void ensureCustomerHasUser(CustomerCreationDto customer, UUID customerKey, UserCreationDto user)
          throws InvalidIdentifierException, ConflictException, InconsistentDbContentException {
    List<UserCustomerInfo> info = this.uam.getUserInfo(user.login);
    if (info.stream().noneMatch(i -> i.getCustomer().getKey().equals(customerKey))) {
      // Add in UAM
      long customerId = this.uam.getCustomerIdFromUuid(customerKey);
      this.uam.addUserToCustomer(customerId, user.login);
    }
    if (!this.keycloak.userExists(customer.getName(), user.login)) {
      this.keycloak.addUserToCustomer(customer.getName(), fromCreationDto(user), user.password);
    }
  }

  protected static UserCreationDto createUser(String user) {
    return new UserCreationDto(user, user + "@email.com",
            user, user + ".firstName", user + ".lastName", "+123456789");
  }

  @Bean
  @DependsOn({"liquibase"})
  public void initialLoad() throws InconsistentDbContentException, InvalidIdentifierException {
    populateDevUsersAndCustomers();
    populateUserGrants();
    populateZandRule();
  }

  /**
   * Populates both keycloak and UAM with users with their roles.
   */
  protected void populateDevUsersAndCustomers() {
    try {
      UUID emaarKey = ensureCustomerExists(EMAAR);
      UUID noonKey = ensureCustomerExists(NOON);
      UUID zandKey = ensureCustomerExists(ZAND);
      ensureCustomerHasUser(EMAAR, emaarKey, user1);
      ensureCustomerHasUser(NOON, noonKey, user1);
      ensureCustomerHasUser(NOON, noonKey, user2);
      ensureCustomerHasUser(ZAND, zandKey, userRM1);

      ensureCustomerHasUser(EMAAR, emaarKey, createUser("bob"));
      ensureCustomerHasUser(EMAAR, emaarKey, createUser("peter"));
      ensureCustomerHasUser(EMAAR, emaarKey, createUser("john"));
      ensureCustomerHasUser(EMAAR, emaarKey, createUser("harry"));
      ensureCustomerHasUser(EMAAR, emaarKey, createUser("jack"));
      ensureCustomerHasUser(EMAAR, emaarKey, createUser("james"));
      ensureCustomerHasUser(EMAAR, emaarKey, createUser("oscar"));
      ensureCustomerHasUser(EMAAR, emaarKey, createUser("william"));
      ensureCustomerHasUser(EMAAR, emaarKey, createUser("george"));
      ensureCustomerHasUser(EMAAR, emaarKey, createUser("thomas"));

      long cId = this.uam.getCustomerIdFromUuid(emaarKey);
      this.uam.addRoleToCustomer(cId, CEO, "authorizer");
      this.uam.addRoleToCustomer(cId, CFO, "authorizer");
      this.uam.addRoleToCustomer(cId, groupA, "type");
      this.uam.addRoleToCustomer(cId, groupB, "releaser");
      this.uam.addRoleToCustomer(cId, groupC, "checker");
      this.uam.addRoleToCustomer(cId, groupD, "authorizer");

      long zandCustomerId = this.uam.getCustomerIdFromUuid(zandKey);
      this.uam.addRoleToCustomer(zandCustomerId, RELATIONSHIP_MANAGER, "zand_employee");

      this.uam.addRolesToUser(cId, this.uam.getValidUserId(cId, "bob"), Arrays.asList(CEO));
      this.uam.addRolesToUser(cId, this.uam.getValidUserId(cId, "peter"), Arrays.asList(CFO));

      this.uam.addRolesToUser(cId, this.uam.getValidUserId(cId, "john"), Arrays.asList(groupA));
      this.uam.addRolesToUser(cId, this.uam.getValidUserId(cId, "harry"), Arrays.asList(groupA, groupB));
      this.uam.addRolesToUser(cId, this.uam.getValidUserId(cId, "jack"), Arrays.asList(groupA, groupB, groupC));
      this.uam.addRolesToUser(cId, this.uam.getValidUserId(cId, "james"), Arrays.asList(groupA, groupB, groupC, groupD));
      this.uam.addRolesToUser(cId, this.uam.getValidUserId(cId, "oscar"), Arrays.asList(groupA));
      this.uam.addRolesToUser(cId, this.uam.getValidUserId(cId, "william"), Arrays.asList(groupA, groupB));
      this.uam.addRolesToUser(cId, this.uam.getValidUserId(cId, "george"), Arrays.asList(groupA, groupB, groupC));
      this.uam.addRolesToUser(cId, this.uam.getValidUserId(cId, "thomas"), Arrays.asList(groupA, groupB, groupC, groupD));

      this.uam.addRolesToUser(zandCustomerId, this.uam.getValidUserId(zandCustomerId, userRM1.login), Arrays.asList(RELATIONSHIP_MANAGER));

      LOGGER.info(CUSTOMER_CREATION_LOG, EMAAR.getName(), emaarKey);
      LOGGER.info(CUSTOMER_CREATION_LOG, NOON.getName(), noonKey);
      LOGGER.info(CUSTOMER_CREATION_LOG, ZAND.getName(), zandKey);
    } catch (InvalidIdentifierException | ConflictException | InconsistentDbContentException e) {
      throw new RuntimeException("Could not populate dev data.", e);
    }
  }

  /**
   * Populates grants for given User.
   */
  protected void grantUser(long customerId, long userId, Iterable<FeaturePermission> featurePermissions) throws InvalidIdentifierException {
    this.uam.revokeAllUser(customerId, userId);
    this.uam.grantUser(customerId, userId,
            StreamSupport.stream(featurePermissions.spliterator(), false)
                    .map(Grant::new).collect(Collectors.toSet()));
  }

  /**
   * Populates roles for given Customer.
   */
  protected void grantRole(long customerId, long roleId, Iterable<FeaturePermission> featurePermissions) throws InvalidIdentifierException {
    this.uam.revokeAllRole(customerId, roleId);
    this.uam.grantRole(customerId, roleId,
            StreamSupport.stream(featurePermissions.spliterator(), false)
                    .map(Grant::new).collect(Collectors.toSet()));
  }

  /**
   * Populates grants for all test Users.
   */
  protected void populateUserGrants()
          throws InvalidIdentifierException, InconsistentDbContentException {
    BiFunction<Feature, Permission, FeaturePermission> fp = (f, p) -> new FeaturePermission(f.getFeatureCode(), p.getPermissionCode());

    List<Permission> allPermissions = Arrays.asList(Permission.READ, Permission.WRITE, Permission.INITIATE, Permission.VALIDATE);
    List<FeaturePermission> paymentFeaturePermissionCJ = Arrays.stream(PaymentType.values())
            .flatMap(paymentType -> allPermissions.stream().map(permission -> fp.apply(paymentType.feature, permission)))
            .collect(Collectors.toList());
    List<FeaturePermission> depositFeaturePermissions = Stream.of(Feature.DEPOSIT_REQUEST, Feature.DEPOSIT_WITHDRAWAL)
            .flatMap(feature -> allPermissions.stream().map(permission -> fp.apply(feature, permission)))
            .collect(Collectors.toList());
    List<FeaturePermission> facilityFeaturePermission = Arrays.stream(FacilityType.values())
            .flatMap(facilityType ->
                    allPermissions.stream().map(permission -> fp.apply(facilityType.feature, permission)))
            .collect(Collectors.toList());

    List<FeaturePermission> sweepFeaturePermission = allPermissions.stream().map(permission -> fp.apply(Feature.SWEEP_REQUEST, permission))
            .collect(Collectors.toList());

    long emaarId = this.uam.getCustomerIdFromUuid(this.uam.getCustomerKeyOrNull(EMAAR.getName()));
    long noonId = this.uam.getCustomerIdFromUuid(this.uam.getCustomerKeyOrNull(NOON.getName()));

    Arrays.stream(new long[]{emaarId, noonId}).forEach(id -> {
      try {
        // user1 has all grants
        grantUser(id, this.uam.getValidUserId(id, user1.login),
                ImmutableListFactoryImpl.INSTANCE.of(
                        new FeaturePermission(Feature.UAM.getFeatureCode(), Permission.READ.getPermissionCode()),
                        new FeaturePermission(Feature.UAM.getFeatureCode(), Permission.WRITE.getPermissionCode()),
                        new FeaturePermission(Feature.AUTHORIZATION_MATRIX_RULE.getFeatureCode(), Permission.READ.getPermissionCode()),
                        new FeaturePermission(Feature.AUTHORIZATION_MATRIX_RULE.getFeatureCode(), Permission.WRITE.getPermissionCode()),
                        new FeaturePermission(Feature.ACCOUNT.getFeatureCode(), Permission.READ.getPermissionCode()),
                        new FeaturePermission(Feature.ACCOUNT.getFeatureCode(), Permission.WRITE.getPermissionCode()))
                        .newWithAll(paymentFeaturePermissionCJ)
                        .newWithAll(depositFeaturePermissions)
                        .newWithAll(facilityFeaturePermission)
                        .newWithAll(sweepFeaturePermission));
      } catch (InvalidIdentifierException | InconsistentDbContentException e) {
        throw new RuntimeException(e);
      }
    });

    // bob, CEO, all grants excepts UAM
    grantUser(emaarId, this.uam.getValidUserId(emaarId, "bob"),
            ImmutableListFactoryImpl.INSTANCE.of(
                    new FeaturePermission(Feature.AUTHORIZATION_MATRIX_RULE.getFeatureCode(), Permission.READ.getPermissionCode()),
                    new FeaturePermission(Feature.AUTHORIZATION_MATRIX_RULE.getFeatureCode(), Permission.WRITE.getPermissionCode()),
                    new FeaturePermission(Feature.ACCOUNT.getFeatureCode(), Permission.READ.getPermissionCode()),
                    new FeaturePermission(Feature.ACCOUNT.getFeatureCode(), Permission.WRITE.getPermissionCode()))
                    .newWithAll(paymentFeaturePermissionCJ)
                    .newWithAll(depositFeaturePermissions)
                    .newWithAll(facilityFeaturePermission)
                    .newWithAll(sweepFeaturePermission));

    // peter, CFO, all grants excepts UAM
    grantUser(emaarId, this.uam.getValidUserId(emaarId, "peter"),
            ImmutableListFactoryImpl.INSTANCE.of(
                    new FeaturePermission(Feature.AUTHORIZATION_MATRIX_RULE.getFeatureCode(), Permission.READ.getPermissionCode()),
                    new FeaturePermission(Feature.AUTHORIZATION_MATRIX_RULE.getFeatureCode(), Permission.WRITE.getPermissionCode()),
                    new FeaturePermission(Feature.ACCOUNT.getFeatureCode(), Permission.READ.getPermissionCode()),
                    new FeaturePermission(Feature.ACCOUNT.getFeatureCode(), Permission.WRITE.getPermissionCode()))
                    .newWithAll(paymentFeaturePermissionCJ)
                    .newWithAll(depositFeaturePermissions)
                    .newWithAll(facilityFeaturePermission)
                    .newWithAll(sweepFeaturePermission));

    // groupA
    grantRole(emaarId, this.uam.getValidRoleId(emaarId, groupA),
            Arrays.stream(PaymentType.values())
                    .flatMap(paymentType -> Collections.singletonList(Permission.INITIATE).stream().map(permission -> fp.apply(paymentType.feature, permission)))
                    .collect(Collectors.toList()));

    // groupB
    grantRole(emaarId, this.uam.getValidRoleId(emaarId, groupB),
            Arrays.stream(PaymentType.values())
                    .flatMap(paymentType -> Collections.singletonList(Permission.VALIDATE).stream().map(permission -> fp.apply(paymentType.feature, permission)))
                    .collect(Collectors.toList()));

    // groupC
    grantRole(emaarId, this.uam.getValidRoleId(emaarId, groupC),
            Arrays.stream(PaymentType.values())
                    .flatMap(paymentType -> Collections.singletonList(Permission.VALIDATE).stream().map(permission -> fp.apply(paymentType.feature, permission)))
                    .collect(Collectors.toList()));

    // groupD
    grantRole(emaarId, this.uam.getValidRoleId(emaarId, groupD),
            Arrays.stream(PaymentType.values())
                    .flatMap(paymentType -> Collections.singletonList(Permission.VALIDATE).stream().map(permission -> fp.apply(paymentType.feature, permission)))
                    .collect(Collectors.toList()));


    // groupA
    grantRole(emaarId, this.uam.getValidRoleId(emaarId, groupA),
            Collections.singletonList(Permission.INITIATE).stream().map(permission -> fp.apply(Feature.SWEEP_REQUEST, permission))
                    .collect(Collectors.toList()));

    // groupB
    grantRole(emaarId, this.uam.getValidRoleId(emaarId, groupB),
            Collections.singletonList(Permission.VALIDATE).stream().map(permission -> fp.apply(Feature.SWEEP_REQUEST, permission))
                    .collect(Collectors.toList()));

    // groupC
    grantRole(emaarId, this.uam.getValidRoleId(emaarId, groupC),
            Collections.singletonList(Permission.VALIDATE).stream().map(permission -> fp.apply(Feature.SWEEP_REQUEST, permission))
                    .collect(Collectors.toList()));

    // groupD
    grantRole(emaarId, this.uam.getValidRoleId(emaarId, groupD),
            Collections.singletonList(Permission.VALIDATE).stream().map(permission -> fp.apply(Feature.SWEEP_REQUEST, permission))
                    .collect(Collectors.toList()));
  }

  /**
   * Populates Approval Workflow Rules.
   */
  protected void populateZandRule() {
    UUID emaarKey = this.uam.getCustomerKeyOrNull(EMAAR.getName());
    ApprovalWorkflowRule approvalWorkflowRule = ApprovalWorkflowRule.create()
            .candidates(
                    Candidates.Candidate.group(groupB),
                    Candidates.Candidate.user(user1.login),
                    Candidates.Candidate.user("bob"),
                    Candidates.Candidate.user("peter"))
            .done();
    AuthorityRule authorityRule = new AuthorityRule(
            approvalWorkflowRule,
            new InRangeCondition<>(new BigDecimal(0), new BigDecimal(10_000)),
            Arrays.asList(AuthorityRule.StepType.AUTHORIZE));

    Arrays.stream(PaymentType.values())
            .forEach(paymentType -> this.authorityRuleService.createAndSaveRule(emaarKey, authorityRule, paymentType.feature.getFeatureCode(), "no attachment"));

    // For Deposit features.
    this.authorityRuleService.createAndSaveRule(emaarKey, authorityRule,
            Feature.DEPOSIT_REQUEST.getFeatureCode(), null);
    this.authorityRuleService.createAndSaveRule(emaarKey, authorityRule,
            Feature.DEPOSIT_WITHDRAWAL.getFeatureCode(), null);

    // For Sweep  features.
    this.authorityRuleService.createAndSaveRule(emaarKey, authorityRule,
            Feature.SWEEP_REQUEST.getFeatureCode(), null);

    // Drawdown Rules
    AuthorityRule facilityRule = new AuthorityRule(
            approvalWorkflowRule,
            new InRangeCondition<>(new BigDecimal(0), new BigDecimal(999_999_000)),
            Arrays.asList(AuthorityRule.StepType.AUTHORIZE));

    Arrays.stream(FacilityType.values())
            .forEach(facilityType -> this.authorityRuleService.
                    createAndSaveRule(emaarKey,
                            facilityRule,
                            facilityType.feature.getFeatureCode(),
                            "no attachment"));
  }
}
