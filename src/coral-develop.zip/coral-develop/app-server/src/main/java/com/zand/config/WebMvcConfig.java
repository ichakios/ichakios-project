package com.zand.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Configuration of frontends redirection rules
 * Used to redirect to the right index.html (needed for good frontend routing)
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
  @Override
  public void addViewControllers(ViewControllerRegistry registry) {

    // Client frontend
    registry
      .addViewController("/app")
      .setViewName("forward:/app/index.html");

    registry
      .addViewController("/app/")
      .setViewName("forward:/app/index.html");

    registry
      .addViewController("/app/**/{spring:\\w+}")
      .setViewName("forward:/app/index.html");

    // JHipster frontend
    registry
      .addViewController("/admin")
      .setViewName("forward:/admin/index.html");

    registry
      .addViewController("/admin/")
      .setViewName("forward:/admin/index.html");

    registry
      .addViewController("/admin/**/{spring:\\w+}")
      .setViewName("forward:/admin/index.html");
  }
}
