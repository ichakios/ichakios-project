/**
 * Data Transfer Objects.
 */
package com.zand.service.dto;
