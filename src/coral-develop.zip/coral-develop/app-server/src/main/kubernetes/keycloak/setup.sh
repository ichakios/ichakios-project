# create namespace if `kubectl get namespace coral` returns no resource.
kubectl create namespace coral

# add keycloak helm repo
helm repo add codecentric https://codecentric.github.io/helm-charts

helm repo update

# Helm 2
helm install --name keycloak --namespace coral codecentric/keycloak

# Helm 3
helm install --generate-name --namespace coral codecentric/keycloak
    NAME:   keycloak
    LAST DEPLOYED: Sun Jul  5 22:28:57 2020
    NAMESPACE: coral
    STATUS: DEPLOYED

    RESOURCES:
  ==> v1/ConfigMap
  NAME              AGE
  keycloak-sh       1s
  keycloak-startup  1s
  keycloak-test     1s

  ==> v1/Pod(related)
  NAME                   AGE
  keycloak-0             1s
  keycloak-postgresql-0  1s

  ==> v1/Secret
  NAME                 AGE
  keycloak-http        1s
  keycloak-postgresql  1s

  ==> v1/Service
  NAME                          AGE
  keycloak-headless             1s
  keycloak-http                 1s
  keycloak-postgresql           1s
  keycloak-postgresql-headless  1s

  ==> v1/StatefulSet
  NAME                 AGE
  keycloak             1s
  keycloak-postgresql  1s

  ==> v1beta1/Ingress
  NAME      AGE
  keycloak  1s


    NOTES:

    Keycloak can be accessed:

  * Within your cluster, at the following DNS name at port 80:

      keycloak-http.coral.svc.cluster.local

  * From outside the cluster:
      - https://keycloak.k8s.shd.eradahcapital.com

    Login with the following credentials:
    Username: keycloak

    To retrieve the initial user password run:
  kubectl get secret --namespace coral keycloak-http -o jsonpath="{.data.password}" | base64 --decode; echo

# Upgrade the helm chart
helm upgrade keycloak --namespace coral codecentric/keycloak -f values.yaml

# run network test
kubectl run --image=praqma/network-multitool nettool
kubectl exec -it nettool-59458d8d78-jr7qf -- /bin/sh
