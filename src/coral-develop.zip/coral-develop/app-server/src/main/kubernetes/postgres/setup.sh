helm repo add bitnami https://charts.bitnami.com/bitnami

#helm 3
helm install --generate-name --namespace coral bitnami/postgres -f values.yaml

#helm 2
helm install --name coral --namespace coral bitnami/postgresql -f values.yaml

NOTES:
  * Please be patient while the chart is being deployed **

PostgreSQL can be accessed via port 5432 on the following DNS name from within your cluster:

  coral-postgresql.coral.svc.cluster.local - Read/Write connection

To get the password for "postgres" run:

  export POSTGRES_PASSWORD=$(kubectl get secret --namespace coral coral-postgresql -o jsonpath="{.data.postgresql-password}" | base64 --decode)

To connect to your database run the following command:

  kubectl run coral-postgresql-client --rm --tty -i --restart='Never' --namespace coral --image docker.io/bitnami/postgresql:11.8.0-debian-10-r51 --env="PGPASSWORD=$POSTGRES_PASSWORD" --command -- psql --host coral-postgresql -U postgres -d postgres -p 5432


To connect to your database from outside the cluster execute the following commands:

  kubectl port-forward --namespace coral svc/coral-postgresql 5432:5432 &
  PGPASSWORD="$POSTGRES_PASSWORD" psql --host 127.0.0.1 -U postgres -d postgres -p 5432

NOTES:
  * Please be patient while the chart is being deployed **

PostgreSQL can be accessed via port 5432 on the following DNS name from within your cluster:

  coral-postgresql.coral.svc.cluster.local - Read/Write connection

To get the password for "postgres" run:

  export POSTGRES_PASSWORD=$(kubectl get secret --namespace coral coral-postgresql -o jsonpath="{.data.postgresql-password}" | base64 --decode)

To connect to your database run the following command:

  kubectl run coral-postgresql-client --rm --tty -i --restart='Never' --namespace coral --image docker.io/bitnami/postgresql:11.8.0-debian-10-r51 --env="PGPASSWORD=$POSTGRES_PASSWORD" --command -- psql --host coral-postgresql -U postgres -d postgres -p 5432



To connect to your database from outside the cluster execute the following commands:

  export NODE_IP=$(kubectl get nodes --namespace coral -o jsonpath="{.items[0].status.addresses[0].address}")
  export NODE_PORT=$(kubectl get --namespace coral -o jsonpath="{.spec.ports[0].nodePort}" services coral-postgresql)
  PGPASSWORD="$POSTGRES_PASSWORD" psql --host $NODE_IP --port $NODE_PORT -U postgres -d postgres
