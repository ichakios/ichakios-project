package com.zand;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.domain.JavaMethod;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import com.zand.spring.FeaturePermissionMethodSecurityExpressionHandler;
import com.zand.spring.HasAccess;
import com.zand.spring.ApiAccess;
import com.zand.spring.ApiAccesses;
import com.zand.spring.HasUamReadAccess;
import com.zand.spring.HasUamWriteAccess;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HasAccessClassScan {

  final JavaClasses importedClasses;

  HasAccessClassScan() {
    this.importedClasses = new ClassFileImporter()
            // comment the line below to test with TestClassScan
            .withImportOption(ImportOption.Predefined.DO_NOT_INCLUDE_TESTS)
            // and uncomment this line
//             .importClasses(TestClassScan.class);
            .importPackages("com.zand");
  }

  protected void printScan() {
    JavaClasses importedClass = new HasAccessClassScan().importedClasses;
    Map<String, List<Object[]>> annotationByCategory = new HashMap<>();
    importedClass.forEach(jc -> {
      Class<?> reflect = jc.reflect();
      for (JavaMethod method : jc.getAllMethods()) {
        HasAccess annotation = FeaturePermissionMethodSecurityExpressionHandler.getHasAccessAnnotation(method.reflect());
        if (annotation != null) {
          annotationByCategory.computeIfAbsent(annotation.feature().getCategory(), k -> new ArrayList<>())
                  .add(new Object[]{annotation.feature(), annotation.permission(), method});
        } else if (method.isAnnotatedWith(ApiAccesses.class)) {
          // Check for HasAccesses.
          ApiAccesses annotationOfType = method.getAnnotationOfType(ApiAccesses.class);
          for (ApiAccess hasAccessAPI : annotationOfType.value()) {
            annotationByCategory.computeIfAbsent(hasAccessAPI.feature().getCategory(), k -> new ArrayList<>())
                    .add(new Object[]{hasAccessAPI.feature(), hasAccessAPI.permission(), method});
          }
        }
      }
    });

    annotationByCategory.forEach((k, v) -> {
      System.out.println("Category: " + k);
      v.forEach(o -> print((Feature) o[0], (Permission) o[1], (JavaMethod) o[2]));
      System.out.println();
    });
  }

  public static void main(String[] args) {
    new HasAccessClassScan().printScan();
  }

  private static void print(Feature feature, Permission permission, JavaMethod method) {
    StringBuilder sb = new StringBuilder()
            .append("feature=")
            .append(feature.getFeatureCode())
            .append(", ")
            .append("permission=")
            .append(permission.getPermissionCode())
            .append(", method=")
            .append(method);
    System.out.println(sb.toString());
  }

  public class TestClassScan {

    @HasAccess(feature = Feature.PAYMENT_LOCAL, permission = Permission.READ)
    public void a() {
    }

    @HasUamWriteAccess
    public void b() {
    }

    @HasUamReadAccess
    public void c() {
    }

    @ApiAccesses({
            @ApiAccess(feature = Feature.PAYMENT_LOCAL, permission = Permission.READ),
            @ApiAccess(feature = Feature.PAYMENT_INTERNATIONAL, permission = Permission.READ)
    })
    public void d() {
    }
  }

  private HasAccess createAnnotation(Feature feature, Permission permission) {
    return new HasAccess() {

      @Override
      public Class<? extends Annotation> annotationType() {
        return HasAccess.class;
      }

      @Override
      public Feature feature() {
        return feature;
      }

      @Override
      public Permission permission() {
        return permission;
      }
    };
  }
}
