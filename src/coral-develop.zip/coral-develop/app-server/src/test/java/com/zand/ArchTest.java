package com.zand;

import com.tngtech.archunit.base.Optional;
import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import com.zand.web.rest.GlobalErrorHandler;
import com.zand.web.rest.errors.ExceptionTranslator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.core.annotation.Order;

import javax.annotation.Priority;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

class ArchTest {

  private static JavaClasses importedClasses;

  @BeforeAll
  public static void before() {
    importedClasses = new ClassFileImporter()
            .withImportOption(ImportOption.Predefined.DO_NOT_INCLUDE_TESTS)
            .importPackages("com.zand");
  }

  @Test
  void servicesAndRepositoriesShouldNotDependOnWebLayer() {
    noClasses()
            .that()
            .resideInAnyPackage("com.zand.service..")
            .or()
            .resideInAnyPackage("com.zand.repository..")
            .should().dependOnClassesThat()
            .resideInAnyPackage("..com.zand.web..")
            .because("Services and repositories should not depend on web layer")
            .check(importedClasses);
  }

  /**
   * Make sure the controller advice we built will be called before the one made by JHipster.
   */
  @Test
  void testPriorityControllerAdvices() {
    int value = importedClasses.get(GlobalErrorHandler.class).getAnnotationOfType(Order.class).value();
    Optional<Order> orderOptional = importedClasses.get(ExceptionTranslator.class).tryGetAnnotationOfType(Order.class);
    Optional<Priority> priorityOptional = importedClasses.get(ExceptionTranslator.class).tryGetAnnotationOfType(Priority.class);
    if (orderOptional.isPresent()) {
      Assertions.assertTrue(value < orderOptional.get().value());
    }
    if (priorityOptional.isPresent()) {
      Assertions.assertTrue(value < priorityOptional.get().value());
    }
  }
}
