package com.zand.web.rest.errors;

import com.zand.config.ApplicationProperties;
import com.zand.config.JacksonConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseProperties;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Import;

@SpringBootApplication(exclude = {LiquibaseAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
@EnableConfigurationProperties({LiquibaseProperties.class, ApplicationProperties.class})
@Import({
        ExceptionTranslatorTestController.class,
        ExceptionTranslator.class,
        JacksonConfiguration.class
})
public class ExceptionTranslatorApplication {
}
