package com.zand.liquibase;

import com.zand.config.LiquibaseConfiguration;
import liquibase.integration.spring.SpringLiquibase;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.persistence.EntityManager;

@ExtendWith(SpringExtension.class)
@DataJpaTest
class TestLiquibase {

  @Autowired
  EntityManager entityManager;

  @Autowired
  SpringLiquibase liquibase;

  /**
   * This test makes sure the right changelog is read and the {@link EntityManager} can be instantiated. If there
   * is an issue with the liquibase configuration (a column type is not compatible with its Java counterpart), the test
   * will not pass.
   */
  @Test
  void testChangeLog() {
    Assertions.assertEquals(LiquibaseConfiguration.CHANGE_LOG_PATH, this.liquibase.getChangeLog());
    Assertions.assertNotNull(this.entityManager);
  }
}
